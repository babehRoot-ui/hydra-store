import { NextResponse } from 'next/server'

export async function middleware(request) {
  const { pathname } = request.nextUrl

  // Proteksi rute /admin (termasuk sub-rute)
  if (pathname.startsWith('/admin')) {
    const sessionCookie = request.cookies.get('admin_session')
    const sessionToken = sessionCookie?.value

    // 1. Cek apakah cookie ada
    if (!sessionToken) {
      console.log('Middleware: No session token found, redirecting to /login')
      const loginUrl = new URL('/login', request.url)
      loginUrl.searchParams.set('from', pathname)
      return NextResponse.redirect(loginUrl)
    }

    // 2. JWT Verification is handled by src/app/admin/layout.js
    // Middleware cannot use Prisma in Edge Runtime, so we just check for the cookie's existence here.
    return NextResponse.next()
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
}
