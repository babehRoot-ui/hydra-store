'use client'

export default function FloatingContactBtn({ text, link }) {
  if (!link) return null;

  return (
    <a
      href={link.startsWith('http') || link.startsWith('mailto:') ? link : `https://wa.me/${link}`}
      target="_blank"
      rel="noopener noreferrer"
      style={{
        position: 'fixed',
        bottom: '5rem', // slightly above the bottom, usually above the music floating button
        right: '1.5rem',
        zIndex: 9997,
        display: 'flex',
        alignItems: 'center',
        gap: '0.5rem',
        padding: '0.75rem 1.2rem',
        borderRadius: '9999px',
        background: 'linear-gradient(135deg, #10b981, #059669)',
        color: 'white',
        fontWeight: 700,
        fontSize: '0.9rem',
        textDecoration: 'none',
        boxShadow: '0 4px 20px rgba(16, 185, 129, 0.4)',
        transition: 'transform 0.2s, box-shadow 0.2s',
        animation: 'bounce-subtle 2s infinite',
        backdropFilter: 'blur(10px)',
      }}
      onMouseEnter={e => {
        e.currentTarget.style.transform = 'scale(1.05) translateY(-2px)'
        e.currentTarget.style.boxShadow = '0 6px 25px rgba(16, 185, 129, 0.6)'
      }}
      onMouseLeave={e => {
        e.currentTarget.style.transform = 'scale(1) translateY(0)'
        e.currentTarget.style.boxShadow = '0 4px 20px rgba(16, 185, 129, 0.4)'
      }}
    >
      {/* WhatsApp / Chat Icon */}
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
      </svg>
      {text || 'Hubungi Admin'}

      <style>{`
        @keyframes bounce-subtle {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-4px); }
        }
      `}</style>
    </a>
  )
}
