'use client'
import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'

export default function LinksPage() {
  const [links, setLinks] = useState([])
  const [loading, setLoading] = useState(true)
  const [copiedId, setCopiedId] = useState(null)

  useEffect(() => {
    fetch('/api/links')
      .then(res => res.json())
      .then(res => {
        if (res.success) setLinks(res.data)
      })
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  const handleCopy = (e, url, id) => {
    e.stopPropagation()
    navigator.clipboard.writeText(url)
    setCopiedId(id)
    setTimeout(() => setCopiedId(null), 2000)
  }

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', background: '#050505' }}>
        <div className="cm-pulse"></div>
      </div>
    )
  }

  return (
    <div className="container" style={{ maxWidth: '680px', margin: '0 auto', paddingTop: '5rem', paddingBottom: '6rem' }}>
      <div className="text-center" style={{ marginBottom: '4rem' }}>
        <motion.div 
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          style={{ width: '90px', height: '90px', borderRadius: '50%', background: 'var(--gradient-main)', margin: '0 auto 1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2.5rem', boxShadow: '0 0 30px rgba(139, 92, 246, 0.4)' }}
        >
          💎
        </motion.div>
        <h1 className="text-gradient" style={{ fontSize: '2.5rem', fontWeight: 900, marginBottom: '0.5rem', letterSpacing: '-0.02em' }}>Tenka Connect</h1>
        <p className="text-secondary" style={{ fontSize: '1rem' }}>Pusat Informasi & Link Resmi Kami</p>
      </div>

      <div className="flex flex-col gap-4">
        {links.map((link, idx) => (
          <motion.div
            key={link.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1, type: 'spring', stiffness: 100 }}
            onClick={() => window.open(link.url, '_blank')}
            className="link-card-lynk"
            style={{ 
              display: 'flex', 
              alignItems: 'center', 
              padding: '1.4rem 1.8rem', 
              background: 'rgba(255,255,255,0.03)', 
              border: '1px solid rgba(255,255,255,0.08)', 
              borderRadius: '20px', 
              cursor: 'pointer',
              transition: 'all 0.4s cubic-bezier(0.23, 1, 0.32, 1)',
              position: 'relative'
            }}
            whileHover={{ 
              scale: 1.015, 
              backgroundColor: 'rgba(255,255,255,0.06)', 
              borderColor: 'rgba(139, 92, 246, 0.4)',
              boxShadow: '0 10px 30px rgba(0,0,0,0.3)'
            }}
            whileTap={{ scale: 0.98 }}
          >
            <div style={{ fontSize: '1.8rem', marginRight: '1.5rem', minWidth: '40px', textAlign: 'center' }}>
              {link.icon || '🔗'}
            </div>
            
            <div style={{ flex: 1 }}>
              <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#fff' }}>{link.title}</h3>
            </div>

            <button
              onClick={(e) => handleCopy(e, link.url, link.id)}
              style={{
                background: copiedId === link.id ? 'var(--tertiary-color)' : 'rgba(255,255,255,0.06)',
                border: '1px solid rgba(255,255,255,0.1)',
                color: '#fff',
                padding: '0.6rem 1.2rem',
                borderRadius: '12px',
                fontSize: '0.85rem',
                fontWeight: 800,
                cursor: 'pointer',
                transition: 'all 0.3s',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                marginLeft: '1rem'
              }}
            >
              {copiedId === link.id ? '✅ Copied' : '📋 Salin'}
            </button>
          </motion.div>
        ))}
      </div>

      {links.length === 0 && (
        <div className="text-center text-secondary" style={{ marginTop: '3rem', padding: '3rem', background: 'rgba(255,255,255,0.02)', borderRadius: '20px', border: '1px dashed rgba(255,255,255,0.1)' }}>
          Belum ada link yang tersedia saat ini.
        </div>
      )}

      <footer className="text-center" style={{ marginTop: '5rem' }}>
        <a href="/" style={{ 
          fontSize: '0.9rem', 
          color: '#a1a1aa', 
          textDecoration: 'none', 
          padding: '0.75rem 2rem', 
          borderRadius: '999px', 
          border: '1px solid rgba(255,255,255,0.1)',
          background: 'rgba(255,255,255,0.02)',
          transition: 'all 0.3s'
        }}
        onMouseEnter={e => { e.currentTarget.style.borderColor = '#8b5cf6'; e.currentTarget.style.color = '#fff' }}
        onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)'; e.currentTarget.style.color = '#a1a1aa' }}
        >
          ← Kembali ke Beranda
        </a>
      </footer>
    </div>
  )
}
