'use client'
import { useState, useEffect } from 'react'

export default function CategoryFilter({ categories, onFilterChange }) {
  const [activeTab, setActiveTab] = useState('all')

  const handleTabClick = (slug) => {
    setActiveTab(slug)
    onFilterChange(slug)
  }

  return (
    <div className="filter-container">
      <div className="filter-scroll">
        <button 
          onClick={() => handleTabClick('all')}
          className={`filter-pill ${activeTab === 'all' ? 'active' : ''}`}
        >
          Semua
        </button>
        {categories.map(cat => (
          <button 
            key={cat.slug}
            onClick={() => handleTabClick(cat.slug)}
            className={`filter-pill ${activeTab === cat.slug ? 'active' : ''}`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      <style jsx>{`
        .filter-container {
          margin: 2rem 0 3rem;
          display: flex;
          justify-content: center;
          width: 100%;
        }
        .filter-scroll {
          display: flex;
          gap: 0.75rem;
          padding: 0.5rem;
          overflow-x: auto;
          scrollbar-width: none; /* Firefox */
          max-width: 100%;
        }
        .filter-scroll::-webkit-scrollbar {
          display: none; /* Chrome/Safari */
        }
        .filter-pill {
          white-space: nowrap;
          padding: 0.75rem 1.5rem;
          border-radius: 12px;
          background: rgba(255, 255, 255, 0.03);
          border: 1px solid rgba(255, 255, 255, 0.08);
          color: #a1a1aa;
          font-size: 0.875rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .filter-pill:hover {
          background: rgba(255, 255, 255, 0.06);
          border-color: rgba(139, 92, 246, 0.3);
          color: #fff;
        }
        .filter-pill.active {
          background: rgba(139, 92, 246, 0.15);
          border-color: rgba(139, 92, 246, 0.5);
          color: #c084fc;
          box-shadow: 0 0 20px rgba(139, 92, 246, 0.2);
        }
        @media (max-width: 768px) {
          .filter-container {
            justify-content: flex-start;
          }
          .filter-pill {
            padding: 0.6rem 1.25rem;
            font-size: 0.8rem;
          }
        }
      `}</style>
    </div>
  )
}
