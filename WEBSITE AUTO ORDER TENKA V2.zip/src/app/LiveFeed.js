'use client'
import { useState, useEffect } from 'react'

export default function LiveFeed() {
  const [show, setShow] = useState(false)
  const [data, setData] = useState(null)
  const [history, setHistory] = useState([])

  useEffect(() => {
    const fetchFeed = async () => {
      try {
        const res = await fetch('/api/feed')
        const feed = await res.json()
        if (feed.length > 0) {
          setHistory(feed)
        }
      } catch (e) {
        console.error('Feed error:', e)
      }
    }

    fetchFeed()
    const interval = setInterval(fetchFeed, 30000) // Check every 30s
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (history.length === 0) return

    const showRandom = () => {
      const randomItem = history[Math.floor(Math.random() * history.length)]
      setData(randomItem)
      setShow(true)
      setTimeout(() => setShow(false), 5000)
    }

    const timer = setInterval(showRandom, 15000) // Show a notification every 15s
    return () => clearInterval(timer)
  }, [history])

  if (!data) return null

  return (
    <div style={{
      position: 'fixed', bottom: '2rem', right: '2rem', zIndex: 100,
      transform: show ? 'translateX(0)' : 'translateX(120%)',
      transition: 'all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275)',
      pointerEvents: 'none'
    }}>
      <div className="glass-card" style={{
        display: 'flex', alignItems: 'center', gap: '1rem',
        padding: '0.75rem 1.25rem', border: '1px solid rgba(139, 92, 246, 0.3)',
        boxShadow: '0 10px 30px rgba(0,0,0,0.5)', minWidth: '280px'
      }}>
        <div style={{
          width: '40px', height: '40px', borderRadius: '50%',
          background: 'linear-gradient(135deg, #8b5cf6, #3b82f6)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem'
        }}>
          🛒
        </div>
        <div>
          <p style={{ fontSize: '0.75rem', color: '#a1a1aa', margin: 0 }}>{data.user} baru saja {data.action}</p>
          <p style={{ fontSize: '0.85rem', fontWeight: 700, margin: 0, color: 'white' }}>{data.product}</p>
        </div>
      </div>
    </div>
  )
}
