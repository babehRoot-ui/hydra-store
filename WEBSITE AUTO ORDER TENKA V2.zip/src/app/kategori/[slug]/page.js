import { prisma } from '@/lib/prisma'
import Link from 'next/link'
import CategoryClientZone from './CategoryClientZone'
import { DEFAULT_CATEGORIES } from '@/app/api/admin/categories/route'

export const dynamic = 'force-dynamic'

export default async function KategoriPage({ params }) {
  const { slug } = await params
  
  // Fetch dynamic categories
  const setting = await prisma.setting.findUnique({
    where: { key: 'CATEGORIES' }
  })
  let categories = DEFAULT_CATEGORIES
  if (setting && setting.value) {
    try {
      categories = JSON.parse(setting.value)
    } catch (e) {}
  }

  const config = categories.find(c => c.slug === slug) || {
    label: slug.charAt(0).toUpperCase() + slug.slice(1),
    icon: '📦', heroDesc: `Produk kategori ${slug}.`,
    accentFrom: '#3b82f6', accentTo: '#8b5cf6',
    layout: 'grid-card', bgVariant: 0, robotPose: 'wave', robotSide: 'right',
    tags: [slug],
  }

  const tags = config.tags || [slug]
  // 1. Ambil setting urutan
  const sortSetting = await prisma.setting.findUnique({
    where: { key: 'PRODUCT_SORT' }
  })
  const sortType = sortSetting?.value || 'cheapest'

  // 2. Tentukan orderBy
  let orderBy = { price: 'asc' }
  if (sortType === 'expensive') orderBy = { price: 'desc' }
  if (sortType === 'latest') orderBy = { createdAt: 'desc' }

  const products = await prisma.product.findMany({
    where: {
      category: { in: [slug, ...tags] }
    },
    orderBy: sortType === 'random' ? undefined : orderBy
  })

  // 3. Jika random, acak di level JS
  if (sortType === 'random') {
    products.sort(() => Math.random() - 0.5)
  }

  const { label, icon, heroDesc, accentFrom, accentTo, layout, bgVariant, robotPose, robotSide } = config
  const gradient = `linear-gradient(135deg, ${accentFrom}, ${accentTo})`

  return (
    <main style={{ paddingBottom: '8rem', position: 'relative', minHeight: '100vh' }}>
      {/* ── Hero (server rendered) ────────── */}
      <section style={{ position: 'relative', zIndex: 2 }}>
        <div style={{ position: 'absolute', inset: 0, opacity: 0.08, background: gradient, pointerEvents: 'none' }} />
        <div className="container text-center page-enter" style={{ padding: '5rem 0 3rem', position: 'relative', zIndex: 1 }}>
          <div style={{ fontSize: '4rem', marginBottom: '1rem', display: 'inline-block', animation: 'robot-float 3s ease-in-out infinite' }}>{icon}</div>
          <h1 style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)', fontWeight: 800, marginBottom: '1rem' }}>
            <span style={{ background: gradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
              {label}
            </span>
          </h1>
          <p style={{ color: '#a1a1aa', fontSize: '1.05rem', maxWidth: '520px', margin: '0 auto 2rem' }}>{heroDesc}</p>
          <span style={{ display: 'inline-flex', padding: '0.4rem 1.1rem', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '9999px', fontSize: '0.875rem', color: '#a1a1aa', gap: '0.4rem' }}>
            <span style={{ background: gradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', fontWeight: 700 }}>{products.length}</span>
            produk tersedia
          </span>
        </div>
      </section>

      {/* Breadcrumb */}
      <div className="container" style={{ padding: '0.5rem 0 1.5rem', fontSize: '0.875rem', color: '#52525b', position: 'relative', zIndex: 2 }}>
        <Link href="/" style={{ color: '#52525b' }}>Beranda</Link>
        <span style={{ margin: '0 0.5rem' }}>›</span>
        <span style={{ color: '#a1a1aa' }}>{label}</span>
      </div>

      {/* Category tabs (server rendered) */}
      <div className="container" style={{ position: 'relative', zIndex: 2, marginBottom: '2.5rem' }}>
        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
          {categories.map((c) => (
            <Link key={c.slug} href={`/kategori/${c.slug}`} style={{
              display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
              padding: '0.45rem 1rem', borderRadius: '9999px', fontSize: '0.85rem', fontWeight: 500,
              border: c.slug === slug ? 'none' : '1px solid rgba(255,255,255,0.1)',
              background: c.slug === slug
                ? `linear-gradient(135deg, ${c.accentFrom}, ${c.accentTo})`
                : 'rgba(255,255,255,0.03)',
              color: c.slug === slug ? 'white' : '#a1a1aa',
              textDecoration: 'none', transition: 'all 0.2s'
            }}>
              {c.icon} {c.label}
            </Link>
          ))}
        </div>
      </div>

      {/* Products + space elements (client zone) */}
      <section className="container" style={{ position: 'relative', zIndex: 2 }}>
        <CategoryClientZone
          products={JSON.parse(JSON.stringify(products))}
          layout={layout}
          gradient={gradient}
          bgVariant={bgVariant}
          robotPose={robotPose}
          robotSide={robotSide}
          slug={slug}
        />
      </section>
    </main>
  )
}
