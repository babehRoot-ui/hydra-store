'use client'
import SpaceBackground from '@/app/SpaceBackground'
import RobotMascot from '@/app/RobotMascot'
import ProductCarousel from '@/app/ProductCarousel'
import MasonryLayout from '@/app/MasonryLayout'
import CheckoutSection from '@/app/CheckoutSection'
import { useState } from 'react'
import Link from 'next/link'

function BadgePill({ badge }) {
  const colors = { HOT: '#ef4444', NEW: '#10b981', SALE: '#f59e0b', LIMITED: '#8b5cf6' }
  return (
    <div className="compact-card-badge" style={{ background: colors[badge] || '#8b5cf6' }}>
      {badge}
    </div>
  )
}

// ── Compact Grid Layout (Dongtube Inspired) ─────────
function CompactGridLayout({ products, onBuy }) {
  return (
    <div className="compact-grid">
      {products.map((p, idx) => {
        return (
          <div key={p.id} className="compact-card" onClick={() => onBuy(p)} style={{ animation: 'fadeIn 0.5s ease both', animationDelay: `${idx * 0.05}s` }}>
            {p.badge && <BadgePill badge={p.badge} />}
            <div className="compact-card-img-wrapper">
              {p.imageUrl 
                ? <img src={p.imageUrl} alt={p.name} className="compact-card-img" /> 
                : <div className="compact-card-img" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2.5rem', background: 'rgba(255,255,255,0.02)' }}>🤖</div>
              }
            </div>
            <div className="compact-card-body">
              {p.subcategory && <span className="compact-card-cat">{p.subcategory}</span>}
              <h3 className="compact-card-title">{p.name}</h3>
              <div className="compact-card-price">
                {Number(p.price) === 0 ? (
                  <span style={{ color: '#f59e0b', fontWeight: 800 }}>GRATIS</span>
                ) : (
                  `Rp ${p.price.toLocaleString('id-ID')}`
                )}
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}

// ── Showcase alternating Layout ────────────────────
function ShowcaseLayout({ products, gradient, onBuy }) {
  return (
    <div className="showcase-container" style={{ display: 'flex', flexDirection: 'column', gap: '4rem' }}>
      {products.map((p, idx) => {
        const isLeft = idx % 2 === 0
        return (
          <div key={p.id} className={`glass-card showcase-card ${isLeft ? 'left' : 'right'}`} onClick={() => onBuy(p)} style={{ cursor: 'pointer', animation: 'fadeIn 0.55s ease both', animationDelay: `${idx * 0.1}s` }}>
            <div className="showcase-image-box">
              {p.imageUrl ? <img src={p.imageUrl} alt={p.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <span style={{ fontSize: '6rem' }}>🦕</span>}
            </div>
            <div className="showcase-content">
              <div style={{ marginBottom: '1rem' }}>{p.badge && <BadgePill badge={p.badge} />}</div>
              <h3 style={{ fontSize: '2.5rem', fontWeight: 900, marginBottom: '1rem', letterSpacing: '-0.02em' }}>{p.name}</h3>
              <p style={{ color: '#a1a1aa', lineHeight: 1.7, fontSize: '1.1rem', marginBottom: '2rem', maxWidth: '600px' }}>{p.description}</p>
              <div style={{ display: 'flex', alignItems: 'center', gap: '2rem', flexWrap: 'wrap' }}>
                <p style={{ fontSize: '2.5rem', fontWeight: 900, color: Number(p.price) === 0 ? '#f59e0b' : '#10b981' }}>
                  {Number(p.price) === 0 ? "GRATIS" : `Rp ${p.price.toLocaleString('id-ID')}`}
                </p>
                <button className="btn btn-primary" style={{ pointerEvents: 'none', padding: '1rem 2.5rem', fontSize: '1rem' }}>Beli Sekarang</button>
              </div>
            </div>
          </div>
        )
      })}
      <style jsx>{`
        .showcase-card { display: grid; grid-template-columns: 1.2fr 1fr; gap: 4rem; align-items: center; padding: 4rem; }
        .showcase-image-box { width: 100%; height: 400px; border-radius: 1.5rem; overflow: hidden; background: rgba(255,255,255,0.03); display: flex; alignItems: center; justifyContent: center; }
        .showcase-card.left .showcase-image-box { order: 1; }
        .showcase-card.left .showcase-content { order: 2; }
        .showcase-card.right .showcase-image-box { order: 2; }
        .showcase-card.right .showcase-content { order: 1; }
        
        @media (max-width: 1024px) {
          .showcase-card { grid-template-columns: 1fr; gap: 2rem; padding: 2.5rem; }
          .showcase-card.left .showcase-image-box, .showcase-card.right .showcase-image-box { order: 1; }
          .showcase-card.left .showcase-content, .showcase-card.right .showcase-content { order: 2; }
          .showcase-image-box { height: 300px; }
        }
        @media (max-width: 768px) {
           .showcase-card { padding: 1.5rem; }
           .showcase-image-box { height: 220px; }
        }
      `}</style>
    </div>
  )
}

// ── Main export: CategoryClientZone ───────────────
export default function CategoryClientZone({ products, layout, gradient, bgVariant, robotPose, robotSide, slug }) {
  const [selectedProduct, setSelectedProduct] = useState(null)

  const handleBuy = (product) => {
    setSelectedProduct(product)
    setTimeout(() => {
      const el = document.getElementById('checkout-section')
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' })
      }
    }, 100)
  }

  return (
    <>
      <SpaceBackground variant={bgVariant} />
      <RobotMascot pose={robotPose} side={robotSide} />

      <div className="category-content-wrapper" style={{ position: 'relative', zIndex: 1, padding: '2rem 0' }}>
        {products.length === 0 ? (
          <EmptyStateMini slug={slug} />
        ) : (
          <>
            {layout === 'grid-card' && <CompactGridLayout products={products} onBuy={handleBuy} />}
            {layout === 'carousel'  && <ProductCarousel products={products} onBuy={handleBuy} />}
            {layout === 'masonry'   && <MasonryLayout products={products} gradient={gradient} onBuy={handleBuy} />}
            {layout === 'showcase'  && <ShowcaseLayout products={products} gradient={gradient} onBuy={handleBuy} />}
            
            <div className="flex justify-between items-center" style={{ marginTop: '4rem', borderTop: '1px solid rgba(255,255,255,0.05)', paddingTop: '2rem' }}>
              <p className="text-secondary" style={{ fontSize: '0.9rem' }}>
                Total <strong>{products.length}</strong> produk.
              </p>
              <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="btn btn-outline" style={{ padding: '0.6rem 1.25rem', fontSize: '0.85rem' }}>
                ↑ Atas
              </button>
            </div>
          </>
        )}
      </div>

      <CheckoutSection 
        product={selectedProduct} 
        onReset={() => setSelectedProduct(null)} 
      />

      <style jsx>{`
        .category-content-wrapper { width: 100%; }
      `}</style>
    </>
  )
}

function EmptyStateMini({ slug }) {
  return (
    <div style={{ textAlign: 'center', padding: '6rem 2rem', position: 'relative' }}>
      <svg width="220" height="260" viewBox="0 0 180 220">
        <g style={{ animation: 'robot-float 3s ease-in-out infinite' }}>
          <rect x="65" y="90" width="50" height="45" rx="10" fill="#1e293b" stroke="#3b82f6" strokeWidth="1.8"/>
          <circle cx="90" cy="112" r="7" fill="#60a5fa"/>
          <rect x="67" y="55" width="46" height="38" rx="12" fill="#0f172a" stroke="#8b5cf6" strokeWidth="1.8"/>
          <circle cx="80" cy="70" r="4" fill="#60a5fa"/>
          <circle cx="100" cy="70" r="4" fill="#60a5fa"/>
          <path d="M 76 82 Q 90 90 104 82" stroke="#94a3b8" strokeWidth="2" fill="none" strokeLinecap="round"/>
          <line x1="90" y1="55" x2="90" y2="44" stroke="#8b5cf6" strokeWidth="2.5" strokeLinecap="round"/>
          <circle cx="90" cy="42" r="4" fill="#c084fc"/>
        </g>
        <g style={{ transformOrigin: '80px 135px', animation: 'robot-swing-legs 1.5s ease-in-out infinite' }}>
          <rect x="75" y="133" width="10" height="15" rx="5" fill="#0f172a" stroke="#8b5cf6" strokeWidth="1.2"/>
        </g>
        <g style={{ transformOrigin: '100px 135px', animation: 'robot-swing-legs 1.5s ease-in-out infinite reverse' }}>
          <rect x="95" y="133" width="10" height="15" rx="5" fill="#0f172a" stroke="#8b5cf6" strokeWidth="1.2"/>
        </g>
      </svg>
      <h3 style={{ fontSize: '1.8rem', fontWeight: 800, margin: '1.5rem 0 0.75rem' }}>Belum ada produk 🌙</h3>
      <p style={{ color: '#a1a1aa', marginBottom: '2rem', fontSize: '1rem' }}>Robot kami masih santai di bulan...</p>
      <Link href="/admin/products" className="btn btn-primary" style={{ padding: '1rem 2.5rem' }}>+ Tambah Produk</Link>
    </div>
  )
}
