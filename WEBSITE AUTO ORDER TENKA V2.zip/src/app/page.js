import { prisma } from '@/lib/prisma'
import ClientHome from './ClientHome'
import { getSettings } from '@/lib/settings'
import { DEFAULT_CATEGORIES } from '@/app/api/admin/categories/route'

export const dynamic = 'force-dynamic'

export default async function Home() {
  // 0. Pelacak Pengunjung Unik Asli secara Asinkron (Non-blocking)
  try {
    const { headers } = await import('next/headers');
    const headersList = await headers();
    const rawIp = headersList.get('x-forwarded-for') || headersList.get('x-real-ip') || '127.0.0.1';
    const clientIp = rawIp.split(',')[0].trim();
    
    // upsert: jika IP belum ada akan dibuat, jika sudah ada dibiarkan (mencegah duplikasi pengunjung)
    prisma.visitor.upsert({
      where: { ip: clientIp },
      update: {},
      create: { ip: clientIp }
    }).catch(err => console.error('Error saving visitor:', err));
  } catch (e) {
    console.error('Error tracking visitor:', e);
  }
  // 1. Ambil setting urutan
  const sortSetting = await prisma.setting.findUnique({
    where: { key: 'PRODUCT_SORT' }
  })
  const sortType = sortSetting?.value || 'cheapest'

  // 2. Tentukan orderBy
  let orderBy = { price: 'asc' }
  if (sortType === 'expensive') orderBy = { price: 'desc' }
  if (sortType === 'latest') orderBy = { createdAt: 'desc' }

  // 3. Ambil produk
  let products = await prisma.product.findMany({
    orderBy: sortType === 'random' ? undefined : orderBy,
  });

  // 4. Jika random, acak di level JS
  if (sortType === 'random') {
    products = products.sort(() => Math.random() - 0.5)
  }

  // 5. Fetch dynamic categories
  const categorySetting = await prisma.setting.findUnique({
    where: { key: 'CATEGORIES' }
  })
  let categories = DEFAULT_CATEGORIES
  if (categorySetting && categorySetting.value) {
    try {
      categories = JSON.parse(categorySetting.value)
    } catch (e) {}
  }

  const settings = await getSettings([
    'WELCOME_TYPE', 'WELCOME_TITLE', 'WELCOME_TEXT', 
    'WELCOME_IMAGE', 'WELCOME_VIDEO', 'WELCOME_DOC_LINK', 
    'WELCOME_MUSIC_URL', 'STORE_NAME', 'STORE_TAGLINE'
  ])

  const welcomeData = {
    type: settings.WELCOME_TYPE || 'text',
    title: settings.WELCOME_TITLE,
    text: settings.WELCOME_TEXT,
    image: settings.WELCOME_IMAGE,
    video: settings.WELCOME_VIDEO,
    docLink: settings.WELCOME_DOC_LINK,
    musicUrl: settings.WELCOME_MUSIC_URL,
    storeName: settings.STORE_NAME,
    storeTagline: settings.STORE_TAGLINE,
  }

  return (
    <main style={{ paddingBottom: '6rem', minHeight: '100vh' }}>
      <ClientHome
        products={JSON.parse(JSON.stringify(products))}
        initialCategories={categories}
        welcomeData={welcomeData}
      />
    </main>
  )
}
