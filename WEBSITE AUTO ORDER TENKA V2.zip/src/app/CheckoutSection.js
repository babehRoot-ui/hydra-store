'use client'
import { useState, useEffect, useRef } from 'react'
import { QRCodeCanvas } from 'qrcode.react'
import { toast } from 'react-hot-toast'
import { useCart } from '@/lib/CartContext'

const DURATIONS = [
  { label: '3 Hari', price: 3000, code: '3' },
  { label: '7 Hari', price: 6000, code: '7' },
  { label: '14 Hari', price: 10000, code: '14' },
  { label: '30 Hari', price: 15000, code: '30' },
  { label: '2 Bulan', price: 18000, code: '60' },
  { label: '4 Bulan', price: 28000, code: '120' },
  { label: 'Permanen', price: 40000, code: '9999999' },
]

export default function CheckoutSection({ product, onReset }) {
  const { cartItems, cartTotal, removeFromCart, updateQuantity, clearCart } = useCart()
  const [step, setStep] = useState('FORM')
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)
  const [order, setOrder] = useState(null)
  const [timeLeft, setTimeLeft] = useState(480)
  const [receipt, setReceipt] = useState('')
  const [deliveryType, setDeliveryType] = useState('LINK')
  const [deliveryContent, setDeliveryContent] = useState(null)
  const [deliveryLink2, setDeliveryLink2] = useState(null)
  const [deliveryLink2Desc, setDeliveryLink2Desc] = useState(null)
  const pollRef = useRef(null)
  const canvasRef = useRef(null)

  // Sewa Bot States (Only for single product "Sewa" category)
  const [selectedDuration, setSelectedDuration] = useState(DURATIONS[3])
  const [groupLink, setGroupLink] = useState('')
  const isSewa = product?.category?.toLowerCase() === 'sewa' || product?.subcategory?.toLowerCase() === 'sewa'

  useEffect(() => {
    if (product) {
      setStep('FORM')
      setOrder(null)
      setReceipt('')
    }
  }, [product])

  const currentTotal = product 
    ? (isSewa ? selectedDuration.price : (Number(product?.price) || 0))
    : cartTotal
    
  const isFree = product 
    ? (!isSewa && currentTotal === 0)
    : (cartItems.length > 0 && currentTotal === 0)

  const handleDownloadQR = () => {
    if (!canvasRef.current) return
    const canvas = canvasRef.current.querySelector('canvas')
    if (!canvas) return
    const url = canvas.toDataURL('image/png')
    const a = document.createElement('a')
    a.href = url
    a.download = `QRIS-Tenka-${order?.orderId || 'Payment'}.png`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
  }

  const handleCheckout = async (e) => {
    e.preventDefault()
    
    // Check if anything is being bought
    if (!product && cartItems.length === 0) return toast.error('Keranjang masih kosong!')

    if (isSewa) {
      if (!groupLink) return toast.error('Harap masukkan link grup penyewa!')
      const waNumber = '6283191853837'
      const message = encodeURIComponent(`.buysewa ${selectedDuration.code} ${groupLink}`)
      window.location.href = `https://wa.me/${waNumber}?text=${message}`
      return
    }

    setLoading(true)
    try {
      const checkoutData = product 
        ? {
            productId: product.id,
            customerPhone: phone,
            amount: currentTotal
          }
        : {
            items: cartItems.map(item => ({ id: item.id, quantity: item.quantity })),
            customerPhone: phone,
            amount: currentTotal
          }

      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(checkoutData)
      })
      const data = await res.json()
      if (data.success) {
        if (isFree) {
          setReceipt(data.receiptCode || 'GRATIS-SUCCESS')
          setDeliveryType(data.deliveryType || 'LINK')
          setDeliveryContent(data.deliveryContent || null)
          setStep('SUCCESS')
          if (!product) clearCart()
        } else {
          setOrder({ 
            orderId: data.orderId, 
            paymentUrl: typeof data.paymentUrl === 'string' ? data.paymentUrl : null,
            qrisString: data.qrisString 
          })
          setStep('QRIS')
          if (!product) clearCart()
        }
      } else {
        toast.error('Gagal: ' + data.message)
      }
    } catch (err) {
      toast.error('Error: ' + err.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (step !== 'QRIS' || isFree) return
    if (timeLeft <= 0) { onReset(); return }
    const t = setInterval(() => setTimeLeft(p => p - 1), 1000)
    return () => clearInterval(t)
  }, [step, timeLeft, isFree])

  useEffect(() => {
    if (step === 'QRIS' && order?.orderId) {
      pollRef.current = setInterval(async () => {
        try {
          const res = await fetch(`/api/checkout/status/${order.orderId}`)
          const data = await res.json()
          if (data.status === 'SUCCESS') {
            setReceipt(data.receiptCode || '')
            setDeliveryType(data.deliveryType || 'LINK')
            setDeliveryContent(data.deliveryContent || null)
            setDeliveryLink2(data.deliveryLink2 || null)
            setDeliveryLink2Desc(data.deliveryLink2Desc || null)
            clearInterval(pollRef.current)
            setStep('SUCCESS')
          }
        } catch {}
      }, 3000)
    }
    return () => { if (pollRef.current) clearInterval(pollRef.current) }
  }, [step, order])

  const fmt = s => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`

  return (
    <div id="checkout-section" className="glass-card" style={{ 
      marginTop: '4rem', 
      padding: '0', 
      overflow: 'hidden', 
      border: '1px solid rgba(139,92,246,0.3)', 
      boxShadow: '0 0 40px rgba(139,92,246,0.1)', 
      scrollMarginTop: '100px',
      maxWidth: '1000px',
      margin: '4rem auto 8rem auto'
    }}>
      <div style={{ background: 'linear-gradient(to right, rgba(139,92,246,0.1), rgba(236,72,153,0.1))', padding: '1.5rem 2rem', borderBottom: '1px solid rgba(255,255,255,0.05)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 800 }}>
          {step === 'FORM' ? (product ? '🛒 Kasir Pembayaran' : '🛒 Keranjang Belanja') : step === 'QRIS' ? '💳 Scan QRIS' : '🎉 Transaksi Berhasil!'}
        </h2>
        {(product || cartItems.length > 0) && step === 'FORM' && (
          <button 
            onClick={() => {
              if (product) onReset()
              else clearCart()
            }} 
            style={{ background: 'none', border: 'none', color: '#ef4444', fontSize: '0.8rem', fontWeight: 700, cursor: 'pointer' }}
          >
            {product ? 'Batal / Ganti' : 'Kosongkan Keranjang'}
          </button>
        )}
      </div>

      <div style={{ padding: '2.5rem' }}>
        {!product && cartItems.length === 0 && step === 'FORM' ? (
          <div style={{ textAlign: 'center', py: '3rem' }}>
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🛒</div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '0.5rem' }}>Keranjang Anda Kosong</h3>
            <p style={{ color: '#a1a1aa' }}>Tambahkan beberapa produk ke keranjang untuk melakukan pembelian massal.</p>
          </div>
        ) : (
          <>
            {step === 'FORM' && (
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '3rem' }} className="mobile-stack">
                <div style={{ maxHeight: '500px', overflowY: 'auto', paddingRight: '10px' }} className="custom-scrollbar">
                  {product ? (
                    <div>
                       <div style={{ width: '100%', height: '300px', borderRadius: '1rem', overflow: 'hidden', marginBottom: '1.5rem', background: 'rgba(0,0,0,0.2)', border: '1px solid rgba(255,255,255,0.05)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          {product.imageUrl ? <img src={product.imageUrl} style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} /> : <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '4rem' }}>🤖</div>}
                       </div>
                       <h3 style={{ fontSize: '1.5rem', fontWeight: 800, marginBottom: '0.5rem' }}>{product.name}</h3>
                       <p style={{ color: '#a1a1aa', fontSize: '0.9rem', lineHeight: 1.6 }}>{product.description || 'Produk digital premium dengan pengiriman otomatis.'}</p>
                    </div>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                      {cartItems.map(item => (
                        <div key={item.id} className="glass-card" style={{ padding: '1rem', display: 'flex', gap: '1rem', alignItems: 'center', background: 'rgba(255,255,255,0.02)' }}>
                          <div style={{ width: '60px', height: '60px', borderRadius: '8px', background: 'rgba(0,0,0,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                            {item.imageUrl ? <img src={item.imageUrl} style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: '8px' }} /> : '📦'}
                          </div>
                          <div style={{ flex: 1 }}>
                            <h4 style={{ fontSize: '0.9rem', fontWeight: 700, marginBottom: '0.2rem' }}>{item.name}</h4>
                            <p style={{ fontSize: '0.8rem', color: '#10b981', fontWeight: 700 }}>Rp {item.price.toLocaleString('id-ID')}</p>
                          </div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <button onClick={() => updateQuantity(item.id, (item.quantity || 1) - 1)} style={S.qtyBtn}>-</button>
                            <span style={{ fontSize: '0.9rem', fontWeight: 700, minWidth: '20px', textAlign: 'center' }}>{item.quantity || 1}</span>
                            <button onClick={() => updateQuantity(item.id, (item.quantity || 1) + 1)} style={S.qtyBtn}>+</button>
                            <button onClick={() => removeFromCart(item.id)} style={{ background: 'none', border: 'none', color: '#ef4444', marginLeft: '0.5rem', cursor: 'pointer' }}>🗑️</button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <form onSubmit={handleCheckout}>
                  <label className="cm-label" style={{ display: 'block', marginBottom: '0.5rem', color: '#a1a1aa', fontSize: '0.8rem', fontWeight: 700 }}>NOMOR WHATSAPP</label>
                  <input
                    className="input" 
                    type="text" 
                    inputMode="numeric"
                    placeholder="628xxxxxxxxxx" 
                    required
                    value={phone} 
                    onChange={e => setPhone(e.target.value.replace(/\D/g, ''))}
                    style={{ marginBottom: '1.5rem', width: '100%', padding: '0.8rem', borderRadius: '8px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.1)', color: 'white' }}
                  />

                  <div style={{ background: 'rgba(16,185,129,0.05)', border: '1px solid rgba(16,185,129,0.2)', padding: '1.25rem', borderRadius: '1rem', marginBottom: '2rem' }}>
                     <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ color: '#a1a1aa', fontWeight: 600 }}>Total Pembayaran</span>
                        <span style={{ color: '#10b981', fontSize: '1.75rem', fontWeight: 900 }}>
                          {isFree ? 'GRATIS' : `Rp ${currentTotal.toLocaleString('id-ID')}`}
                        </span>
                     </div>
                  </div>

                  <button type="submit" disabled={loading} className="btn btn-primary" style={{ width: '100%', padding: '1.25rem', fontWeight: 800 }}>
                    {loading ? '⏳ Memproses...' : (isFree ? 'Dapatkan Sekarang (Gratis)' : '💎 Konfirmasi & Bayar Sekarang')}
                  </button>
                  {!product && (
                    <p style={{ textAlign: 'center', fontSize: '0.75rem', color: '#71717a', marginTop: '1rem' }}>
                      Membeli {cartItems.length} item sekaligus
                    </p>
                  )}
                </form>
              </div>
            )}

            {step === 'QRIS' && (
              <div style={{ textAlign: 'center', maxWidth: '500px', margin: '0 auto' }}>
                <h3 style={{ fontSize: '1.5rem', fontWeight: 800, marginBottom: '1rem' }}>Scan QRIS untuk Membayar</h3>
                <div ref={canvasRef} style={{ background: 'white', padding: '1.5rem', borderRadius: '1.5rem', display: 'inline-block', marginBottom: '1.5rem' }}>
                  <QRCodeCanvas value={order.qrisString} size={250} />
                </div>
                <div style={{ color: '#ef4444', fontWeight: 700, marginBottom: '1.5rem', fontSize: '1.2rem' }}>⏰ {fmt(timeLeft)}</div>
                
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                   <button onClick={handleDownloadQR} className="btn btn-outline" style={{ width: '100%', background: 'rgba(59,130,246,0.1)', borderColor: 'rgba(59,130,246,0.3)', color: '#60a5fa' }}>
                     📥 Simpan QRIS ke Galeri
                   </button>
                   <button onClick={onReset} className="btn btn-outline" style={{ width: '100%', color: '#ef4444', borderColor: 'rgba(239,68,68,0.2)' }}>
                     ❌ Batal Bayar
                   </button>
                </div>

                <p style={{ color: '#a1a1aa', fontSize: '0.8rem', marginTop: '2rem' }}>Pembayaran akan terdeteksi otomatis. Jangan tutup halaman ini sampai muncul notifikasi sukses.</p>
              </div>
            )}

            {step === 'SUCCESS' && (
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '5rem', marginBottom: '1.5rem' }}>✅</div>
                <h3 style={{ fontSize: '2rem', fontWeight: 900, color: '#10b981', marginBottom: '1rem' }}>PEMBAYARAN BERHASIL</h3>
                <div className="glass-card" style={{ maxWidth: '600px', margin: '0 auto', padding: '2rem', textAlign: 'left', background: 'rgba(16,185,129,0.05)' }}>
                   <p style={{ fontSize: '0.8rem', color: '#a1a1aa', marginBottom: '0.5rem' }}>Resi / Kode Akses:</p>
                   <div style={{ fontSize: '1.5rem', fontWeight: 900, color: '#f59e0b', fontFamily: 'monospace', marginBottom: '1.5rem', padding: '1rem', background: 'rgba(0,0,0,0.2)', borderRadius: '8px', wordBreak: 'break-all' }}>{receipt}</div>
                   
                   {deliveryContent && (
                     <a href={deliveryContent} target="_blank" className="btn btn-primary" style={{ display: 'block', textDecoration: 'none', textAlign: 'center', marginBottom: '1rem', padding: '1rem' }}>
                       📥 Download / Buka Produk
                     </a>
                   )}
                   <button onClick={onReset} className="btn btn-outline" style={{ width: '100%', padding: '0.8rem' }}>Kembali Belanja</button>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      <style jsx>{`
        .mobile-stack { display: grid; }
        @media (max-width: 768px) {
          .mobile-stack { grid-template-columns: 1fr !important; gap: 2rem !important; }
        }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: rgba(255,255,255,0.05); }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(139,92,246,0.5); borderRadius: 10px; }
      `}</style>
    </div>
  )
}

const S = {
  qtyBtn: {
    width: '24px', height: '24px', borderRadius: '4px', border: '1px solid rgba(255,255,255,0.1)',
    background: 'rgba(255,255,255,0.05)', color: 'white', cursor: 'pointer', display: 'flex',
    alignItems: 'center', justifyContent: 'center', fontSize: '1rem'
  }
}
