'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'

export default function PaymentPoller({ orderId }) {
  const router = useRouter()
  const [error, setError] = useState(null)

  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/checkout/status/${orderId}`)
        const data = await res.json()
        
        if (data.success && data.status === 'SUCCESS') {
          clearInterval(interval)
          router.refresh()
        }
      } catch (err) {
        console.error('Failed to poll payment status', err)
      }
    }, 5000) // Poll every 5 seconds

    return () => clearInterval(interval)
  }, [orderId, router])

  return (
    <div style={{ marginTop: '1.5rem', textAlign: 'center' }}>
      <div style={{ width: '20px', height: '20px', border: '3px solid rgba(59, 130, 246, 0.3)', borderTop: '3px solid #60a5fa', borderRadius: '50%', animation: 'spin 1s linear infinite', margin: '0 auto 0.5rem' }} />
      <p style={{ color: '#60a5fa', fontSize: '0.85rem' }}>
        Menunggu pembayaran Anda...
      </p>
      <style jsx>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  )
}
