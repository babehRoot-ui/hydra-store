'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'

export default function SimulatePayment({ orderId }) {
  const router = useRouter()
  const [timeLeft, setTimeLeft] = useState(5)

  useEffect(() => {
    // Simulasi pembayaran otomatis setelah 5 detik
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timer)
    }

    // Panggil API untuk set SUCCESS
    const triggerSuccess = async () => {
      try {
        await fetch('/api/checkout/simulate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderId })
        })
        // Refresh halaman agar SSR (Server Component) membaca status SUCCESS
        router.refresh()
      } catch (err) {
        console.error(err)
      }
    }

    triggerSuccess()
  }, [timeLeft, orderId, router])

  return (
    <div style={{ marginTop: '1.5rem', padding: '0.75rem', background: 'rgba(59, 130, 246, 0.1)', border: '1px solid rgba(59, 130, 246, 0.3)', borderRadius: '0.5rem', textAlign: 'center', width: '100%' }}>
      <p style={{ color: '#60a5fa', fontSize: '0.85rem' }}>
        🔄 Simulasi: Pembayaran akan sukses otomatis dalam {timeLeft} detik...
      </p>
    </div>
  )
}
