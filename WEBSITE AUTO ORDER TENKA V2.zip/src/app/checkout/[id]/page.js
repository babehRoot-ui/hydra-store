import { prisma } from '@/lib/prisma'
import { redirect } from 'next/navigation'
import PaymentPoller from './PaymentPoller'

export default async function CheckoutOrder({ params }) {
  const { id } = params;
  
  // Cari order beserta produknya
  const order = await prisma.order.findUnique({ 
    where: { id },
    include: { product: true }
  });

  if (!order) {
    redirect('/');
  }

  // Jika sudah sukses, tampilkan pesanan
  if (order.status === 'SUCCESS') {
    return (
      <main className="container flex items-center justify-center" style={{ minHeight: '80vh', padding: '4rem 0' }}>
        <div className="glass-card" style={{ maxWidth: '600px', width: '100%', textAlign: 'center', padding: '3rem' }}>
          <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>🎉</div>
          <h1 style={{ fontSize: '2rem', fontWeight: 700, color: '#10b981', marginBottom: '1rem' }}>Pembayaran Berhasil!</h1>
          <p className="text-secondary" style={{ marginBottom: '2rem' }}>Terima kasih <strong>{order.customerPhone}</strong>, pesanan Anda untuk <strong>{order.product.name}</strong> telah berhasil diproses.</p>
          
          <div style={{ background: 'rgba(16, 185, 129, 0.1)', border: '1px solid rgba(16, 185, 129, 0.3)', padding: '1.5rem', borderRadius: '1rem', marginBottom: '2rem' }}>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 600, color: 'white', marginBottom: '0.5rem' }}>Detail Pesanan:</h3>
            <p className="text-secondary" style={{ marginBottom: '1rem' }}>Simpan detail ini baik-baik.</p>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
              <span className="text-secondary">Kode Resi:</span>
              <strong style={{ color: 'white' }}>{order.receiptCode}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span className="text-secondary">Status:</span>
              <strong style={{ color: '#10b981' }}>SELESAI</strong>
            </div>
          </div>
          
          <p className="text-secondary" style={{ fontSize: '0.9rem' }}>Kami telah mengirimkan instruksi dan link akses produk ke nomor WhatsApp Anda.</p>
          <a href="/" className="btn btn-primary" style={{ display: 'inline-block', marginTop: '2rem', padding: '0.8rem 2rem' }}>Kembali ke Beranda</a>
        </div>
      </main>
    )
  }

  // Jika belum sukses, tampilkan QR Code
  return (
    <main className="container flex items-center justify-center" style={{ minHeight: '80vh', padding: '4rem 0' }}>
      <div className="glass-card flex flex-col gap-6 items-center" style={{ maxWidth: '500px', width: '100%', padding: '3rem' }}>
        <h1 style={{ fontSize: '1.75rem', fontWeight: 700, textAlign: 'center' }}>Selesaikan Pembayaran</h1>
        
        <div style={{ width: '100%', background: 'rgba(255,255,255,0.05)', padding: '1rem', borderRadius: '0.75rem', border: '1px solid var(--card-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <p className="text-secondary" style={{ fontSize: '0.85rem' }}>Produk</p>
            <p style={{ fontWeight: 600 }}>{order.product.name}</p>
          </div>
          <div style={{ textAlign: 'right' }}>
            <p className="text-secondary" style={{ fontSize: '0.85rem' }}>Total Tagihan</p>
            <p className="text-gradient" style={{ fontWeight: 700, fontSize: '1.2rem' }}>Rp {order.amount.toLocaleString('id-ID')}</p>
          </div>
        </div>

        <div style={{ 
          background: 'white', padding: '1.5rem', borderRadius: '1rem', 
          display: 'flex', flexDirection: 'column', alignItems: 'center', width: '250px', height: '250px',
          boxShadow: '0 0 20px rgba(59, 130, 246, 0.3)'
        }}>
          {/* Real Pakasir QR Code Image */}
          <div style={{ position: 'relative', width: '100%', height: '100%' }}>
             {order.pakasirRef ? (
               <img src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(order.pakasirRef)}`} alt="QRIS QR Code" style={{ width: '100%', height: '100%' }} />
             ) : (
               <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f1f5f9', color: '#64748b', fontSize: '0.8rem', textAlign: 'center' }}>
                 Gagal memuat QRIS. Hubungi Admin.
               </div>
             )}
          </div>
        </div>
        
        <div style={{ textAlign: 'center' }}>
          <p style={{ fontWeight: 600, color: 'white', marginBottom: '0.2rem' }}>Scan QRIS ini untuk membayar</p>
          <p className="text-secondary" style={{ fontSize: '0.85rem' }}>Pembayaran otomatis terverifikasi oleh Pakasir.</p>
        </div>

        <PaymentPoller orderId={order.id} />
      </div>
    </main>
  )
}
