import Link from 'next/link'

export default function CheckoutSuccess({ searchParams }) {
  const orderId = searchParams.orderId;

  return (
    <main className="container flex items-center justify-center" style={{ minHeight: '80vh' }}>
      <div className="glass-card flex flex-col items-center justify-center text-center animate-fade-in" style={{ padding: '4rem 2rem', maxWidth: '600px', width: '100%' }}>
        <div style={{ width: '80px', height: '80px', background: 'var(--tertiary-color)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '2rem' }}>
          <span style={{ fontSize: '2.5rem', color: 'white' }}>✓</span>
        </div>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 700, marginBottom: '1rem' }}>Pesanan Diterima!</h1>
        <p className="text-secondary" style={{ fontSize: '1.1rem', marginBottom: '0.5rem' }}>
          Terima kasih telah berbelanja di Tenka.
        </p>
        <p className="text-secondary" style={{ marginBottom: '2rem' }}>
          Order ID: <span className="text-gradient" style={{ fontWeight: 600 }}>{orderId || 'SIMULATION-123'}</span>
        </p>
        <p className="text-secondary" style={{ fontSize: '0.9rem', marginBottom: '2rem', padding: '1rem', background: 'rgba(255,255,255,0.02)', borderRadius: '0.5rem' }}>
          Di sistem aslinya, status pembayaran Anda akan diperbarui secara otomatis ketika Anda sudah membayar melalui payment gateway Pakasir.
        </p>
        <Link href="/" className="btn btn-primary" style={{ padding: '0.75rem 2rem' }}>
          Kembali ke Toko
        </Link>
      </div>
    </main>
  )
}
