import nextDynamic from 'next/dynamic'
import Link from 'next/link'
import ClientSpaceBackground from '@/app/ClientSpaceBackground'

export const dynamic = 'force-dynamic'

export default function RenewPage() {
  return (
    <main style={{ paddingBottom: '8rem', position: 'relative', minHeight: '100vh' }}>
      <ClientSpaceBackground variant={2} />
      
      <section className="container text-center" style={{ padding: '6rem 0 3rem', position: 'relative', zIndex: 2 }}>
        <h1 style={{ fontSize: '3rem', fontWeight: 800, marginBottom: '1.5rem' }}>
          <span className="text-gradient">Perpanjang Panel</span>
        </h1>
        <p className="text-secondary" style={{ maxWidth: '500px', margin: '0 auto 2.5rem' }}>
          Lanjutkan masa aktif server Anda sebelum berakhir.
        </p>

        <div className="glass-card text-center" style={{ padding: '4rem', maxWidth: '600px', margin: '0 auto' }}>
          <p style={{ fontSize: '3rem', marginBottom: '1rem' }}>🔄</p>
          <h3 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '0.5rem' }}>Layanan Belum Tersedia</h3>
          <p className="text-secondary">Fitur perpanjangan panel akan segera hadir. Silahkan hubungi admin untuk bantuan manual.</p>
        </div>
      </section>

      <section className="container" style={{ position: 'relative', zIndex: 2, marginTop: '3rem' }}>
        <div style={{ textAlign: 'center' }}>
          <Link href="/track" className="text-secondary" style={{ fontSize: '0.9rem' }}>
            Lupa ID Server? Cek Riwayat Order →
          </Link>
        </div>
      </section>
    </main>
  )
}
