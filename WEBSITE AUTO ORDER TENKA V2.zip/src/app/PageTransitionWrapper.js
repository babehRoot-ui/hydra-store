'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { usePathname } from 'next/navigation';
import { useState, useEffect } from 'react';

// Berbagai macam animasi yang premium, menarik, dan smooth
const variants = [
  // 1. Muncul dari Kiri, menghilang ke Kanan (Slide Horizontal)
  {
    initial: { x: '-100vw', scale: 0.9, opacity: 0, filter: 'blur(10px)' },
    animate: { x: 0, scale: 1, opacity: 1, filter: 'blur(0px)' },
    exit: { x: '100vw', scale: 0.9, opacity: 0, filter: 'blur(10px)' },
  },
  // 2. Muncul dari Kanan, menghilang ke Kiri (Slide Horizontal)
  {
    initial: { x: '100vw', scale: 0.9, opacity: 0, filter: 'blur(10px)' },
    animate: { x: 0, scale: 1, opacity: 1, filter: 'blur(0px)' },
    exit: { x: '-100vw', scale: 0.9, opacity: 0, filter: 'blur(10px)' },
  },
  // 3. Muncul dari Bawah, menghilang ke Atas (Slide Vertical)
  {
    initial: { y: '100vh', scale: 0.95, opacity: 0, filter: 'blur(10px)' },
    animate: { y: 0, scale: 1, opacity: 1, filter: 'blur(0px)' },
    exit: { y: '-100vh', scale: 0.95, opacity: 0, filter: 'blur(10px)' },
  },
  // 4. Muncul dari Atas, menghilang ke Bawah (Slide Vertical)
  {
    initial: { y: '-100vh', scale: 0.95, opacity: 0, filter: 'blur(10px)' },
    animate: { y: 0, scale: 1, opacity: 1, filter: 'blur(0px)' },
    exit: { y: '100vh', scale: 0.95, opacity: 0, filter: 'blur(10px)' },
  },
  // 5. Zoom in membesar dengan elegan (Scale focus)
  {
    initial: { scale: 0.8, opacity: 0, filter: 'blur(15px)' },
    animate: { scale: 1, opacity: 1, filter: 'blur(0px)' },
    exit: { scale: 1.1, opacity: 0, filter: 'blur(15px)' },
  }
];

// Helper untuk mendapatkan efek "acak" berdasarkan nama path,
// ini mencegah error Hydration di Next.js karena selalu konsisten per halaman.
const getRandomVariantIndex = (path) => {
  let hash = 0;
  for (let i = 0; i < path.length; i++) {
    hash = path.charCodeAt(i) + ((hash << 5) - hash);
  }
  return Math.abs(hash) % variants.length;
};

export default function PageTransitionWrapper({ children }) {
  const pathname = usePathname();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const variantIndex = getRandomVariantIndex(pathname || '');
  const activeVariant = variants[variantIndex];

  return (
    <AnimatePresence mode="wait">
      {mounted && (
        <motion.div
          key={pathname}
          initial={activeVariant.initial}
          animate={activeVariant.animate}
          exit={activeVariant.exit}
          transition={{
            type: 'spring',
            stiffness: 150,     // Disesuaikan agar lebih lembut (soft)
            damping: 18,        // Redaman agar tidak terlalu memantul keras
            mass: 0.8,          // Sedikit lebih berat agar elegan
            duration: 0.6       // Waktu animasi agar memanjakan mata
          }}
          style={{ width: '100%' }}
        >
          {children}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
