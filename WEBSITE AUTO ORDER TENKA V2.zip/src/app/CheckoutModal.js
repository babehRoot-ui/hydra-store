'use client'
import { useState, useEffect, useRef } from 'react'
import { QRCodeSVG } from 'qrcode.react'
import { toast } from 'react-hot-toast'

const DURATIONS = [
  { label: '3 Hari', price: 3000, code: '3' },
  { label: '7 Hari', price: 6000, code: '7' },
  { label: '14 Hari', price: 10000, code: '14' },
  { label: '30 Hari', price: 15000, code: '30' },
  { label: '2 Bulan', price: 18000, code: '60' },
  { label: '4 Bulan', price: 28000, code: '120' },
  { label: 'Permanen', price: 40000, code: '9999999' },
]

export default function CheckoutModal({ product, onClose }) {
  const [step, setStep] = useState('FORM')
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)
  const [order, setOrder] = useState(null)
  const [timeLeft, setTimeLeft] = useState(480)
  const [receipt, setReceipt] = useState('')
  const [deliveryType, setDeliveryType] = useState('LINK')
  const [deliveryContent, setDeliveryContent] = useState(null)
  const [deliveryLink2, setDeliveryLink2] = useState(null)
  const [deliveryLink2Desc, setDeliveryLink2Desc] = useState(null)
  const pollRef = useRef(null)
  const qrRef = useRef(null)

  // Sewa Bot States
  const [selectedDuration, setSelectedDuration] = useState(DURATIONS[3]) // Default 30 Hari
  const [groupLink, setGroupLink] = useState('')
  const isSewa = product.category?.toLowerCase() === 'sewa' || product.subcategory?.toLowerCase() === 'sewa'

  useEffect(() => {
    if (!product) return
  }, [product])

  if (!product) return null

  // Total price logic
  const totalPrice = isSewa ? selectedDuration.price : (Number(product.price) || 0)

  const handleCheckout = async (e) => {
    e.preventDefault()
    
    if (isSewa) {
      if (!groupLink) {
        toast.error('Harap masukkan link grup penyewa!')
        return
      }
      // WA Redirect for Sewa Bot
      const waNumber = '6283191853837'
      const message = encodeURIComponent(`.buysewa ${selectedDuration.code} ${groupLink}`)
      window.location.href = `https://wa.me/${waNumber}?text=${message}`
      return
    }

    setLoading(true)
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: product.id,
          customerName: 'Pelanggan',
          customerPhone: phone,
          customerEmail: 'noemail@mail.com',
          amount: totalPrice
        })
      })
      const data = await res.json()
      if (data.success) {
        setOrder({ 
          orderId: data.orderId, 
          paymentUrl: typeof data.paymentUrl === 'string' ? data.paymentUrl : null,
          qrisString: data.qrisString 
        })
        setStep('QRIS')
      } else {
        toast.error('Gagal: ' + (data.message || 'Error'))
      }
    } catch (err) {
      toast.error('Error: ' + err.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (step !== 'QRIS') return
    if (timeLeft <= 0) { onClose(); return }
    const t = setInterval(() => setTimeLeft(p => p - 1), 1000)
    return () => clearInterval(t)
  }, [step, timeLeft, onClose])

  useEffect(() => {
    if (step === 'QRIS' && order?.orderId) {
      pollRef.current = setInterval(async () => {
        try {
          const res = await fetch(`/api/checkout/status/${order.orderId}`)
          const data = await res.json()
          if (data.status === 'SUCCESS') {
            setReceipt(data.receiptCode || '')
            setDeliveryType(data.deliveryType || 'LINK')
            setDeliveryContent(data.deliveryContent || null)
            setDeliveryLink2(data.deliveryLink2 || null)
            setDeliveryLink2Desc(data.deliveryLink2Desc || null)
            clearInterval(pollRef.current)
            setStep('SUCCESS')
          }
        } catch {}
      }, 3000)
    }
    return () => { if (pollRef.current) clearInterval(pollRef.current) }
  }, [step, order])

  const fmt = s => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`

  return (
    <div className="cm-overlay" onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <div className="cm-box" onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div className="cm-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ fontSize: 22 }}>{step === 'FORM' ? '🛒' : step === 'QRIS' ? '💳' : '🎉'}</span>
            <span style={{ fontSize: 17, fontWeight: 800 }}>
              {step === 'FORM' && (isSewa ? 'Sewa Bot WhatsApp' : 'Detail Pesanan')}
              {step === 'QRIS' && 'Pembayaran QRIS Otomatis'}
              {step === 'SUCCESS' && 'Pembayaran Berhasil!'}
            </span>
          </div>
          <button className="cm-close-btn" onClick={onClose}>✕</button>
        </div>

        {/* Body */}
        <div className="cm-body">

          {/* STEP FORM */}
          {step === 'FORM' && (
            <div className="cm-grid">
              {/* Left */}
              <div className="cm-left">
                <div className="cm-img-box">
                  {product.imageUrl
                    ? <img src={product.imageUrl} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    : <span style={{ fontSize: 56 }}>🤖</span>}
                </div>
                <h3 style={{ fontSize: 20, fontWeight: 800, marginBottom: 10 }}>{product.name}</h3>
                <p style={{ color: '#9ca3af', fontSize: 14, lineHeight: 1.7, marginBottom: 16 }}>
                  {isSewa ? 'Penyewaan bot WhatsApp aktif 24/7 dengan sistem otomatis.' : (product.description || 'Produk digital premium, pengiriman instan.')}
                </p>
                
                {isSewa && (
                  <div style={{ padding: '12px', background: 'rgba(255,255,255,0.03)', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.05)' }}>
                    <p style={{ fontSize: '11px', color: '#71717a', fontWeight: 800, marginBottom: '8px', textTransform: 'uppercase' }}>💰 HARGA SEWA</p>
                    <div style={{ display: 'grid', gap: '4px' }}>
                      {DURATIONS.map(d => (
                        <div key={d.code} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: d.code === selectedDuration.code ? '#c084fc' : '#a1a1aa' }}>
                          <span>{d.label}</span>
                          <span style={{ fontWeight: 700 }}>Rp {d.price.toLocaleString('id-ID')}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Right */}
              <div className="cm-right">
                <form onSubmit={handleCheckout}>
                  {isSewa ? (
                    <>
                      <label className="cm-label">Pilih Masa Sewa</label>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '1.5rem' }}>
                        {DURATIONS.map(d => (
                          <button 
                            key={d.code} 
                            type="button"
                            onClick={() => setSelectedDuration(d)}
                            style={{
                              padding: '8px 12px',
                              borderRadius: '8px',
                              fontSize: '12px',
                              fontWeight: 700,
                              border: '1px solid',
                              borderColor: selectedDuration.code === d.code ? '#8b5cf6' : 'rgba(255,255,255,0.1)',
                              background: selectedDuration.code === d.code ? 'rgba(139,92,246,0.2)' : 'rgba(255,255,255,0.02)',
                              color: selectedDuration.code === d.code ? '#fff' : '#71717a',
                              transition: 'all 0.2s ease'
                            }}
                          >
                            {d.label}
                          </button>
                        ))}
                      </div>

                      <label className="cm-label">Link Grup WhatsApp</label>
                      <input
                        className="cm-input" type="url" placeholder="https://chat.whatsapp.com/..." required
                        value={groupLink} onChange={e => setGroupLink(e.target.value)}
                        style={{ marginBottom: '1rem' }}
                      />
                    </>
                  ) : (
                    <>
                      <label className="cm-label">Nomor WhatsApp</label>
                      <input
                        className="cm-input" 
                        type="text" 
                        inputMode="numeric"
                        pattern="[0-9]*"
                        placeholder="628xxxxxxxxxx" 
                        required
                        maxLength={25}
                        value={phone} 
                        onChange={e => setPhone(e.target.value.replace(/\D/g, ''))}
                      />
                      <div style={{ marginBottom: 20, padding: 15, borderRadius: 12, background: 'rgba(139,92,246,0.1)', border: '1px solid rgba(139,92,246,0.2)' }}>
                        <p style={{ fontSize: 13, fontWeight: 600, color: '#c084fc' }}>💳 Pembayaran QRIS Otomatis</p>
                        <p style={{ fontSize: 11, color: '#a1a1aa', marginTop: 4 }}>Pembayaran akan langsung terverifikasi secara otomatis.</p>
                      </div>
                    </>
                  )}

                  <div className="cm-price-box">
                    <span style={{ color: '#9ca3af', fontSize: 14 }}>{isSewa ? 'Biaya Sewa' : 'Total Bayar'}</span>
                    <span style={{ color: '#10b981', fontSize: 26, fontWeight: 900 }}>
                      Rp {totalPrice.toLocaleString('id-ID')}
                    </span>
                  </div>

                  <button type="submit" className="cm-btn-primary" disabled={loading} style={{ background: isSewa ? '#25d366' : '' }}>
                    {loading ? '⏳ Memproses...' : (isSewa ? '📱 Sewa via WhatsApp' : '🛒 Konfirmasi & Bayar')}
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* STEP QRIS */}
          {step === 'QRIS' && (
            <div className="cm-center">
              <h3 style={{ fontSize: 26, fontWeight: 900, marginBottom: 6 }}>QRIS Pembayaran</h3>
              <p style={{ color: '#9ca3af', marginBottom: 32, fontSize: 15 }}>
                Silakan scan QRIS di bawah ini. Pembayaran akan terdeteksi otomatis oleh sistem kami.
              </p>

              <div className="cm-qr-box" ref={qrRef}>
                <QRCodeSVG 
                  value={String(order.qrisString || '').trim()} 
                  size={220} 
                  level="H"
                  includeMargin={true}
                />
                <div className="cm-timer-badge">⏰ {fmt(timeLeft)}</div>
              </div>

              {/* Download QR Button */}
              <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
                <button
                  onClick={() => {
                    const svgEl = qrRef.current?.querySelector('svg')
                    if (!svgEl) return
                    const svgData = new XMLSerializer().serializeToString(svgEl)
                    const canvas = document.createElement('canvas')
                    const ctx = canvas.getContext('2d')
                    const img = new Image()
                    img.onload = () => {
                      canvas.width = img.width
                      canvas.height = img.height
                      ctx.fillStyle = '#ffffff'
                      ctx.fillRect(0, 0, canvas.width, canvas.height)
                      ctx.drawImage(img, 0, 0)
                      const a = document.createElement('a')
                      a.download = `QRIS-${order?.orderId?.slice(0, 8) || 'tenka'}.png`
                      a.href = canvas.toDataURL('image/png')
                      a.click()
                    }
                    img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)))
                  }}
                  style={{
                    padding: '10px 20px',
                    borderRadius: '10px',
                    border: '1px solid rgba(16, 185, 129, 0.3)',
                    background: 'rgba(16, 185, 129, 0.1)',
                    color: '#10b981',
                    fontWeight: 700,
                    fontSize: '14px',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    fontFamily: 'inherit',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.style.background = 'rgba(16, 185, 129, 0.2)'
                    e.currentTarget.style.borderColor = 'rgba(16, 185, 129, 0.5)'
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.style.background = 'rgba(16, 185, 129, 0.1)'
                    e.currentTarget.style.borderColor = 'rgba(16, 185, 129, 0.3)'
                  }}
                >
                  📥 Download QR Code
                </button>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, marginBottom: 20 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#60a5fa', fontWeight: 700, fontSize: 14 }}>
                  <span className="cm-pulse" />
                  Mendeteksi pembayaran otomatis...
                </div>
              </div>

              <p style={{ color: '#4b5563', fontSize: 12, marginBottom: 24 }}>
                ID Transaksi: <strong style={{ color: '#6b7280' }}>#{order?.orderId?.slice(0, 14)}</strong>
              </p>

              <button 
                onClick={onClose}
                style={{
                  padding: '10px 24px',
                  borderRadius: '8px',
                  border: '1px solid rgba(239, 68, 68, 0.3)',
                  background: 'rgba(239, 68, 68, 0.1)',
                  color: '#ef4444',
                  fontWeight: 700,
                  fontSize: '14px',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                  fontFamily: 'inherit'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.background = 'rgba(239, 68, 68, 0.2)'
                  e.currentTarget.style.borderColor = 'rgba(239, 68, 68, 0.5)'
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.background = 'rgba(239, 68, 68, 0.1)'
                  e.currentTarget.style.borderColor = 'rgba(239, 68, 68, 0.3)'
                }}
              >
                ✖ Batal Beli
              </button>
            </div>
          )}

          {/* STEP SUCCESS */}
          {step === 'SUCCESS' && (
            <div className="cm-success-wrapper">
              <div className="cm-robot">🤖</div>
              <div className="cm-success-card cm-card-animated" style={{ width: '100%', maxWidth: '500px' }}>
                <div style={{ fontSize: 56, marginBottom: 12 }}>💎</div>
                <h3 style={{ fontSize: 28, fontWeight: 900, color: '#10b981', marginBottom: 8, textTransform: 'uppercase' }}>Berhasil!</h3>
                
                <div className="cm-resi-box">
                  <p style={{ fontSize: 11, color: '#6b7280', marginBottom: 4 }}>Produk:</p>
                  <p style={{ fontWeight: 700, fontSize: 15, marginBottom: 12 }}>{product.name}</p>

                  {/* Panel/Server Credentials Display */}
                  {(product.category === 'ptero' || product.category === 'panel') && receipt?.includes('Server ID') ? (
                    <div style={{ textAlign: 'left' }}>
                      <p style={{ fontSize: 12, color: '#60a5fa', fontWeight: 800, marginBottom: 10, textTransform: 'uppercase' }}>
                        🖥️ Informasi Login Panel Server:
                      </p>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        {receipt.split('\n').map((line, i) => {
                          const [label, ...valueParts] = line.split(': ')
                          const value = valueParts.join(': ')
                          return (
                            <div key={i} style={{
                              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                              padding: '10px 14px', borderRadius: '10px',
                              background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)'
                            }}>
                              <span style={{ fontSize: 12, color: '#9ca3af', fontWeight: 600 }}>{label}</span>
                              <span style={{
                                fontSize: 13, fontWeight: 800, fontFamily: 'monospace',
                                color: line.includes('Password') ? '#f59e0b' : line.includes('Domain') ? '#60a5fa' : '#e5e7eb',
                                cursor: 'pointer'
                              }}
                                onClick={() => { navigator.clipboard.writeText(value); toast.success('Berhasil disalin!') }}
                                title="Klik untuk salin"
                              >
                                {value}
                              </span>
                            </div>
                          )
                        })}
                      </div>
                      <p style={{ fontSize: 10, color: '#52525b', marginTop: 12, textAlign: 'center' }}>
                        💡 Klik nilai untuk menyalin. Simpan informasi ini baik-baik!
                      </p>
                    </div>
                  ) : (
                    /* Standard Receipt Display */
                    <>
                      <p style={{ fontSize: 11, color: '#6b7280', marginBottom: 4 }}>
                        {product.category?.toLowerCase() === 'ptero' ? 'Informasi Login Panel:' : 'Kode Resi / Serial:'}
                      </p>
                      <div style={{ 
                        fontFamily: 'monospace', 
                        fontSize: receipt?.includes('\n') ? 14 : 20, 
                        color: '#f59e0b', 
                        fontWeight: 900, 
                        letterSpacing: receipt?.includes('\n') ? 0 : 2,
                        whiteSpace: 'pre-wrap',
                        textAlign: receipt?.includes('\n') ? 'left' : 'center',
                        background: 'rgba(0,0,0,0.2)',
                        padding: '10px',
                        borderRadius: '8px'
                      }}>
                        {receipt || `TNKA-${Math.random().toString(36).substring(2, 8).toUpperCase()}`}
                      </div>
                    </>
                  )}
                </div>

                {/* Primary Asset */}
                {deliveryContent && (
                  <div className="cm-resi-box" style={{ borderColor: '#3b82f6', background: 'rgba(59,130,246,0.05)', marginBottom: '16px' }}>
                    <p style={{ fontSize: 11, color: '#60a5fa', marginBottom: 6, fontWeight: 700, textTransform: 'uppercase' }}>
                      🚀 {product.category === 'panel' ? 'Join Grup WhatsApp:' : (deliveryType === 'FILE' ? 'File Utama Siap:' : 'Link Download Utama:')}
                    </p>
                    <a href={deliveryContent} target="_blank" rel="noopener noreferrer" className="cm-btn-primary" style={{ display: 'block', textDecoration: 'none', textAlign: 'center', fontSize: '14px', padding: '10px', background: product.category === 'panel' ? '#25d366' : '#3b82f6' }}>
                      {product.category === 'panel' ? '📱 Gabung Grup WA' : (deliveryType === 'FILE' ? '📥 Download File (.zip/.7z)' : '🔗 Buka Link Utama')}
                    </a>
                  </div>
                )}

                {/* Secondary Asset (Link 2 / Telegram) */}
                {deliveryLink2 && (
                  <div className="cm-resi-box" style={{ borderColor: '#8b5cf6', background: 'rgba(139,92,246,0.05)', marginBottom: '24px' }}>
                    <p style={{ fontSize: 11, color: '#c084fc', marginBottom: 6, fontWeight: 700, textTransform: 'uppercase' }}>
                      {product.category === 'panel' ? '✈️ Join Grup Telegram:' : '✨ Link Tambahan / Update:'}
                    </p>
                    {deliveryLink2Desc && product.category !== 'panel' && (
                      <p style={{ fontSize: '12px', color: '#a1a1aa', marginBottom: '12px', lineHeight: '1.5' }}>
                        {deliveryLink2Desc}
                      </p>
                    )}
                    <a href={deliveryLink2} target="_blank" rel="noopener noreferrer" className="cm-btn-primary" style={{ display: 'block', textDecoration: 'none', textAlign: 'center', fontSize: '14px', padding: '10px', background: product.category === 'panel' ? '#0088cc' : '#8b5cf6' }}>
                      {product.category === 'panel' ? '✈️ Gabung Grup Telegram' : '🔗 Buka Link Tambahan'}
                    </a>
                  </div>
                )}

                <button className="cm-success-close" onClick={onClose}>Tutup & Selesai</button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  )
}
