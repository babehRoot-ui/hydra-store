'use client'
import { useEffect, useRef } from 'react'

// Saturn SVG component
function Saturn({ size = 100, style = {} }) {
  return (
    <svg width={size * 2.4} height={size * 1.5} viewBox="0 0 240 150" style={style}>
      {/* Ellipse ring back */}
      <ellipse cx="120" cy="80" rx="110" ry="22" fill="none" stroke="rgba(253,224,171,0.35)" strokeWidth="10" />
      {/* Planet */}
      <circle cx="120" cy="80" r="45" fill="url(#saturnGrad)" />
      {/* Bands */}
      <ellipse cx="120" cy="72" rx="42" ry="6" fill="rgba(0,0,0,0.12)" />
      <ellipse cx="120" cy="84" rx="38" ry="4" fill="rgba(0,0,0,0.09)" />
      {/* Ring front */}
      <path d="M 18 80 Q 120 108 222 80" stroke="rgba(253,224,171,0.5)" strokeWidth="10" fill="none" />
      <defs>
        <radialGradient id="saturnGrad" cx="38%" cy="35%">
          <stop offset="0%" stopColor="#fde68a" />
          <stop offset="60%" stopColor="#f59e0b" />
          <stop offset="100%" stopColor="#92400e" />
        </radialGradient>
      </defs>
    </svg>
  )
}

export default function SpaceBackground({ variant = 0 }) {
  const containerRef = useRef(null)

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    // Clear previous
    container.innerHTML = ''

    // ── Twinkle Stars ──────────────────────────
    const starCount = 55
    for (let i = 0; i < starCount; i++) {
      const star = document.createElement('div')
      star.className = 'star-dot'
      const size = Math.random() * 2.5 + 0.5
      star.style.cssText = `
        width: ${size}px; height: ${size}px;
        left: ${Math.random() * 100}%;
        top: ${Math.random() * 100}%;
        animation-duration: ${2 + Math.random() * 4}s;
        animation-delay: ${Math.random() * 4}s;
        opacity: ${0.15 + Math.random() * 0.5};
      `
      container.appendChild(star)
    }

    // ── Falling Stars ──────────────────────────
    const fallingCount = 7
    for (let i = 0; i < fallingCount; i++) {
      const s = document.createElement('div')
      s.className = 'falling-star'
      const delay = Math.random() * 12
      const duration = 4 + Math.random() * 6
      s.style.cssText = `
        left: ${10 + Math.random() * 80}%;
        top: ${-10 + Math.random() * 20}%;
        animation-duration: ${duration}s;
        animation-delay: ${delay}s;
        opacity: 0;
        width: ${1 + Math.random()}px;
        height: ${10 + Math.random() * 16}px;
      `
      container.appendChild(s)
    }

    return () => { if (container) container.innerHTML = '' }
  }, [variant])

  // Saturn position varies per variant
  const saturnPositions = [
    { bottom: '12%', right: '3%' },
    { top: '8%', left: '2%' },
    { bottom: '5%', left: '5%' },
    { top: '15%', right: '4%' },
  ]
  const pos = saturnPositions[variant % saturnPositions.length]

  return (
    <>
      {/* Twinkle + falling stars canvas */}
      <div ref={containerRef} style={{ position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0, overflow: 'hidden' }} />

      {/* Saturn */}
      <div className="saturn-wrapper" style={{ ...pos, opacity: 0.55 }}>
        <Saturn size={55} />
      </div>
    </>
  )
}
