'use client';
import { motion } from 'framer-motion';

import { useState, useEffect } from 'react';

export default function SpecialRobotBadge() {
  const [pose, setPose] = useState('wave');

  useEffect(() => {
    const poses = ['wave', 'cheer', 'look'];
    setPose(poses[Math.floor(Math.random() * poses.length)]);
  }, []);

  return (
    <div style={{
      position: 'absolute',
      top: '-65px', // Sit on top of the card
      right: '15px',
      zIndex: 10,
      pointerEvents: 'none',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center'
    }}>
      {/* Robot SVG */}
      <motion.div
        animate={
          pose === 'wave' ? { y: [0, -8, 0] } :
          pose === 'cheer' ? { y: [0, -15, 0], scale: [1, 1.05, 1] } :
          { y: [0, -4, 0], rotate: [-2, 2, -2] }
        }
        transition={{ repeat: Infinity, duration: pose === 'cheer' ? 1.5 : 3, ease: 'easeInOut' }}
        style={{ width: 65, height: 75 }}
      >
        <svg viewBox="0 0 100 120" style={{ width: '100%', height: '100%', overflow: 'visible' }}>
          <defs>
            <linearGradient id="specialRoboGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#c084fc" />
              <stop offset="100%" stopColor="#7c3aed" />
            </linearGradient>
            <filter id="specialGlow">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Antena */}
          <line x1="50" y1="15" x2="50" y2="0" stroke="#c084fc" strokeWidth="3" />
          <circle cx="50" cy="0" r="4" fill="#fbcfe8" filter="url(#specialGlow)" />

          {/* Kepala */}
          <motion.g
            animate={
              pose === 'look' ? { rotate: [-10, 10, -10] } :
              pose === 'cheer' ? { rotate: [-5, 5, -5], y: [-2, 2, -2] } :
              { rotate: [-5, 5, -5] }
            }
            transition={{ repeat: Infinity, duration: pose === 'look' ? 4 : 2, ease: 'easeInOut' }}
            style={{ transformOrigin: '50px 30px' }}
          >
            <rect x="25" y="15" width="50" height="35" rx="10" fill="#1e1b4b" stroke="#a855f7" strokeWidth="2" />
            {/* Mata bintang lucu */}
            <path d="M 40 28 l 2 -6 l 2 6 l 6 2 l -6 2 l -2 6 l -2 -6 l -6 -2 z" fill="#fbbf24" filter="url(#specialGlow)" />
            <path d="M 60 28 l 2 -6 l 2 6 l 6 2 l -6 2 l -2 6 l -2 -6 l -6 -2 z" fill="#fbbf24" filter="url(#specialGlow)" />
            {/* Mulut Senyum */}
            <path d="M 40 40 Q 50 48 60 40" stroke="#f472b6" strokeWidth="2" fill="none" strokeLinecap="round" />
          </motion.g>

          {/* Badan */}
          <rect x="30" y="50" width="40" height="40" rx="8" fill="url(#specialRoboGrad)" stroke="#d8b4fe" strokeWidth="2" />
          
          {/* Tangan Kiri memegang papan */}
          <motion.g animate={{ rotate: pose === 'cheer' ? 25 : 15 }} style={{ transformOrigin: '25px 60px' }}>
            <rect x="15" y="55" width="15" height="25" rx="7.5" fill="#312e81" stroke="#a855f7" strokeWidth="1.5" />
          </motion.g>

          {/* Tangan Kanan */}
          <motion.g
            animate={
              pose === 'wave' ? { rotate: [-30, -60, -30] } :
              pose === 'cheer' ? { rotate: [-150, -180, -150] } :
              { rotate: [0, -10, 0] }
            }
            transition={{ repeat: Infinity, duration: pose === 'wave' ? 1.5 : 1, ease: 'easeInOut' }}
            style={{ transformOrigin: '75px 60px' }}
          >
            <rect x="70" y="55" width="15" height="25" rx="7.5" fill="#312e81" stroke="#a855f7" strokeWidth="1.5" />
          </motion.g>
          
          {/* Kaki Kecil */}
          <rect x="35" y="90" width="10" height="15" rx="5" fill="#1e1b4b" />
          <rect x="55" y="90" width="10" height="15" rx="5" fill="#1e1b4b" />
        </svg>
      </motion.div>

      {/* Papan Hologram Produk Special */}
      <motion.div
        animate={{ y: [0, -3, 0], opacity: [0.8, 1, 0.8] }}
        transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut', delay: 0.5 }}
        style={{
          marginTop: '-35px',
          marginLeft: '-70px',
          background: 'rgba(236, 72, 153, 0.15)',
          border: '1px solid rgba(244, 114, 182, 0.5)',
          backdropFilter: 'blur(4px)',
          padding: '4px 10px',
          borderRadius: '8px',
          boxShadow: '0 0 15px rgba(236, 72, 153, 0.4)',
          transform: 'rotate(-5deg)'
        }}
      >
        <span style={{
          fontSize: '0.65rem',
          fontWeight: 800,
          color: '#fdf2f8',
          textShadow: '0 0 5px #f472b6',
          letterSpacing: '0.05em'
        }}>
          ✨ SPECIAL ✨
        </span>
      </motion.div>
    </div>
  );
}
