import './globals.css'
import Navbar from './Navbar'
import LiveFeed from './LiveFeed'
import AdPopup from './AdPopup'
import Marquee from './Marquee'
import { getSettings } from '@/lib/settings'

import PageTransitionWrapper from './PageTransitionWrapper'
import RobotMascot from './RobotMascot'
import GlobalBackground from './GlobalBackground'
import PersistentMusicPlayer from './PersistentMusicPlayer'
import { CartProvider } from '@/lib/CartContext'
import ToasterProvider from './ToasterProvider'

export const dynamic = 'force-dynamic'

import { DEFAULT_CATEGORIES } from '@/app/api/admin/categories/route'

export async function generateMetadata() {
  const settings = await getSettings(['STORE_NAME', 'STORE_TAGLINE'])
  return {
    title: `${settings.STORE_NAME || 'Tenka'} | ${settings.STORE_TAGLINE || 'Premium Digital Store'}`,
    description: 'Beli Script v3, SC cPanel, Bot dan panel dengan kualitas terbaik.',
  }
}

export default async function RootLayout({ children }) {
  const settings = await getSettings([
    'STORE_NAME', 
    'GLOBAL_BG_URL', 
    'GLOBAL_BG_TYPE', 
    'CONTACT_ADMIN_TEXT', 
    'CONTACT_ADMIN_LINK',
    'LINKBIO_NAME',
    'LINKBIO_SHOW',
    'WELCOME_MUSIC_URL',
    'CATEGORIES'
  ])
  const storeName = settings.STORE_NAME || 'Tenka'
  
  let customCategories = DEFAULT_CATEGORIES;
  try {
    if (settings.CATEGORIES) customCategories = JSON.parse(settings.CATEGORIES);
  } catch(e){}

  return (
    <html lang="id" suppressHydrationWarning>
      <body suppressHydrationWarning>
        <ToasterProvider />
        <CartProvider>
          <GlobalBackground url={settings.GLOBAL_BG_URL} type={settings.GLOBAL_BG_TYPE} />
          <AdPopup />
          <Navbar 
            storeName={storeName} 
            contactText={settings.CONTACT_ADMIN_TEXT} 
            contactLink={settings.CONTACT_ADMIN_LINK}
            linkBioName={settings.LINKBIO_NAME}
            linkBioShow={settings.LINKBIO_SHOW}
            categories={customCategories}
          />
          <PersistentMusicPlayer musicUrl={settings.WELCOME_MUSIC_URL} />
          <Marquee />
          <PageTransitionWrapper>
            {children}
          </PageTransitionWrapper>
          <RobotMascot />
          <LiveFeed />
          <footer style={{
            textAlign: 'center', padding: '3rem 0 2rem',
            borderTop: '1px solid rgba(255,255,255,0.05)', marginTop: '4rem'
          }}>
            <p style={{
              fontWeight: 700, fontSize: '1.25rem',
              background: 'linear-gradient(to right, #60a5fa, #c084fc, #34d399)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
              backgroundClip: 'text', marginBottom: '0.5rem'
            }}>{storeName}</p>
            <p style={{ color: '#52525b', fontSize: '0.875rem' }}>Premium Digital Store © 2025</p>
          </footer>
        </CartProvider>
      </body>
    </html>
  )
}
