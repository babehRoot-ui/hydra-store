'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useCart } from '@/lib/CartContext'

export default function Navbar({ storeName = 'Tenka', contactText, contactLink, linkBioName, linkBioShow, categories = [] }) {
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { cartCount } = useCart()

  const contactHref = contactLink 
    ? (contactLink.startsWith('http') || contactLink.startsWith('mailto:') ? contactLink : `https://wa.me/${contactLink}`)
    : null;

  const scrollToCheckout = () => {
    const el = document.getElementById('checkout-section')
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }

  return (
    <nav style={{
      margin: '1.5rem auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      borderRadius: '9999px', padding: '1rem 2.5rem', position: 'sticky', top: '1.5rem', zIndex: 50,
      background: 'rgba(255,255,255,0.03)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)',
      border: '1px solid rgba(255,255,255,0.08)', maxWidth: '1540px', width: 'calc(100% - 3rem)'
    }}>
      <Link href="/" style={{ textDecoration: 'none' }}>
        <span style={{
          fontSize: '1.5rem', fontWeight: 800,
          background: 'linear-gradient(to right, #60a5fa, #c084fc, #34d399)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text'
        }}>{storeName}</span>
      </Link>

      {/* Desktop Menu */}
      <div className="nav-menu-desktop" style={{ display: 'flex', gap: '0.25rem', alignItems: 'center' }}>
        {linkBioShow === 'yes' && (
          <NavLink href="/links">
            <span style={{ marginRight: '0.4rem' }}>🔗</span>
            {linkBioName || 'Connect'}
          </NavLink>
        )}
        <NavLink href="/">Beranda</NavLink>

        <div style={{ position: 'relative' }}>
          <button
            onClick={() => setDropdownOpen(v => !v)}
            onBlur={() => setTimeout(() => setDropdownOpen(false), 150)}
            style={{
              background: 'transparent', border: 'none', color: dropdownOpen ? 'white' : '#a1a1aa',
              cursor: 'pointer', fontFamily: 'inherit', fontWeight: 500, fontSize: '0.95rem',
              padding: '0.5rem 0.875rem', borderRadius: '0.5rem', display: 'flex', alignItems: 'center',
              gap: '0.3rem', transition: 'color 0.2s', background: dropdownOpen ? 'rgba(255,255,255,0.05)' : 'transparent'
            }}
          >
            Kategori <span style={{ fontSize: '0.65rem', transition: 'transform 0.2s', transform: dropdownOpen ? 'rotate(180deg)' : 'none' }}>▼</span>
          </button>

          {dropdownOpen && (
            <div style={{
              position: 'absolute', top: 'calc(100% + 0.5rem)', left: '50%', transform: 'translateX(-50%)',
              background: 'rgba(10,10,10,0.97)', backdropFilter: 'blur(20px)', border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: '1rem', padding: '0.5rem', minWidth: '220px', zIndex: 100,
              boxShadow: '0 20px 40px -10px rgba(0,0,0,0.8)'
            }}>
              {categories.map(cat => {
                const isPage = false // Legacy support removed
                const href = isPage ? `/${cat.slug}` : `/kategori/${cat.slug}`
                return (
                  <Link key={cat.slug} href={href}
                    onClick={() => setDropdownOpen(false)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: '0.75rem',
                      padding: '0.6rem 0.875rem', borderRadius: '0.75rem', color: '#a1a1aa',
                      textDecoration: 'none', fontSize: '0.9rem', fontWeight: 500, transition: 'all 0.15s'
                    }}
                    onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.06)'; e.currentTarget.style.color = 'white' }}
                    onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#a1a1aa' }}
                  >
                    <span>{cat.icon}</span>{cat.label}
                  </Link>
                )
              })}
            </div>
          )}
        </div>

        <NavLink href="/track">Track Order</NavLink>
        <NavLink href="/admin">Admin</NavLink>

        <button 
          onClick={scrollToCheckout}
          style={{
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: '9999px',
            padding: '0.5rem 1rem',
            color: 'white',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            cursor: 'pointer',
            position: 'relative',
            marginLeft: '0.5rem'
          }}
        >
          <span style={{ fontSize: '1.1rem' }}>🛒</span>
          {cartCount > 0 && (
            <span style={{
              position: 'absolute', top: '-5px', right: '-5px',
              background: '#ef4444', color: 'white', fontSize: '0.7rem',
              fontWeight: 800, padding: '2px 6px', borderRadius: '9999px',
              border: '2px solid rgba(0,0,0,0.5)'
            }}>{cartCount}</span>
          )}
          <span style={{ fontSize: '0.9rem', fontWeight: 600 }}>Keranjang</span>
        </button>
        
        {contactHref && (
          <a 
            href={contactHref} 
            target="_blank" 
            rel="noopener noreferrer"
            style={{
              marginLeft: '0.5rem',
              background: 'linear-gradient(135deg, #10b981, #059669)',
              color: 'white',
              fontWeight: 600,
              fontSize: '0.9rem',
              textDecoration: 'none',
              padding: '0.5rem 1rem',
              borderRadius: '9999px',
              display: 'flex',
              alignItems: 'center',
              gap: '0.4rem',
              transition: 'transform 0.2s, box-shadow 0.2s',
            }}
            onMouseEnter={e => {
              e.currentTarget.style.transform = 'translateY(-1px)'
              e.currentTarget.style.boxShadow = '0 4px 15px rgba(16, 185, 129, 0.4)'
            }}
            onMouseLeave={e => {
              e.currentTarget.style.transform = 'none'
              e.currentTarget.style.boxShadow = 'none'
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
            </svg>
            {contactText || 'Hubungi Admin'}
          </a>
        )}
      </div>

      {/* Mobile Menu Toggle */}
      <button 
        className="nav-menu-mobile-toggle"
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        style={{ 
          display: 'none', background: 'transparent', border: 'none', color: 'white', 
          fontSize: '1.5rem', cursor: 'pointer' 
        }}
      >
        {mobileMenuOpen ? '✕' : '☰'}
      </button>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div style={{
          position: 'fixed', top: '5.5rem', left: '1rem', right: '1rem',
          background: 'rgba(10,10,10,0.95)', backdropFilter: 'blur(20px)',
          border: '1px solid rgba(255,255,255,0.1)', borderRadius: '1.5rem',
          padding: '2rem 1.5rem', zIndex: 100, display: 'flex', flexDirection: 'column', gap: '1.5rem',
          boxShadow: '0 25px 60px rgba(0,0,0,0.9)',
          animation: 'fadeInDown 0.4s cubic-bezier(0.16, 1, 0.3, 1)'
        }}>
          <Link href="/" onClick={() => setMobileMenuOpen(false)} style={S.mobileLink}>🏠 Beranda</Link>
          {linkBioShow === 'yes' && (
            <Link href="/links" onClick={() => setMobileMenuOpen(false)} style={S.mobileLink}>🔗 {linkBioName || 'Connect'}</Link>
          )}
          <div style={{ padding: '0.5rem 0', borderBottom: '1px solid rgba(255,255,255,0.05)', fontSize: '0.7rem', color: '#71717a', fontWeight: 800, letterSpacing: '0.1em' }}>KATEGORI</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            {categories.map(cat => (
              <Link 
                key={cat.slug} 
                href={`/kategori/${cat.slug}`} 
                onClick={() => setMobileMenuOpen(false)} 
                style={S.mobileGridLink}
              >
                {cat.icon} {cat.label.split(' ')[0]}
              </Link>
            ))}
          </div>
          <div style={{ borderTop: '1px solid rgba(255,255,255,0.05)', paddingTop: '1.5rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            <Link href="/track" onClick={() => setMobileMenuOpen(false)} style={S.mobileLink}>🔍 Track Order</Link>
            <Link href="/admin" onClick={() => setMobileMenuOpen(false)} style={S.mobileLink}>🛡️ Dashboard Admin</Link>
            {contactHref && (
              <a 
                href={contactHref} 
                target="_blank" 
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
                style={{
                  ...S.mobileLink,
                  background: 'linear-gradient(135deg, #10b981, #059669)',
                  display: 'flex', alignItems: 'center', gap: '0.5rem', justifyContent: 'center'
                }}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                </svg>
                {contactText || 'Hubungi Admin'}
              </a>
            )}
          </div>
        </div>
      )}

      <style jsx>{`
        @media (max-width: 768px) {
          .nav-menu-desktop { display: none !important; }
          .nav-menu-mobile-toggle { display: block !important; }
        }
      `}</style>
    </nav>
  )
}

function NavLink({ href, children }) {
  return (
    <Link href={href} style={{
      color: '#a1a1aa', fontWeight: 500, fontSize: '0.95rem', textDecoration: 'none',
      padding: '0.5rem 0.875rem', borderRadius: '0.5rem', transition: 'all 0.2s'
    }}
      onMouseEnter={e => { e.currentTarget.style.color = 'white'; e.currentTarget.style.background = 'rgba(255,255,255,0.05)' }}
      onMouseLeave={e => { e.currentTarget.style.color = '#a1a1aa'; e.currentTarget.style.background = 'transparent' }}
    >
      {children}
    </Link>
  )
}

const S = {
  mobileLink: {
    display: 'block', padding: '0.75rem 1rem', color: 'white', textDecoration: 'none',
    fontWeight: 600, borderRadius: '0.75rem', fontSize: '1rem', transition: 'background 0.2s'
  },
  mobileGridLink: {
    padding: '0.6rem', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)',
    borderRadius: '0.75rem', color: '#a1a1aa', textDecoration: 'none', fontSize: '0.85rem', fontWeight: 500,
    textAlign: 'center'
  }
}
