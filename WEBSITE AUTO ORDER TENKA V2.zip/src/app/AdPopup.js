'use client'
import { useState, useEffect } from 'react'

export default function AdPopup() {
  const [show, setShow] = useState(false)

  useEffect(() => {
    const closed = sessionStorage.getItem('tenka_ad_closed')
    if (!closed) {
      const timer = setTimeout(() => setShow(true), 2000)
      return () => clearTimeout(timer)
    }
  }, [])

  const close = () => {
    setShow(false)
    sessionStorage.setItem('tenka_ad_closed', '1')
  }

  if (!show) return null

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 1000,
      background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '1.5rem', animation: 'fade-in 0.3s ease'
    }}>
      <div className="glass-card" style={{
        maxWidth: '500px', width: '100%', padding: '2.5rem', position: 'relative',
        animation: 'zoom-in 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)'
      }}>
        <button 
          onClick={close}
          style={{
            position: 'absolute', top: '1.25rem', right: '1.25rem',
            background: 'rgba(255,255,255,0.05)', border: 'none', color: '#a1a1aa',
            width: '2.5rem', height: '2.5rem', borderRadius: '50%', cursor: 'pointer'
          }}
        >
          ✕
        </button>

        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '3.5rem', marginBottom: '1rem' }}>🚀</div>
          <h2 style={{ fontSize: '1.75rem', fontWeight: 800, marginBottom: '1rem' }}>
            Selamat Datang di <span className="text-gradient">Tenka Store</span>
          </h2>
          <p style={{ color: '#a1a1aa', lineHeight: 1.6, marginBottom: '2rem' }}>
            Dapatkan Script Bot WhatsApp, Panel Reseller, dan Layanan CPanel terbaik dengan sistem pembayaran otomatis 24/7.
          </p>
          
          <div style={{ 
            display: 'flex', flexDirection: 'column', gap: '0.75rem', 
            background: 'rgba(59,130,246,0.05)', padding: '1.25rem', 
            borderRadius: '1rem', border: '1px solid rgba(59,130,246,0.2)',
            textAlign: 'left', fontSize: '0.9rem'
          }}>
            <p>✅ <b>Otomatis:</b> Status order terupdate dalam hitungan detik.</p>
            <p>✅ <b>Lengkap:</b> Dari script hingga panel pterodactyl.</p>
            <p>✅ <b>Aman:</b> Menggunakan gateway Pakasir resmi.</p>
          </div>

          <button 
            onClick={close}
            className="btn btn-primary"
            style={{ width: '100%', marginTop: '2rem', padding: '1rem' }}
          >
            Mulai Belanja
          </button>
        </div>
      </div>

    </div>
  )
}
