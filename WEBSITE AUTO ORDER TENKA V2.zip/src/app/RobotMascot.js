'use client'
import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { usePathname } from 'next/navigation'

export default function RobotMascot() {
  const pathname = usePathname()
  const [currentPose, setCurrentPose] = useState('float')
  
  // Acak pose setiap kali pindah halaman
  useEffect(() => {
    const poses = ['sit-moon', 'wave', 'float', 'fly', 'swing']
    const randomPose = poses[Math.floor(Math.random() * poses.length)]
    setCurrentPose(randomPose)
  }, [pathname])

  const wrapperBase = {
    position: 'fixed', bottom: '4rem', zIndex: 50, pointerEvents: 'none',
    right: '1.5rem',
  }

  return (
    <motion.div 
      layoutId="global-robot-mascot"
      style={wrapperBase}
      initial={{ opacity: 0, scale: 0.5 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ type: 'spring', damping: 20, stiffness: 100 }}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={currentPose}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          {currentPose === 'sit-moon' && <HoverHologram />}
          {currentPose === 'wave'     && <WaveRobot />}
          {currentPose === 'float'    && <FloatRobot />}
          {currentPose === 'fly'      && <FlyingRobot />}
          {currentPose === 'swing'    && <SwingRobot />}
        </motion.div>
      </AnimatePresence>
    </motion.div>
  )
}

/* ── Shared robot SVG parts ── */
function RobotSVG({ leftLegAnim, rightLegAnim, leftArmAnim, rightArmAnim, bodyAnim, scale = 1, smile = false }) {
  const s = { display: 'block' }
  return (
    <svg width={80 * scale} height={100 * scale} viewBox="0 0 80 100" style={s}>
      {/* Body */}
      <g style={bodyAnim}>
        {/* Torso */}
        <rect x="20" y="35" width="40" height="36" rx="8" fill="#1e293b" stroke="#3b82f6" strokeWidth="1.5" />
        {/* Chest light */}
        <circle cx="40" cy="53" r="5" fill="#60a5fa" style={{ filter: 'drop-shadow(0 0 4px #3b82f6)' }} />
        <rect x="28" y="62" width="8" height="4" rx="2" fill="#334155" />
        <rect x="44" y="62" width="8" height="4" rx="2" fill="#334155" />

        {/* Head */}
        <rect x="22" y="10" width="36" height="28" rx="10" fill="#0f172a" stroke="#8b5cf6" strokeWidth="1.5" />
        
        {/* Eyes (Bisa tersenyum) */}
        {!smile ? (
          <>
            <circle cx="32" cy="22" r="5" fill="#1e293b" />
            <circle cx="32" cy="22" r="3" fill="#60a5fa" style={{ filter: 'drop-shadow(0 0 4px #60a5fa)' }} />
            <circle cx="48" cy="22" r="5" fill="#1e293b" />
            <circle cx="48" cy="22" r="3" fill="#60a5fa" style={{ filter: 'drop-shadow(0 0 4px #60a5fa)' }} />
          </>
        ) : (
          <>
            <path d="M 28 24 Q 32 18 36 24" stroke="#60a5fa" strokeWidth="2.5" fill="none" strokeLinecap="round" style={{ filter: 'drop-shadow(0 0 4px #60a5fa)' }} />
            <path d="M 44 24 Q 48 18 52 24" stroke="#60a5fa" strokeWidth="2.5" fill="none" strokeLinecap="round" style={{ filter: 'drop-shadow(0 0 4px #60a5fa)' }} />
          </>
        )}

        {/* Mouth */}
        {!smile ? (
          <path d="M 30 31 Q 40 36 50 31" stroke="#94a3b8" strokeWidth="1.5" fill="none" strokeLinecap="round" />
        ) : (
          <path d="M 32 30 Q 40 38 48 30" stroke="#f472b6" strokeWidth="2" fill="none" strokeLinecap="round" />
        )}

        {/* Antenna */}
        <line x1="40" y1="10" x2="40" y2="2" stroke="#8b5cf6" strokeWidth="2" strokeLinecap="round" />
        <circle cx="40" cy="2" r="3" fill="#c084fc" style={{ filter: 'drop-shadow(0 0 3px #8b5cf6)' }} />

        {/* Left arm */}
        <g style={{ transformOrigin: '20px 42px', ...leftArmAnim }}>
          <rect x="8" y="38" width="13" height="22" rx="6" fill="#1e293b" stroke="#3b82f6" strokeWidth="1.2" />
          <circle cx="14.5" cy="62" r="4" fill="#334155" />
        </g>
        {/* Right arm */}
        <g style={{ transformOrigin: '60px 42px', ...rightArmAnim }}>
          <rect x="59" y="38" width="13" height="22" rx="6" fill="#1e293b" stroke="#3b82f6" strokeWidth="1.2" />
          <circle cx="65.5" cy="62" r="4" fill="#334155" />
        </g>
      </g>

      {/* Left leg */}
      <g style={{ transformOrigin: '30px 71px', ...leftLegAnim }}>
        <rect x="24" y="70" width="12" height="20" rx="6" fill="#0f172a" stroke="#8b5cf6" strokeWidth="1.2" />
        <rect x="20" y="87" width="16" height="7" rx="3" fill="#1e293b" />
      </g>
      {/* Right leg */}
      <g style={{ transformOrigin: '50px 71px', ...rightLegAnim }}>
        <rect x="44" y="70" width="12" height="20" rx="6" fill="#0f172a" stroke="#8b5cf6" strokeWidth="1.2" />
        <rect x="44" y="87" width="16" height="7" rx="3" fill="#1e293b" />
      </g>
    </svg>
  )
}

/* ── Pose 1: Hover over hologram moon ── */
function HoverHologram() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <div style={{ animation: 'robot-float 2.5s ease-in-out infinite' }}>
        <RobotSVG
          bodyAnim={{}}
          leftLegAnim={{ animation: 'robot-swing-legs 1.2s ease-in-out infinite' }}
          rightLegAnim={{ animation: 'robot-swing-legs 1.2s ease-in-out infinite reverse' }}
          leftArmAnim={{}}
          rightArmAnim={{}}
          smile={true}
        />
      </div>
      <svg width="100" height="40" viewBox="0 0 100 40" style={{ marginTop: '-10px', animation: 'hologram-flicker 4s infinite step-end' }}>
        <defs>
          <linearGradient id="holoGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="rgba(59,130,246,0)" />
            <stop offset="50%" stopColor="rgba(59,130,246,0.5)" />
            <stop offset="100%" stopColor="rgba(139,92,246,0.8)" />
          </linearGradient>
          <pattern id="holoLines" width="100%" height="3" patternUnits="userSpaceOnUse">
            <line x1="0" y1="0" x2="100" y2="0" stroke="rgba(255,255,255,0.15)" strokeWidth="1" />
          </pattern>
        </defs>
        <ellipse cx="50" cy="20" rx="45" ry="12" fill="url(#holoLines)" stroke="rgba(59,130,246,0.4)" strokeWidth="1" />
        <ellipse cx="50" cy="20" rx="40" ry="10" fill="url(#holoGrad)" opacity="0.6" />
        <ellipse cx="50" cy="22" rx="48" ry="14" fill="rgba(59,130,246,0.2)" style={{ filter: 'blur(6px)' }} />
      </svg>
    </div>
  )
}

/* ── Pose 2: Waving robot ── */
function WaveRobot() {
  return (
    <div style={{ animation: 'robot-float 2.5s ease-in-out infinite' }}>
      <RobotSVG
        bodyAnim={{}}
        leftLegAnim={{ animation: 'robot-swing-legs 0.8s ease-in-out infinite', animationDelay: '0.2s' }}
        rightLegAnim={{ animation: 'robot-swing-legs 0.8s ease-in-out infinite reverse', animationDelay: '0.2s' }}
        leftArmAnim={{ animation: 'robot-wave 0.6s ease-in-out infinite' }}
        rightArmAnim={{}}
        smile={true}
      />
    </div>
  )
}

/* ── Pose 3: Floating robot ── */
function FloatRobot() {
  return (
    <div style={{ animation: 'robot-float 2s ease-in-out infinite' }}>
      <RobotSVG
        bodyAnim={{}}
        leftLegAnim={{ animation: 'robot-swing-legs 1.4s ease-in-out infinite', animationDelay: '0.3s' }}
        rightLegAnim={{ animation: 'robot-swing-legs 1.4s ease-in-out infinite reverse', animationDelay: '0.3s' }}
        leftArmAnim={{ animation: 'robot-wave 1.8s ease-in-out infinite', animationDelay: '0.4s' }}
        rightArmAnim={{ animation: 'robot-wave 1.8s ease-in-out infinite reverse', animationDelay: '0.4s' }}
      />
    </div>
  )
}

/* ── Pose 4: Flying robot ── */
function FlyingRobot() {
  return (
    <div style={{ animation: 'robot-float 1.5s ease-in-out infinite', transform: 'rotate(-20deg)' }}>
      <RobotSVG
        bodyAnim={{}}
        leftLegAnim={{ transform: 'rotate(30deg)' }}
        rightLegAnim={{ transform: 'rotate(-15deg)' }}
        leftArmAnim={{ transform: 'rotate(-40deg)' }}
        rightArmAnim={{ transform: 'rotate(40deg)' }}
        scale={0.9}
        smile={true}
      />
    </div>
  )
}

/* ── Pose 5: Ayunan (Swing) ── */
function SwingRobot() {
  return (
    <div style={{ position: 'relative', width: 100, height: 160, display: 'flex', justifyContent: 'center' }}>
      <motion.div 
        animate={{ rotate: [-10, 10, -10] }}
        transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
        style={{ transformOrigin: 'top center', position: 'absolute', top: '-100px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}
      >
        {/* Tali ayunan */}
        <svg width="60" height="150" style={{ position: 'absolute', top: 0, zIndex: 0 }}>
          <line x1="10" y1="0" x2="10" y2="150" stroke="rgba(255,255,255,0.2)" strokeWidth="2" />
          <line x1="50" y1="0" x2="50" y2="150" stroke="rgba(255,255,255,0.2)" strokeWidth="2" />
          <rect x="0" y="145" width="60" height="10" rx="3" fill="#334155" stroke="#475569" strokeWidth="2" />
        </svg>

        {/* Robot Duduk di Ayunan */}
        <div style={{ marginTop: '55px', zIndex: 1 }}>
          <RobotSVG
            bodyAnim={{}}
            leftLegAnim={{ animation: 'robot-swing-legs 1.5s ease-in-out infinite', animationDelay: '0s' }}
            rightLegAnim={{ animation: 'robot-swing-legs 1.5s ease-in-out infinite reverse', animationDelay: '0.2s' }}
            leftArmAnim={{ transform: 'rotate(-30deg)' }} // Pegang tali
            rightArmAnim={{ transform: 'rotate(30deg)' }}  // Pegang tali
            smile={true}
          />
        </div>
      </motion.div>
    </div>
  )
}
