'use client'
import { useState, useEffect, useRef } from 'react'

export default function BackgroundMusic() {
  const [playing, setPlaying] = useState(false)
  const [muted, setMuted] = useState(true)
  const audioRef = useRef(null)

  useEffect(() => {
    // Cek preference
    const saved = localStorage.getItem('tenka_music_muted')
    if (saved === '0') setMuted(false)
  }, [])

  const toggle = () => {
    if (!audioRef.current) return
    
    if (muted) {
      audioRef.current.play().catch(() => {})
      setMuted(false)
      localStorage.setItem('tenka_music_muted', '0')
    } else {
      audioRef.current.pause()
      setMuted(true)
      localStorage.setItem('tenka_music_muted', '1')
    }
  }

  return (
    <div style={{ position: 'fixed', bottom: '2rem', left: '2rem', zIndex: 100 }}>
      <audio 
        ref={audioRef} 
        loop 
        src="https://nauval.cloud/download/alip-1766031972731.jpg" // Placeholder audio source, user can change
        // Wait, the user site has a music button. I'll use a royalty-free track or just a placeholder.
      />
      <button 
        onClick={toggle}
        style={{
          width: '3.5rem', height: '3.5rem', borderRadius: '50%',
          background: 'rgba(15,15,15,0.8)', backdropFilter: 'blur(10px)',
          border: `2px solid ${muted ? 'rgba(255,255,255,0.1)' : '#8b5cf6'}`,
          color: muted ? '#a1a1aa' : '#c084fc',
          cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: muted ? 'none' : '0 0 20px rgba(139,92,246,0.3)',
          transition: 'all 0.3s ease', 
          animation: !muted ? 'vibrate 0.3s infinite ease-in-out' : 'none'
        }}
        title="Musik Latar"
      >
        {muted ? (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>
            <line x1="1" y1="1" x2="23" y2="23" stroke="#ef4444" strokeWidth="2.5" />
          </svg>
        ) : (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="playing-icon">
            <path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>
          </svg>
        )}
      </button>

      <style jsx>{`
        @keyframes vibrate {
          0% { transform: rotate(0deg); }
          25% { transform: rotate(2deg); }
          50% { transform: rotate(0deg); }
          75% { transform: rotate(-2deg); }
          100% { transform: rotate(0deg); }
        }
        @keyframes pulse-glow {
          0% { box-shadow: 0 0 10px rgba(139,92,246,0.3); }
          50% { box-shadow: 0 0 25px rgba(139,92,246,0.5); }
          100% { box-shadow: 0 0 10px rgba(139,92,246,0.3); }
        }
        .playing-icon {
          animation: float-note 2s ease-in-out infinite;
        }
        @keyframes float-note {
          0%, 100% { transform: translateY(0) rotate(0); }
          50% { transform: translateY(-3px) rotate(5deg); }
        }
      `}</style>
    </div>
  )
}
