'use client'

import { Toaster } from 'react-hot-toast'

export default function ToasterProvider() {
  return (
    <Toaster
      position="top-center"
      reverseOrder={false}
      gutter={12}
      toastOptions={{
        // Styling dasar untuk semua jenis notifikasi
        className: '',
        duration: 4000,
        style: {
          background: 'rgba(15, 23, 42, 0.85)',
          backdropFilter: 'blur(12px)',
          WebkitBackdropFilter: 'blur(12px)',
          color: '#fff',
          border: '1px solid rgba(255, 255, 255, 0.08)',
          boxShadow: '0 10px 40px rgba(0, 0, 0, 0.4)',
          borderRadius: '100px', // Bentuk pil modern
          padding: '12px 24px',
          fontSize: '0.9rem',
          fontWeight: 700,
          letterSpacing: '0.02em',
        },
        success: {
          icon: '✨',
          style: {
            border: '1px solid rgba(16, 217, 129, 0.3)',
            background: 'linear-gradient(90deg, rgba(16,217,129,0.1) 0%, rgba(15,23,42,0.9) 100%)',
            boxShadow: '0 8px 32px rgba(16, 217, 129, 0.15)',
            color: '#34d399'
          },
          iconTheme: {
            primary: '#10b981',
            secondary: '#fff',
          },
        },
        error: {
          icon: '🚨',
          duration: 5000,
          style: {
            border: '1px solid rgba(239, 68, 68, 0.3)',
            background: 'linear-gradient(90deg, rgba(239,68,68,0.1) 0%, rgba(15,23,42,0.9) 100%)',
            boxShadow: '0 8px 32px rgba(239, 68, 68, 0.15)',
            color: '#f87171'
          },
          iconTheme: {
            primary: '#ef4444',
            secondary: '#fff',
          },
        },
      }}
    />
  )
}
