'use client'
import { useState, useEffect } from 'react'

export default function TransactionFeed() {
  const [data, setData] = useState([])

  useEffect(() => {
    fetch('/api/feed')
      .then(r => r.json())
      .then(j => { setData(j.slice(0, 10)) })
      .catch(() => setData([]))
  }, [])

  return (
    <section className="container" style={{ marginBottom: '6rem' }}>
      <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>⚡ Riwayat Transaksi</h2>
        <p className="text-secondary" style={{ marginTop: '0.4rem' }}>Update otomatis dari sistem Tenka</p>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
          {data.length === 0 ? (
            <div style={{ padding: '3rem', textAlign: 'center', color: '#52525b' }}>
              <p>Belum ada transaksi terbaru.</p>
            </div>
          ) : data.map((item, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              padding: '1.25rem 1.5rem', borderBottom: '1px solid rgba(255,255,255,0.05)',
              animation: `fadeIn 0.5s ease both ${i * 0.1}s`
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <div style={{ 
                  width: '2.5rem', height: '2.5rem', borderRadius: '50%', background: 'rgba(59,130,246,0.1)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1rem'
                }}>
                  🛒
                </div>
                <div>
                  <h4 style={{ fontSize: '0.95rem', fontWeight: 600 }}>{item.label}</h4>
                  <p style={{ fontSize: '0.8rem', color: '#52525b' }}>
                    {item.username || 'user***'} • {new Date(item.ts).toLocaleTimeString('id-ID')}
                  </p>
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <p style={{ fontWeight: 800, color: '#10b981' }}>
                  {item.amount === 0 ? 'GRATIS' : `Rp ${item.amount.toLocaleString('id-ID')}`}
                </p>
                <span style={{ fontSize: '0.7rem', padding: '0.1rem 0.5rem', background: 'rgba(16,185,129,0.1)', color: '#10b981', borderRadius: '9999px', border: '1px solid rgba(16,185,129,0.2)' }}>SUCCESS</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
