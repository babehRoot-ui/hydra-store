import { prisma } from '@/lib/prisma'
import ClientSpaceBackground from '@/app/ClientSpaceBackground'

export const dynamic = 'force-dynamic';

export default async function TrackPage({ searchParams }) {
  const { q } = await searchParams
  let orders = []
  let error = null

  if (q) {
    orders = await prisma.order.findMany({
      where: {
        OR: [
          { id: q },
          { customerPhone: q },
          { customerPhone: q.startsWith('0') ? '62' + q.slice(1) : q }
        ]
      },
      include: { product: true },
      orderBy: { createdAt: 'desc' }
    })
    
    if (orders.length === 0) error = "Data tidak ditemukan. Pastikan ID atau Nomor WA benar."
  }

  return (
    <main style={{ paddingBottom: '8rem', position: 'relative', minHeight: '100vh' }}>
      <ClientSpaceBackground variant={1} />
      
      <section className="container text-center" style={{ padding: '6rem 0 3rem', position: 'relative', zIndex: 2 }}>
        <h1 style={{ fontSize: '3rem', fontWeight: 800, marginBottom: '1.5rem' }}>
          <span className="text-gradient">Track Order</span>
        </h1>
        <p className="text-secondary" style={{ maxWidth: '500px', margin: '0 auto 2.5rem' }}>
          Masukkan Order ID atau Nomor WhatsApp Anda untuk melihat riwayat pesanan.
        </p>

        <form action="/track" method="GET" className="glass-card" style={{ maxWidth: '500px', margin: '0 auto', display: 'flex', gap: '0.5rem' }}>
          <input 
            type="text" 
            name="q" 
            placeholder="Order ID / Nomor WA (0812...)" 
            className="input" 
            defaultValue={q || ''}
            required 
          />
          <button type="submit" className="btn btn-primary">Cari</button>
        </form>
      </section>

      {error && (
        <section className="container text-center" style={{ position: 'relative', zIndex: 2 }}>
          <div className="glass-card" style={{ maxWidth: '500px', margin: '0 auto', borderColor: '#ef4444' }}>
            <p style={{ color: '#ef4444' }}>{error}</p>
          </div>
        </section>
      )}

      {orders.length > 0 && (
        <section className="container" style={{ position: 'relative', zIndex: 2, marginTop: '2rem' }}>
          <div className="flex flex-col gap-6" style={{ maxWidth: '700px', margin: '0 auto' }}>
            {orders.map(order => (
              <div key={order.id} className="glass-card" style={{ padding: '2rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem', borderBottom: '1px solid var(--card-border)', paddingBottom: '1rem' }}>
                  <div>
                    <h3 style={{ fontSize: '1.1rem', fontWeight: 700 }}>{order.product.name}</h3>
                    <p className="text-secondary" style={{ fontSize: '0.8rem', fontFamily: 'monospace' }}>ID: {order.id}</p>
                  </div>
                  <span style={{ 
                    padding: '0.2rem 0.75rem', borderRadius: '9999px', fontSize: '0.75rem', fontWeight: 700,
                    background: order.status === 'SUCCESS' ? 'rgba(16,185,129,0.1)' : 'rgba(245,158,11,0.1)',
                    color: order.status === 'SUCCESS' ? '#10b981' : '#f59e0b',
                    border: `1px solid ${order.status === 'SUCCESS' ? '#10b981' : '#f59e0b'}`
                  }}>
                    {order.status}
                  </span>
                </div>
                
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
                    <div>
                        <p className="text-secondary" style={{ fontSize: '0.75rem' }}>WAKTU PEMBELIAN</p>
                        <p style={{ fontSize: '0.9rem' }}>{new Date(order.createdAt).toLocaleString('id-ID')}</p>
                    </div>
                    <div>
                        <p className="text-secondary" style={{ fontSize: '0.75rem' }}>TOTAL PEMBAYARAN</p>
                        <p style={{ fontSize: '0.9rem', fontWeight: 700, color: '#10b981' }}>Rp {order.amount.toLocaleString('id-ID')}</p>
                    </div>
                </div>

                <div style={{ 
                    padding: '1.25rem', background: 'rgba(59,130,246,0.05)', borderRadius: '0.75rem', 
                    border: '1px dashed var(--primary-color)', textAlign: 'center'
                }}>
                  <p className="text-secondary" style={{ fontSize: '0.75rem', marginBottom: '0.5rem' }}>KODE RESI / AKSES</p>
                  <h3 style={{ fontSize: '1.25rem', fontWeight: 800, letterSpacing: '2px', color: '#60a5fa' }}>
                    {order.receiptCode || 'Menunggu Konfirmasi...'}
                  </h3>
                </div>

                {order.status === 'SUCCESS' && order.product?.deliveryContent && (
                  <div style={{ 
                    marginTop: '1.5rem', padding: '1.25rem', background: 'rgba(16,185,129,0.08)', 
                    borderRadius: '0.75rem', border: '1px solid #10b981'
                  }}>
                    <p style={{ fontSize: '0.75rem', color: '#10b981', fontWeight: 700, marginBottom: '0.75rem', textTransform: 'uppercase' }}>
                      🚀 Produk Digital Anda Siap:
                    </p>
                    <div style={{ background: 'rgba(0,0,0,0.2)', padding: '0.75rem', borderRadius: '0.5rem', marginBottom: '1rem', border: '1px solid rgba(255,255,255,0.05)' }}>
                       <p style={{ color: '#fff', fontSize: '0.85rem', wordBreak: 'break-all', fontFamily: 'monospace' }}>
                         {order.product.deliveryContent}
                       </p>
                    </div>
                    <a 
                      href={order.product.deliveryContent} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="btn btn-primary"
                      style={{ display: 'block', textDecoration: 'none', textAlign: 'center', fontSize: '0.9rem' }}
                    >
                      {order.product.deliveryType === 'FILE' ? '📥 Download File' : '🔗 Buka Link Produk'}
                    </a>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      )}
    </main>
  )
}
