'use client'
import { useState } from 'react'
import Link from 'next/link'

function BadgePill({ badge }) {
  const colors = { HOT: '#ef4444', NEW: '#10b981', SALE: '#f59e0b', LIMITED: '#8b5cf6' }
  return (
    <span className={badge === 'HOT' ? 'badge-hot' : ''} style={{
      background: colors[badge] || '#8b5cf6', color: 'white',
      fontSize: '0.7rem', fontWeight: 700, padding: '0.2rem 0.65rem', borderRadius: '9999px'
    }}>{badge}</span>
  )
}

export default function ProductCarousel({ products, onBuy }) {
  const [current, setCurrent] = useState(0)
  const [dir, setDir] = useState('right')

  const go = (direction) => {
    setDir(direction)
    setCurrent(prev => {
      if (direction === 'right') return (prev + 1) % products.length
      return (prev - 1 + products.length) % products.length
    })
  }

  const p = products[current]
  const featureList = (() => { try { return JSON.parse(p.features || '[]') } catch { return [] } })()

  return (
    <div style={{ position: 'relative' }}>
      {/* Progress dots */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: '0.5rem', marginBottom: '2rem' }}>
        {products.map((_, i) => (
          <button key={i} onClick={() => { setDir(i > current ? 'right' : 'left'); setCurrent(i) }}
            style={{
              width: i === current ? '2rem' : '0.5rem', height: '0.5rem', borderRadius: '9999px',
              background: i === current ? 'linear-gradient(to right, #3b82f6, #8b5cf6)' : 'rgba(255,255,255,0.15)',
              border: 'none', cursor: 'pointer', transition: 'all 0.3s ease', padding: 0
            }}
          />
        ))}
      </div>

      {/* Main card */}
      <div key={current} style={{
        animation: dir === 'right' ? 'slide-right 0.4s ease' : 'slide-left 0.4s ease',
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2.5rem', alignItems: 'center',
        background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.09)',
        borderRadius: '1.5rem', padding: '3rem', backdropFilter: 'blur(12px)'
      }}>
        {/* Left: image */}
        <div style={{
          width: '100%', aspectRatio: '4/3', borderRadius: '1.25rem', overflow: 'hidden',
          background: 'linear-gradient(135deg, rgba(59,130,246,0.2), rgba(139,92,246,0.2))',
          display: 'flex', alignItems: 'center', justifyContent: 'center'
        }}>
          {p.imageUrl
            ? <img src={p.imageUrl} alt={p.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            : <span style={{ fontSize: '5rem' }}>🖥️</span>}
        </div>

        {/* Right: info */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            {p.badge && <BadgePill badge={p.badge} />}
            {p.subcategory && <span style={{ background: 'rgba(59,130,246,0.15)', color: '#60a5fa', fontSize: '0.75rem', fontWeight: 500, padding: '0.2rem 0.65rem', borderRadius: '9999px', border: '1px solid rgba(59,130,246,0.3)' }}>{p.subcategory}</span>}
          </div>
          <h2 style={{ fontSize: '1.75rem', fontWeight: 800, lineHeight: 1.2 }}>{p.name}</h2>
          <p style={{ color: '#a1a1aa', fontSize: '0.95rem', lineHeight: 1.6 }}>{p.description}</p>
          {featureList.length > 0 && (
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
              {featureList.map((f, i) => (
                <li key={i} style={{ display: 'flex', gap: '0.5rem', fontSize: '0.875rem', color: '#e2e8f0' }}>
                  <span style={{ color: '#10b981' }}>✓</span>{f}
                </li>
              ))}
            </ul>
          )}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '0.5rem' }}>
            <p style={{ fontSize: '2rem', fontWeight: 800, background: 'linear-gradient(to right, #10b981, #3b82f6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
              Rp {p.price.toLocaleString('id-ID')}
            </p>
            <button onClick={() => onBuy(p)} className="btn btn-primary">Beli Sekarang</button>
          </div>
        </div>
      </div>

      {/* Nav buttons */}
      {products.length > 1 && (
        <>
          <button onClick={() => go('left')} style={{
            position: 'absolute', left: '-1.5rem', top: '50%', transform: 'translateY(-50%)',
            width: '3rem', height: '3rem', borderRadius: '50%', background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,255,255,0.1)', color: 'white', fontSize: '1.2rem',
            cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
            backdropFilter: 'blur(8px)', transition: 'all 0.2s'
          }}>‹</button>
          <button onClick={() => go('right')} style={{
            position: 'absolute', right: '-1.5rem', top: '50%', transform: 'translateY(-50%)',
            width: '3rem', height: '3rem', borderRadius: '50%', background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,255,255,0.1)', color: 'white', fontSize: '1.2rem',
            cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
            backdropFilter: 'blur(8px)', transition: 'all 0.2s'
          }}>›</button>
        </>
      )}

      {/* Thumbnails */}
      {products.length > 1 && (
        <div style={{ display: 'flex', gap: '0.75rem', marginTop: '2rem', overflowX: 'auto', paddingBottom: '0.5rem' }}>
          {products.map((prod, i) => (
            <button key={i} onClick={() => { setDir(i > current ? 'right' : 'left'); setCurrent(i) }}
              style={{
                minWidth: '80px', height: '60px', borderRadius: '0.75rem', cursor: 'pointer', padding: 0,
                border: `2px solid ${i === current ? '#8b5cf6' : 'rgba(255,255,255,0.1)'}`,
                background: 'rgba(255,255,255,0.03)', overflow: 'hidden',
                transition: 'all 0.2s', transform: i === current ? 'scale(1.05)' : 'scale(1)'
              }}
            >
              {prod.imageUrl
                ? <img src={prod.imageUrl} alt={prod.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                : <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.5rem' }}>🖥️</div>}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
