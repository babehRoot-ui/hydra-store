'use client'
import { useState, useEffect } from 'react'

export default function Marquee() {
  const [products, setProducts] = useState([])

  useEffect(() => {
    // Ambil data produk asli dari database
    const fetchProducts = async () => {
      try {
        // Paksa browser untuk tidak menggunakan cache lama
        const res = await fetch('/api/products', {
          cache: 'no-store',
          headers: {
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache'
          }
        }) 
        const data = await res.json()
        
        if (Array.isArray(data) && data.length > 0) {
          // Mengambil 10 produk untuk ditampilkan di teks berjalan
          setProducts(data.slice(0, 10))
        } else {
          // Jika belum ada produk sama sekali di database
          setProducts([
            { name: '✨ Belum Ada Produk di Database ✨', price: 0 }
          ])
        }
      } catch (e) {
        console.error('Gagal mengambil data Marquee:', e)
        setProducts([
          { name: `✨ Gagal Memuat: ${e.message} ✨`, price: 0 }
        ])
      }
    }
    fetchProducts()
  }, [])

  return (
    <div style={{
      width: '100%', height: '40px', background: 'rgba(0,0,0,0.4)', 
      backdropFilter: 'blur(5px)', borderBottom: '1px solid rgba(255,255,255,0.05)',
      overflow: 'hidden', position: 'relative', display: 'flex', alignItems: 'center'
    }}>
      <div 
        className="marquee-content" 
        style={{ animationDuration: `${products.length > 0 ? products.length * 15 : 40}s` }}
      >
        {products.map((p, i) => (
          <span key={i} style={{ 
            padding: '0 2rem', fontSize: '0.8rem', fontWeight: 600, 
            color: '#a1a1aa', whiteSpace: 'nowrap', display: 'inline-flex', alignItems: 'center' 
          }}>
            <span style={{ color: '#c084fc', marginRight: '0.5rem' }}>✨</span>
            {p.name.toUpperCase()} — 
            <span style={{ color: '#10b981', marginLeft: '0.5rem' }}>Rp {p.price?.toLocaleString('id-ID')}</span>
            <span style={{ margin: '0 2rem', color: '#8b5cf6' }}>•</span>
          </span>
        ))}
      </div>

      <style jsx>{`
        .marquee-content {
          display: flex;
          white-space: nowrap;
          animation-name: marquee;
          animation-timing-function: linear;
          animation-iteration-count: infinite;
          padding-left: 100vw;
        }
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-100%); }
        }
        .marquee-content:hover {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  )
}
