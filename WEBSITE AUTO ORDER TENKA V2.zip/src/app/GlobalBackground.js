'use client'

export default function GlobalBackground({ url, type }) {
  if (!url || type === 'default') return null;

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100vw',
      height: '100vh',
      zIndex: -1,
      pointerEvents: 'none',
      overflow: 'hidden'
    }}>
      {type === 'video' ? (
        <video
          autoPlay
          loop
          muted
          playsInline
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            opacity: 0.3 // Adjust opacity so text remains readable
          }}
          src={url}
        />
      ) : (
        <div style={{
          width: '100%',
          height: '100%',
          backgroundImage: `url(${url})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          opacity: 0.3
        }} />
      )}
      {/* Fallback gradient/blur overlay to blend it with the dark theme */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        background: 'linear-gradient(to bottom, rgba(15,15,25,0.7), rgba(15,15,25,0.95))',
      }} />
    </div>
  )
}
