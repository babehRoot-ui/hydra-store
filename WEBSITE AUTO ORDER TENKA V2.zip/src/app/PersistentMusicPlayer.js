'use client'
import { useState, useEffect, useRef } from 'react'

export default function PersistentMusicPlayer({ musicUrl }) {
  const [playing, setPlaying] = useState(false)
  const [mounted, setMounted] = useState(false)
  const audioRef = useRef(null)

  useEffect(() => {
    setMounted(true)
    let safeMusicUrl = musicUrl
    if (safeMusicUrl && safeMusicUrl.startsWith('http://')) {
      safeMusicUrl = safeMusicUrl.replace('http://', 'https://')
    }

    if (safeMusicUrl && typeof window !== 'undefined') {
      if (!audioRef.current) {
        audioRef.current = new Audio(safeMusicUrl)
        audioRef.current.loop = true
        audioRef.current.volume = 0.35
      }

      const handleUserInteraction = () => {
        if (audioRef.current && !playing) {
          audioRef.current.play()
            .then(() => setPlaying(true))
            .catch(err => console.log('Autoplay blocked:', err))
        }
        document.removeEventListener('click', handleUserInteraction)
        document.removeEventListener('touchstart', handleUserInteraction)
      }

      document.addEventListener('click', handleUserInteraction)
      document.addEventListener('touchstart', handleUserInteraction)

      return () => {
        document.removeEventListener('click', handleUserInteraction)
        document.removeEventListener('touchstart', handleUserInteraction)
      }
    }
  }, [musicUrl])

  const toggle = () => {
    if (!audioRef.current) return
    if (playing) {
      audioRef.current.pause()
      setPlaying(false)
    } else {
      audioRef.current.play().then(() => setPlaying(true)).catch(() => {})
    }
  }

  if (!mounted || !musicUrl) return null

  return (
    <div style={{ position: 'fixed', bottom: '1.5rem', left: '1.5rem', zIndex: 10000 }}>
      <button
        onClick={toggle}
        title={playing ? 'Pause Musik' : 'Play Musik'}
        style={{
          width: '48px', height: '48px', borderRadius: '50%',
          background: playing
            ? 'linear-gradient(135deg, #ec4899, #8b5cf6)'
            : 'rgba(15,15,15,0.8)',
          border: '1px solid rgba(255,255,255,0.15)',
          color: 'white', fontSize: '1.25rem', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: playing ? '0 0 20px rgba(236,72,153,0.5)' : 'none',
          transition: 'all 0.3s ease',
          backdropFilter: 'blur(10px)'
        }}
      >
        {playing ? '🎵' : '🔇'}
      </button>
    </div>
  )
}

