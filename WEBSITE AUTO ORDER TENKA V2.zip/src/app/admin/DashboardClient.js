'use client';
import { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const DEMO_DATA = {
  daily: [
    { name: '1 Mei', sales: 250000 },
    { name: '2 Mei', sales: 180000 }, // Turun pertama (Merah)
    { name: '3 Mei', sales: 120000 }, // Turun stabil (Biru)
    { name: '4 Mei', sales: 290000 }, // Naik pertama (Hijau)
    { name: '5 Mei', sales: 350000 }, // Naik stabil (Biru)
    { name: '6 Mei', sales: 420000 }, // Naik stabil (Biru)
    { name: '7 Mei', sales: 300000 }, // Turun pertama (Merah)
    { name: '8 Mei', sales: 250000 }, // Turun stabil (Biru)
    { name: '9 Mei', sales: 250000 }, // Datar (Biru)
    { name: '10 Mei', sales: 450000 }, // Naik pertama (Hijau)
    { name: '11 Mei', sales: 600000 }, // Naik stabil (Biru)
  ],
  monthly: [
    { name: 'Jan', sales: 3000000 },
    { name: 'Feb', sales: 2400000 }, // Turun pertama (Merah)
    { name: 'Mar', sales: 1800000 }, // Turun stabil (Biru)
    { name: 'Apr', sales: 2600000 }, // Naik pertama (Hijau)
    { name: 'Mei', sales: 3800000 }, // Naik stabil (Biru)
    { name: 'Jun', sales: 4900000 }, // Naik stabil (Biru)
    { name: 'Jul', sales: 4100000 }, // Turun pertama (Merah)
    { name: 'Agu', sales: 3200000 }, // Turun stabil (Biru)
    { name: 'Sep', sales: 2500000 }, // Turun stabil (Biru)
    { name: 'Okt', sales: 3900000 }, // Naik pertama (Hijau)
    { name: 'Nov', sales: 5600000 }, // Naik stabil (Biru)
    { name: 'Des', sales: 7200000 }, // Naik stabil (Biru)
  ],
  yearly: [
    { name: '2023', sales: 12000000 },
    { name: '2024', sales: 9000000 },  // Turun pertama (Merah)
    { name: '2025', sales: 18000000 }, // Naik pertama (Hijau)
    { name: '2026', sales: 29000000 }, // Naik stabil (Biru)
  ],
  all: [
    { name: '#1', sales: 150000 },
    { name: '#2', sales: 120000 }, // Turun pertama (Merah)
    { name: '#3', sales: 250000 }, // Naik pertama (Hijau)
    { name: '#4', sales: 350000 }, // Naik stabil (Biru)
    { name: '#5', sales: 200000 }, // Turun pertama (Merah)
    { name: '#6', sales: 180000 }, // Turun stabil (Biru)
    { name: '#7', sales: 450000 }, // Naik pertama (Hijau)
    { name: '#8', sales: 650000 }, // Naik stabil (Biru)
  ]
};

export default function DashboardClient({ orders = [] }) {
  const [mounted, setMounted] = useState(false);
  const [timeframe, setTimeframe] = useState('monthly'); // 'daily', 'monthly', 'yearly', 'all'
  const [useDemo, setUseDemo] = useState(false);

  useEffect(() => {
    setMounted(true);
    // Jika tidak ada transaksi riil, otomatis gunakan data demo simulasi
    setUseDemo(orders.length === 0);
  }, [orders]);

  if (!mounted) return <div style={{ width: '100%', height: 400, background: 'rgba(255,255,255,0.02)', borderRadius: '1rem' }} />;

  // Kalkulasi data riil berdasarkan timeframe pilihan
  const getRealData = () => {
    if (timeframe === 'daily') {
      const data = [];
      const now = new Date();
      // Tarik 15 hari terakhir
      for (let i = 14; i >= 0; i--) {
        const d = new Date();
        d.setDate(now.getDate() - i);
        const dateStr = d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
        
        const startOfDay = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0).getTime();
        const endOfDay = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999).getTime();
        
        const daySales = orders
          .filter(o => {
            const t = new Date(o.createdAt).getTime();
            return t >= startOfDay && t <= endOfDay;
          })
          .reduce((sum, o) => sum + o.amount, 0);

        data.push({ name: dateStr, sales: daySales });
      }
      return data;
    }

    if (timeframe === 'monthly') {
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
      const now = new Date();
      const currentYear = now.getFullYear();
      
      return months.map((monthName, index) => {
        const monthSales = orders
          .filter(o => {
            const d = new Date(o.createdAt);
            return d.getMonth() === index && d.getFullYear() === currentYear;
          })
          .reduce((sum, o) => sum + o.amount, 0);
        return { name: monthName, sales: monthSales };
      });
    }

    if (timeframe === 'yearly') {
      const now = new Date();
      const currentYear = now.getFullYear();
      const years = [currentYear - 2, currentYear - 1, currentYear];
      
      return years.map(y => {
        const yearSales = orders
          .filter(o => new Date(o.createdAt).getFullYear() === y)
          .reduce((sum, o) => sum + o.amount, 0);
        return { name: y.toString(), sales: yearSales };
      });
    }

    if (timeframe === 'all') {
      if (orders.length === 0) return [];
      // Sort kronologis berdasarkan tanggal transaksi dibuat
      const sorted = [...orders].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
      return sorted.map((o, idx) => {
        const d = new Date(o.createdAt);
        const dateStr = d.toLocaleDateString('id-ID', { day: 'numeric', month: 'numeric', hour: '2-digit', minute: '2-digit' });
        return { name: `#${idx + 1} (${dateStr})`, sales: o.amount };
      });
    }

    return [];
  };

  const chartData = useDemo ? DEMO_DATA[timeframe] : getRealData();

  // Custom Dot Renderer dengan logika deteksi tren warna kustom
  const renderCustomDot = (props) => {
    const { cx, cy, payload, index } = props;
    if (index === undefined || chartData.length === 0) return null;

    let dotColor = '#8b5cf6'; // Default ungu untuk titik pertama

    if (index > 0 && chartData[index - 1]) {
      const prevSales = chartData[index - 1].sales;
      const currSales = payload.sales;
      const diff = currSales - prevSales;

      if (diff < 0) {
        // Tren Turun
        const wasDroppingBefore = index > 1 && chartData[index - 2] && (chartData[index - 1].sales - chartData[index - 2].sales < 0);
        dotColor = wasDroppingBefore ? '#3b82f6' : '#ef4444'; // Turun stabil = Biru, Turun pertama = Merah
      } else if (diff > 0) {
        // Tren Naik
        const wasRisingBefore = index > 1 && chartData[index - 2] && (chartData[index - 1].sales - chartData[index - 2].sales > 0);
        dotColor = wasRisingBefore ? '#3b82f6' : '#10b981'; // Naik stabil = Biru, Naik pertama = Hijau
      } else {
        dotColor = '#3b82f6';
      }
    }

    return (
      <g key={`dot-${index}`}>
        <circle cx={cx} cy={cy} r={10} fill={dotColor} opacity={0.3} style={{ filter: 'blur(3px)' }} />
        <circle cx={cx} cy={cy} r={7} fill="none" stroke={dotColor} strokeWidth={1.5} />
        <circle cx={cx} cy={cy} r={4.5} fill={dotColor} stroke="#0f0f18" strokeWidth={1} />
      </g>
    );
  };

  return (
    <div style={{ width: '100%', minHeight: 440 }}>
      {/* Menu Switcher Mode Grafik */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div style={{ display: 'flex', gap: '0.4rem', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)', padding: '0.3rem', borderRadius: '12px', flexWrap: 'wrap' }}>
          <button 
            onClick={() => setTimeframe('daily')}
            style={{ padding: '0.4rem 0.9rem', fontSize: '0.8rem', fontWeight: 600, border: 'none', borderRadius: '8px', cursor: 'pointer', transition: 'all 0.2s', background: timeframe === 'daily' ? '#8b5cf6' : 'transparent', color: timeframe === 'daily' ? '#fff' : '#a1a1aa' }}
          >
            📅 Hari
          </button>
          <button 
            onClick={() => setTimeframe('monthly')}
            style={{ padding: '0.4rem 0.9rem', fontSize: '0.8rem', fontWeight: 600, border: 'none', borderRadius: '8px', cursor: 'pointer', transition: 'all 0.2s', background: timeframe === 'monthly' ? '#8b5cf6' : 'transparent', color: timeframe === 'monthly' ? '#fff' : '#a1a1aa' }}
          >
            📆 Bulan
          </button>
          <button 
            onClick={() => setTimeframe('yearly')}
            style={{ padding: '0.4rem 0.9rem', fontSize: '0.8rem', fontWeight: 600, border: 'none', borderRadius: '8px', cursor: 'pointer', transition: 'all 0.2s', background: timeframe === 'yearly' ? '#8b5cf6' : 'transparent', color: timeframe === 'yearly' ? '#fff' : '#a1a1aa' }}
          >
            🗓️ Tahun
          </button>
          <button 
            onClick={() => setTimeframe('all')}
            style={{ padding: '0.4rem 0.9rem', fontSize: '0.8rem', fontWeight: 700, border: 'none', borderRadius: '8px', cursor: 'pointer', transition: 'all 0.2s', background: timeframe === 'all' ? '#8b5cf6' : 'transparent', color: timeframe === 'all' ? '#fff' : '#a1a1aa' }}
          >
            📈 Semua
          </button>
        </div>

        {/* Toggle Data Asli / Demo */}
        {orders.length > 0 && (
          <button
            onClick={() => setUseDemo(!useDemo)}
            style={{
              padding: '0.4rem 0.9rem', fontSize: '0.75rem', fontWeight: 700,
              borderRadius: '9999px', cursor: 'pointer', transition: 'all 0.2s',
              border: '1px solid ' + (useDemo ? 'rgba(239, 68, 68, 0.3)' : 'rgba(16, 185, 129, 0.3)'),
              background: useDemo ? 'rgba(239, 68, 68, 0.05)' : 'rgba(16, 185, 129, 0.05)',
              color: useDemo ? '#ef4444' : '#10b981'
            }}
          >
            {useDemo ? '🔄 Klik untuk Lihat Data Nyata' : '🧪 Klik untuk Coba Simulasi'}
          </button>
        )}

        {orders.length === 0 && (
          <div style={{ fontSize: '0.75rem', padding: '0.4rem 0.9rem', borderRadius: '9999px', border: '1px solid rgba(251,191,36,0.3)', background: 'rgba(251,191,36,0.05)', color: '#fbbf24', fontWeight: 600 }}>
            ⚠️ Belum ada order lunas. Menampilkan Data Simulasi
          </div>
        )}
      </div>

      {chartData.length === 0 ? (
        <div style={{ height: 400, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', border: '1px dashed rgba(255,255,255,0.05)', borderRadius: '12px' }}>
          <p style={{ color: '#52525b', fontSize: '0.9rem' }}>Belum ada data untuk periode ini.</p>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart
            data={chartData}
            margin={{ top: 20, right: 30, left: 10, bottom: 5 }}
          >
            <defs>
              <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.25}/>
                <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0.0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
            <XAxis 
              dataKey="name" 
              stroke="#52525b" 
              tickLine={false}
              axisLine={false}
              style={{ fontSize: '0.75rem', fontWeight: 600 }}
            />
            <YAxis 
              stroke="#52525b" 
              tickLine={false}
              axisLine={false}
              style={{ fontSize: '0.75rem', fontWeight: 600 }}
              tickFormatter={(v) => `Rp ${v >= 1000000 ? `${(v/1000000).toFixed(1)}M` : (v >= 1000 ? `${(v/1000).toFixed(0)}k` : v)}`}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'rgba(10,10,18,0.95)', 
                border: '1px solid rgba(255,255,255,0.08)', 
                borderRadius: '12px',
                backdropFilter: 'blur(10px)',
                boxShadow: '0 10px 25px -5px rgba(0,0,0,0.5)'
              }}
              itemStyle={{ color: '#fff', fontSize: '0.85rem' }}
              labelStyle={{ color: '#a1a1aa', fontWeight: 700, fontSize: '0.85rem', marginBottom: '4px' }}
              formatter={(value, name, props) => {
                const index = props.index;
                let trendText = 'Awal Periode';
                if (index > 0 && chartData[index - 1]) {
                  const prev = chartData[index - 1].sales;
                  const diff = value - prev;
                  if (diff < 0) {
                    const wasDroppingBefore = index > 1 && chartData[index - 2] && (chartData[index - 1].sales - chartData[index - 2].sales < 0);
                    trendText = wasDroppingBefore ? '📉 Stabil Turun' : '🚨 Turun Pertama';
                  } else if (diff > 0) {
                    const wasRisingBefore = index > 1 && chartData[index - 2] && (chartData[index - 1].sales - chartData[index - 2].sales > 0);
                    trendText = wasRisingBefore ? '📈 Stabil Naik' : '✨ Naik Pertama';
                  } else {
                    trendText = '⚖️ Stabil/Datar';
                  }
                }
                return [`Rp ${value.toLocaleString('id-ID')} (${trendText})`, 'Pendapatan'];
              }}
            />
            <Area 
              type="monotone" 
              dataKey="sales" 
              stroke="#8b5cf6" 
              strokeWidth={3}
              fillOpacity={1} 
              fill="url(#colorSales)"
              dot={renderCustomDot}
              activeDot={{ r: 8, strokeWidth: 0 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      )}
      
      {/* Legend Indikator Tren */}
      <div className="flex justify-center gap-6" style={{ marginTop: '1.5rem', flexWrap: 'wrap', fontSize: '0.8rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <div style={{ width: 10, height: 10, background: '#10b981', borderRadius: '50%', boxShadow: '0 0 8px #10b981' }} />
          <span style={{ color: '#a1a1aa', fontWeight: 500 }}>Naik Pertama (Tren Positif)</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <div style={{ width: 10, height: 10, background: '#ef4444', borderRadius: '50%', boxShadow: '0 0 8px #ef4444' }} />
          <span style={{ color: '#a1a1aa', fontWeight: 500 }}>Turun Pertama (Tren Negatif)</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <div style={{ width: 10, height: 10, background: '#3b82f6', borderRadius: '50%', boxShadow: '0 0 8px #3b82f6' }} />
          <span style={{ color: '#a1a1aa', fontWeight: 500 }}>Stabil Naik / Turun (Tren Berlanjut)</span>
        </div>
      </div>
    </div>
  );
}
