'use client'
import { useState, useEffect } from 'react'
import { toast } from 'react-hot-toast'
import { useRouter } from 'next/navigation'

export const dynamic = 'force-dynamic'

export default function AdminLinksPage() {
  const [links, setLinks] = useState([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({ title: '', url: '', icon: '🔗', order: 0 })
  const [editingId, setEditingId] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    fetchLinks()
  }, [])

  const fetchLinks = async () => {
    try {
      const res = await fetch('/api/links')
      const data = await res.json()
      if (data.success) setLinks(data.data)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitting(true)

    try {
      const method = editingId ? 'PUT' : 'POST'
      const url = editingId ? `/api/links/${editingId}` : '/api/links'
      
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      })

      const data = await res.json()
      if (data.success) {
        toast.success(editingId ? 'Link diperbarui!' : 'Link ditambahkan!')
        setForm({ title: '', url: '', icon: '🔗', order: 0 })
        setEditingId(null)
        fetchLinks()
      } else {
        toast.error('Gagal: ' + data.message)
      }
    } catch (err) {
      toast.error('Error: ' + err.message)
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (id) => {
    if (!confirm('Yakin ingin menghapus link ini?')) return
    try {
      const res = await fetch(`/api/links/${id}`, { method: 'DELETE' })
      const data = await res.json()
      if (data.success) {
        toast.success('Link dihapus!')
        fetchLinks()
      }
    } catch (err) {
      toast.error('Error: ' + err.message)
    }
  }

  const handleEdit = (link) => {
    setForm({ title: link.title, url: link.url, icon: link.icon, order: link.order })
    setEditingId(link.id)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleSyncDB = async () => {
    if (!confirm('Ingin sinkronisasi database untuk fitur Link Bio? (Gunakan jika muncul error Table Not Found)')) return
    try {
      const res = await fetch('/api/admin/db-sync', { method: 'POST' })
      const data = await res.json()
      if (data.success) {
        toast.success('Database berhasil disinkronkan!')
        fetchLinks()
      } else {
        toast.error('Gagal sinkron: ' + data.message)
      }
    } catch (err) {
      toast.error('Error: ' + err.message)
    }
  }

  return (
    <div className="container" style={{ padding: '2rem 1rem' }}>
      <div style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button onClick={() => window.location.href = '/admin'} className="btn" style={{ background: 'rgba(255,255,255,0.05)', padding: '0.5rem 1rem' }}>← Dashboard</button>
          <h1 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Manage Bio Links</h1>
        </div>
        <button 
          onClick={handleSyncDB} 
          className="btn" 
          style={{ 
            background: 'rgba(16, 185, 129, 0.1)', 
            border: '1px solid rgba(16, 185, 129, 0.3)', 
            color: '#10b981', 
            fontSize: '0.8rem',
            fontWeight: 700
          }}
        >
          🔄 Sync Database
        </button>
      </div>

      <div className="admin-links-grid">
        <style jsx>{`
          .admin-links-grid {
            display: grid;
            grid-template-columns: 1fr 1.5fr;
            gap: 2rem;
          }
          @media (max-width: 1024px) {
            .admin-links-grid {
              grid-template-columns: 1fr;
              gap: 1.5rem;
            }
          }
        `}</style>
        {/* FORM */}
        <div className="glass-card" style={{ height: 'fit-content' }}>
          <h2 style={{ marginBottom: '1.5rem', fontSize: '1.1rem' }}>{editingId ? '✏️ Edit Link' : '+ Add New Link'}</h2>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <label className="cm-label">Judul Link</label>
              <input 
                type="text" 
                required 
                className="input" 
                placeholder="Misal: Join Telegram" 
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
            </div>
            <div>
              <label className="cm-label">URL Tujuan</label>
              <input 
                type="url" 
                required 
                className="input" 
                placeholder="https://..." 
                value={form.url}
                onChange={(e) => setForm({ ...form, url: e.target.value })}
              />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div>
                <label className="cm-label">Ikon (Emoji)</label>
                <input 
                  type="text" 
                  className="input" 
                  placeholder="🚀" 
                  value={form.icon}
                  onChange={(e) => setForm({ ...form, icon: e.target.value })}
                />
              </div>
              <div>
                <label className="cm-label">Urutan</label>
                <input 
                  type="number" 
                  className="input" 
                  value={form.order}
                  onChange={(e) => setForm({ ...form, order: parseInt(e.target.value) })}
                />
              </div>
            </div>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <button type="submit" disabled={submitting} className="btn btn-primary" style={{ flex: 1 }}>
                {submitting ? 'Processing...' : (editingId ? 'Update Link' : 'Save Link')}
              </button>
              {editingId && (
                <button type="button" onClick={() => { setEditingId(null); setForm({ title: '', url: '', icon: '🔗', order: 0 }) }} className="btn" style={{ background: 'rgba(255,255,255,0.05)' }}>Batal</button>
              )}
            </div>
          </form>
        </div>

        {/* LIST */}
        <div className="glass-card">
          <h2 style={{ marginBottom: '1.5rem', fontSize: '1.1rem' }}>Current Links</h2>
          <div className="flex flex-col gap-3">
            {loading ? (
              <div className="text-center py-8">Loading...</div>
            ) : links.map(link => (
              <div key={link.id} style={{ display: 'flex', alignItems: 'center', padding: '1rem', background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.05)', borderRadius: '12px', gap: '1rem' }}>
                <span style={{ fontSize: '1.2rem' }}>{link.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600 }}>{link.title}</div>
                  <div className="text-secondary" style={{ fontSize: '0.75rem', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '300px', whiteSpace: 'nowrap' }}>{link.url}</div>
                </div>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <button onClick={() => window.open(link.url, '_blank')} className="btn" style={{ background: 'rgba(255,255,255,0.05)', padding: '0.4rem 0.8rem', fontSize: '0.75rem' }}>View</button>
                  <button onClick={() => handleEdit(link)} className="btn" style={{ background: 'rgba(59,130,246,0.1)', color: '#3b82f6', padding: '0.4rem 0.8rem', fontSize: '0.75rem' }}>Edit</button>
                  <button onClick={() => handleDelete(link.id)} className="btn" style={{ background: 'rgba(239,68,68,0.1)', color: '#ef4444', padding: '0.4rem 0.8rem', fontSize: '0.75rem' }}>Delete</button>
                </div>
              </div>
            ))}
            {!loading && links.length > 0 && (
              <a href="/links" target="_blank" className="btn btn-primary" style={{ marginTop: '1rem', textDecoration: 'none' }}>
                👁️ Lihat Halaman Bio (Public)
              </a>
            )}
            {!loading && links.length === 0 && <div className="text-center text-secondary py-8">No links found.</div>}
          </div>
        </div>
      </div>
    </div>
  )
}
