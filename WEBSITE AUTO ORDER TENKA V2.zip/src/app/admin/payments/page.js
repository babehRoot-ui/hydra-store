import Link from 'next/link'

export default async function AdminPayments() {
  return (
    <main className="container" style={{ padding: '4rem 0' }}>
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
          <Link href="/admin" style={{ color: '#3b82f6', textDecoration: 'none', fontWeight: 600 }}>← Kembali</Link>
          <h1 style={{ fontSize: '2.5rem', fontWeight: 700 }}>💳 Konfigurasi Pembayaran</h1>
        </div>
        <p className="text-secondary">Status gateway pembayaran Tenka Store.</p>
      </div>

      <div className="glass-card" style={{ padding: '3rem', textAlign: 'center' }}>
        <div style={{ fontSize: '4rem', marginBottom: '1.5rem' }}>🤖</div>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 700, marginBottom: '1rem' }}>Sistem Pembayaran Otomatis Aktif</h2>
        <p style={{ color: '#94a3b8', maxWidth: '600px', margin: '0 auto 2rem', lineHeight: '1.6' }}>
          Sesuai kebijakan terbaru, seluruh metode pembayaran manual telah dinonaktifkan. 
          Sistem kini sepenuhnya menggunakan <strong>Pakasir Payment Gateway (QRIS)</strong> untuk menjamin keamanan "Zero Data" dan pengiriman produk instan.
        </p>
        
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.75rem', padding: '0.75rem 1.5rem', background: 'rgba(16,185,129,0.1)', borderRadius: '9999px', border: '1px solid rgba(16,185,129,0.3)' }}>
          <span style={{ color: '#10b981', fontSize: '1.2rem' }}>●</span>
          <span style={{ color: '#10b981', fontWeight: 600 }}>Gateway Pakasir: Terhubung & Siap</span>
        </div>
      </div>
    </main>
  )
}
