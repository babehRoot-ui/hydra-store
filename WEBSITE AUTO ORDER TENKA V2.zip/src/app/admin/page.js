import { prisma } from '@/lib/prisma'
import DashboardClient from './DashboardClient'
import Link from 'next/link'

export default async function AdminDashboard() {
  const productsCount = await prisma.product.count();
  const ordersCount = await prisma.order.count();
  const visitorsCount = await prisma.visitor.count();
  
  // Ambil transaksi asli yang sukses secara realtime
  let paidOrders = [];
  try {
    paidOrders = await prisma.order.findMany({
      where: { status: 'SUCCESS' },
      select: {
        createdAt: true,
        amount: true
      },
      orderBy: { createdAt: 'asc' }
    });
  } catch (error) {
    console.error('Error fetching paid orders:', error);
  }

  // Hitung total omset riil
  const totalRevenue = paidOrders.reduce((sum, o) => sum + o.amount, 0);

  return (
    <main className="container" style={{ padding: '2rem 0' }}>
      <div style={{ marginBottom: '3rem' }}>
        <h1 className="text-gradient" style={{ fontSize: 'clamp(2rem, 5vw, 3rem)', fontWeight: 800, marginBottom: '1.5rem' }}>
          Admin Dashboard
        </h1>
        
        {/* Quick Actions Grid */}
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', 
          gap: '1rem',
          marginBottom: '2rem'
        }}>
          <Link href="/admin/orders" className="btn btn-outline" style={{ borderRadius: '12px', fontSize: '0.85rem' }}>
            📦 Pesanan & Resi
          </Link>
          <Link href="/admin/upload" className="btn btn-outline" style={{ borderRadius: '12px', fontSize: '0.85rem' }}>
            ☁️ Upload CDN
          </Link>
          <Link href="/admin/products" className="btn btn-outline" style={{ borderRadius: '12px', fontSize: '0.85rem' }}>
            🛍️ Manajemen Produk
          </Link>
          <Link href="/admin/links" className="btn btn-outline" style={{ borderRadius: '12px', fontSize: '0.85rem' }}>
            🔗 Bio Links
          </Link>
          <Link href="/admin/categories" className="btn btn-outline" style={{ 
            borderRadius: '12px', fontSize: '0.85rem',
            background: 'rgba(139, 92, 246, 0.1)', border: '1px solid rgba(139, 92, 246, 0.3)', color: '#c084fc'
          }}>
            📁 Kategori & Tema
          </Link>
          <Link href="/admin/settings" className="btn" style={{ 
            borderRadius: '12px', 
            fontSize: '0.85rem',
            background: 'rgba(239, 68, 68, 0.1)',
            border: '1px solid rgba(239, 68, 68, 0.3)',
            color: '#ef4444',
            fontWeight: 700
          }}>
            ⚙️ Pengaturan Sistem
          </Link>
        </div>
      </div>

      <div className="grid gap-6" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', marginBottom: '2rem' }}>
        <div className="glass-card">
          <h3 className="text-secondary" style={{ fontSize: '1rem', marginBottom: '0.5rem' }}>Total Produk</h3>
          <p style={{ fontSize: '2.5rem', fontWeight: 700 }} className="text-gradient">{productsCount}</p>
        </div>
        <div className="glass-card">
          <h3 className="text-secondary" style={{ fontSize: '1rem', marginBottom: '0.5rem' }}>Total Pesanan</h3>
          <p style={{ fontSize: '2.5rem', fontWeight: 700 }} className="text-gradient">{ordersCount}</p>
        </div>
        <div className="glass-card" style={{ border: '1px solid rgba(16, 185, 129, 0.2)', background: 'linear-gradient(135deg, rgba(16,185,129,0.03), rgba(0,0,0,0))' }}>
          <h3 className="text-secondary" style={{ fontSize: '1rem', marginBottom: '0.5rem', color: '#10b981' }}>💰 Omset Nyata</h3>
          <p style={{ fontSize: '2.2rem', fontWeight: 800, background: 'linear-gradient(to right, #10b981, #34d399)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
            Rp {totalRevenue.toLocaleString('id-ID')}
          </p>
        </div>
        <div className="glass-card" style={{ border: '1px solid rgba(59, 130, 246, 0.2)', background: 'linear-gradient(135deg, rgba(59,130,246,0.03), rgba(0,0,0,0))' }}>
          <h3 className="text-secondary" style={{ fontSize: '1rem', marginBottom: '0.5rem', color: '#60a5fa' }}>👥 Total Pengunjung (IP Unik)</h3>
          <p style={{ fontSize: '2.2rem', fontWeight: 800, background: 'linear-gradient(to right, #60a5fa, #3b82f6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
            {visitorsCount.toLocaleString('id-ID')}
          </p>
        </div>
      </div>

      <div className="glass-card" style={{ position: 'relative' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 600 }}>📊 Grafik Penjualan Riil</h2>
          <span style={{ fontSize: '0.75rem', background: 'rgba(16, 185, 129, 0.1)', border: '1px solid rgba(16, 185, 129, 0.3)', color: '#10b981', padding: '0.3rem 0.8rem', borderRadius: '9999px', fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}>
            <span style={{ width: 6, height: 6, background: '#10b981', borderRadius: '50%', animation: 'ping 1s infinite' }} />
            REALTIME NYATA
          </span>
        </div>
        <DashboardClient orders={JSON.parse(JSON.stringify(paidOrders))} />
      </div>
    </main>
  )
}
