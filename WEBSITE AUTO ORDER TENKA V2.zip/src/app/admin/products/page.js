import { prisma } from '@/lib/prisma'
import Link from 'next/link'
import ProductsClient from './ProductsClient'
import { DEFAULT_CATEGORIES } from '@/app/api/admin/categories/route'

export const dynamic = 'force-dynamic'

export default async function AdminProducts() {
  let products = []
  let categories = DEFAULT_CATEGORIES
  try {
    products = await prisma.product.findMany({
      orderBy: { createdAt: 'desc' }
    })
    
    const categorySetting = await prisma.setting.findUnique({
      where: { key: 'CATEGORIES' }
    })
    if (categorySetting && categorySetting.value) {
      categories = JSON.parse(categorySetting.value)
    }
  } catch (error) {
    console.error('Database fetch error:', error)
  }

  return (
    <main className="container" style={{ padding: '4rem 0' }}>
      <div className="flex justify-between items-center" style={{ marginBottom: '2rem' }}>
        <div className="flex items-center gap-4">
          <Link href="/admin" className="text-secondary" style={{ textDecoration: 'none' }}>← Kembali</Link>
          <h1 style={{ fontSize: '2rem', fontWeight: 700 }}>Manajemen Produk</h1>
        </div>
      </div>

      <ProductsClient products={JSON.parse(JSON.stringify(products))} categories={categories} />
    </main>
  )
}
