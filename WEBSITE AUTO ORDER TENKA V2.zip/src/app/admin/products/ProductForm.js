'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'react-hot-toast'

// Supabase CDN Configuration with Dual Key Failover
const SUPABASE_UPLOAD_URL = 'https://yxwcqbvumcxyahiknszr.supabase.co/functions/v1/api-upload'
const SUPABASE_API_KEYS = [
  'zzzz_JWXDHqIlDu5qPVr8C5yIM14NCxKP1WR1Fw9NgDwF', // Key Utama
  'zzzz_BKpEaA01t9yKYDhQ8h8NSUf6CR6J40mXqsy5c7Ec'  // Key Cadangan
]

/**
 * Robust upload dengan failover otomatis antar API Key
 */
async function robustUpload(file) {
  let lastError = null
  
  for (const key of SUPABASE_API_KEYS) {
    try {
      const fd = new FormData()
      fd.append('file', file)
      const res = await fetch(SUPABASE_UPLOAD_URL, {
        method: 'POST',
        headers: { 'x-api-key': key },
        body: fd
      })
      const data = await res.json()
      if (data.success && data.url) return { success: true, url: data.url }
      lastError = data.message || data.error || 'API Error'
    } catch (err) {
      lastError = err.message
    }
  }
  return { success: false, error: lastError }
}

export default function ProductForm({ editProduct = null, onCancel = null, categories = [] }) {
  const router = useRouter()
  const isEditMode = !!editProduct

  const [loading, setLoading] = useState(false)
  const [category, setCategory] = useState(editProduct?.category || '')
  const [deliveryType, setDeliveryType] = useState(editProduct?.deliveryType || 'LINK')
  const [uploading, setUploading] = useState(false)
  const [uploadedUrl, setUploadedUrl] = useState(editProduct?.deliveryContent || '')
  
  // Image handling
  const [imageMode, setImageMode] = useState('url') // 'url' or 'upload'
  const [imageUrl, setImageUrl] = useState(editProduct?.imageUrl || '')
  const [uploadingImg, setUploadingImg] = useState(false)

  // Re-sync state kalau editProduct berubah
  useEffect(() => {
    setCategory(editProduct?.category || '')
    setDeliveryType(editProduct?.deliveryType || 'LINK')
    setUploadedUrl(editProduct?.deliveryContent || '')
    setImageUrl(editProduct?.imageUrl || '')
  }, [editProduct])

  const isTierPanel = category === 'panel'
  const isSewa = category === 'sewa'
  const isPtero = category === 'ptero'

  const handleFileUpload = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    const MAX_SIZE = 2 * 1024 * 1024 * 1024
    if (file.size > MAX_SIZE) { toast.error('File terlalu besar! Maksimal 2GB.'); return }
    
    setUploading(true)
    const res = await robustUpload(file)
    if (res.success) {
      setUploadedUrl(res.url)
      toast.success('File berhasil diunggah!')
    } else {
      toast.error('Gagal unggah: ' + res.error)
    }
    setUploading(false)
  }

  const handleImageUpload = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    if (!file.type.startsWith('image/')) { toast.error('Harap pilih file gambar!'); return }
    
    setUploadingImg(true)
    const res = await robustUpload(file)
    if (res.success) {
      setImageUrl(res.url)
      toast.success('Gambar berhasil diunggah!')
    } else {
      toast.error('Gagal unggah gambar: ' + res.error)
    }
    setUploadingImg(false)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    const formData = new FormData(e.currentTarget)
    if (deliveryType === 'FILE' && !isSewa) {
      formData.set('deliveryContent', uploadedUrl)
    }
    // Sertakan ID jika mode edit
    if (isEditMode) formData.set('id', editProduct.id)

    try {
      const res = await fetch('/api/admin/products', {
        method: isEditMode ? 'PUT' : 'POST',
        body: formData
      })
      const data = await res.json()
      if (data.success) {
        router.refresh()
        if (isEditMode) {
          toast.success('Produk berhasil diperbarui!')
          onCancel?.()
        } else {
          e.target.reset()
          setUploadedUrl('')
          setDeliveryType('LINK')
          setCategory('')
          toast.success('Produk berhasil ditambahkan!')
        }
      } else {
        toast.error('Gagal: ' + data.message)
      }
    } catch (err) {
      toast.error('Error: ' + err.message)
    } finally {
      setLoading(false)
    }
  }

  // Helper: parse fitur dari JSON atau string biasa
  const featuresDefault = () => {
    if (!editProduct?.features) return ''
    try {
      const arr = JSON.parse(editProduct.features)
      return Array.isArray(arr) ? arr.join('\n') : editProduct.features
    } catch { return editProduct.features }
  }

  return (
    <div className="glass-card">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>
          {isEditMode ? '✏️ Edit Produk' : '+ Tambah Produk'}
        </h2>
        {isEditMode && onCancel && (
          <button
            type="button"
            onClick={onCancel}
            style={{ fontSize: '0.8rem', color: '#a1a1aa', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', padding: '0.3rem 0.8rem', cursor: 'pointer' }}
          >
            ✕ Batal
          </button>
        )}
      </div>

      {isEditMode && (
        <div style={{ marginBottom: '1rem', padding: '0.75rem 1rem', background: 'rgba(251,191,36,0.08)', border: '1px solid rgba(251,191,36,0.2)', borderRadius: '10px', fontSize: '0.8rem', color: '#fbbf24' }}>
          📝 Mode Edit: <strong>{editProduct.name}</strong>
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div>
          <label className="text-secondary" style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.875rem' }}>Nama Produk *</label>
          <input type="text" name="name" required className="input" placeholder="ALICE MD V16 Terbaru" defaultValue={editProduct?.name || ''} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: (isTierPanel || isSewa || isPtero) ? '1fr' : '1fr 1fr', gap: '0.75rem' }}>
          <div>
            <label className="text-secondary" style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.875rem' }}>Kategori *</label>
            <select name="category" required className="input" style={{ cursor: 'pointer' }} value={category} onChange={(e) => setCategory(e.target.value)}>
              <option value="">-- Pilih --</option>
              {categories.map(c => (
                <option key={c.slug} value={c.slug}>{c.icon} {c.label}</option>
              ))}
            </select>
          </div>
          {!isTierPanel && !isSewa && !isPtero && (
            <div>
              <label className="text-secondary" style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.875rem' }}>Sub-Kategori</label>
              <input type="text" name="subcategory" className="input" placeholder="Baileys MD, cPanel v2..." defaultValue={editProduct?.subcategory || ''} />
            </div>
          )}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
          <div>
            <label className="text-secondary" style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.875rem' }}>Harga (Rp) *</label>
            <div className="input-container">
              <input 
                type="number" 
                name="price" 
                required 
                className="input" 
                placeholder="50000" 
                defaultValue={editProduct?.price || ''} 
                style={{ paddingRight: '2.5rem' }}
              />
              <span className="input-icon">💰</span>
            </div>
          </div>
          <div>
            <label className="text-secondary" style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.875rem' }}>Badge</label>
            <select name="badge" className="input" style={{ cursor: 'pointer' }} defaultValue={editProduct?.badge || ''}>
              <option value="">-- Tidak Ada --</option>
              <option value="NEW">🟢 NEW</option>
              <option value="HOT">🔴 HOT</option>
              <option value="SALE">🟡 SALE</option>
              <option value="LIMITED">🟣 LIMITED</option>
              <option value="SPECIAL">✨ SPECIAL</option>
            </select>
          </div>
        </div>

        <div>
          <label className="text-secondary" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.4rem', fontSize: '0.875rem' }}>
            <span>URL Gambar (Opsional)</span>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
               <button type="button" onClick={() => setImageMode('url')} style={{ fontSize: '0.7rem', padding: '0.1rem 0.4rem', borderRadius: '4px', background: imageMode === 'url' ? '#8b5cf6' : 'rgba(255,255,255,0.05)', border: 'none', cursor: 'pointer' }}>🔗 Link</button>
               <button type="button" onClick={() => setImageMode('upload')} style={{ fontSize: '0.7rem', padding: '0.1rem 0.4rem', borderRadius: '4px', background: imageMode === 'upload' ? '#8b5cf6' : 'rgba(255,255,255,0.05)', border: 'none', cursor: 'pointer' }}>📤 Upload</button>
            </div>
          </label>
          
          {imageMode === 'url' ? (
            <input 
              type="url" 
              name="imageUrl" 
              className="input" 
              placeholder="https://i.imgur.com/..." 
              value={imageUrl} 
              onChange={(e) => setImageUrl(e.target.value)} 
            />
          ) : (
            <div style={{ padding: '0.75rem', border: '1px dashed rgba(255,255,255,0.1)', borderRadius: '8px' }}>
               <input 
                 type="file" 
                 accept="image/*" 
                 onChange={handleImageUpload} 
                 className="input" 
                 style={{ marginBottom: 0, padding: '5px', fontSize: '0.8rem' }} 
               />
               {uploadingImg && <p style={{ fontSize: '0.7rem', color: '#3b82f6', marginTop: '0.5rem' }}>⏳ Mengunggah gambar...</p>}
               {imageUrl && (
                 <div style={{ marginTop: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <img src={imageUrl} alt="Preview" style={{ width: '40px', height: '40px', objectFit: 'cover', borderRadius: '4px' }} />
                    <span style={{ fontSize: '0.7rem', color: '#10b981', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Berhasil diunggah!</span>
                    <input type="hidden" name="imageUrl" value={imageUrl} />
                 </div>
               )}
            </div>
          )}
        </div>

        <div>
          <label className="text-secondary" style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.875rem' }}>Deskripsi</label>
          <textarea name="description" rows="2" className="input" placeholder="Deskripsi lengkap produk..." style={{ resize: 'vertical' }} defaultValue={editProduct?.description || ''}></textarea>
        </div>

        {/* DELIVERY SECTION */}
        {!isSewa && !isPtero && (
          <div style={{ padding: '1rem', background: 'rgba(255,255,255,0.03)', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.08)' }}>
            <label className="text-secondary" style={{ display: 'block', marginBottom: '0.8rem', fontSize: '0.875rem', fontWeight: 700 }}>
              {isTierPanel ? 'LINK GRUP (WAJIB ISI)' : 'PENGIRIMAN PRODUK (DELIVERY)'}
            </label>

            {!isTierPanel && (
              <div style={{ display: 'flex', gap: '1rem', marginBottom: '1rem' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                  <input type="radio" name="deliveryType" value="LINK" checked={deliveryType === 'LINK'} onChange={() => setDeliveryType('LINK')} />
                  <span style={{ fontSize: '0.85rem' }}>🔗 Link Download</span>
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                  <input type="radio" name="deliveryType" value="FILE" checked={deliveryType === 'FILE'} onChange={() => setDeliveryType('FILE')} />
                  <span style={{ fontSize: '0.85rem' }}>📁 Upload File (Supabase CDN)</span>
                </label>
              </div>
            )}

            <div className="flex flex-col gap-3">
              <div>
                <label className="text-secondary" style={{ fontSize: '0.75rem', marginBottom: '0.4rem', display: 'block' }}>
                  {isTierPanel ? 'Link Grup Utama (WhatsApp / Telegram)' : 'Link Download Utama / Konten'}
                </label>
                <input
                  type="url"
                  name="deliveryContent"
                  required={!uploadedUrl && !isSewa}
                  className="input"
                  value={uploadedUrl}
                  onChange={(e) => setUploadedUrl(e.target.value)}
                  placeholder={isTierPanel ? 'https://chat.whatsapp.com/... atau https://t.me/...' : 'https://mega.nz/file/...'}
                />
              </div>

              {!isTierPanel && deliveryType === 'FILE' && (
                <div style={{ padding: '1rem', border: '1px dashed rgba(255,255,255,0.1)', borderRadius: '8px' }}>
                  <input
                    type="file"
                    onChange={handleFileUpload}
                    className="input"
                    style={{ marginBottom: 0, padding: '8px' }}
                    accept=".zip,.7z,.rar,.tar,.gz,.txt,.pdf"
                  />
                  {uploading && <p style={{ fontSize: '0.7rem', color: '#3b82f6', marginTop: '0.5rem' }}>⏳ Mengunggah ke Supabase CDN...</p>}
                  {uploadedUrl && <p style={{ fontSize: '0.7rem', color: '#10b981', marginTop: '0.5rem' }}>✅ URL: {uploadedUrl}</p>}
                </div>
              )}

              {isTierPanel && (
                <div>
                  <label className="text-secondary" style={{ fontSize: '0.75rem', marginBottom: '0.4rem', display: 'block' }}>Link Grup Alternatif (Opsional)</label>
                  <input type="url" name="deliveryLink2" className="input" placeholder="Misal link cadangan (WA / Telegram)" defaultValue={editProduct?.deliveryLink2 || ''} />
                  <input type="hidden" name="deliveryLink2Desc" value="Grup Alternatif / Cadangan." />
                </div>
              )}
            </div>
          </div>
        )}

        {/* EXTRA LINKS */}
        {!isTierPanel && !isSewa && !isPtero && (
          <div style={{ padding: '1rem', background: 'rgba(255,255,255,0.03)', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.08)' }}>
            <label className="text-secondary" style={{ display: 'block', marginBottom: '0.8rem', fontSize: '0.875rem', fontWeight: 700 }}>LINK TAMBAHAN (OPTIONAL - LINK 2)</label>
            <div className="flex flex-col gap-3">
              <div>
                <label className="text-secondary" style={{ fontSize: '0.75rem', marginBottom: '0.4rem', display: 'block' }}>URL Link 2 (Grup Update/Folder Cadangan)</label>
                <input type="url" name="deliveryLink2" className="input" placeholder="https://chat.whatsapp.com/..." defaultValue={editProduct?.deliveryLink2 || ''} />
              </div>
              <div>
                <label className="text-secondary" style={{ fontSize: '0.75rem', marginBottom: '0.4rem', display: 'block' }}>Deskripsi Link 2</label>
                <textarea name="deliveryLink2Desc" rows="2" className="input" placeholder="Misal: Join grup ini untuk info update terbaru script." style={{ resize: 'vertical' }} defaultValue={editProduct?.deliveryLink2Desc || ''}></textarea>
              </div>
            </div>
          </div>
        )}

        <div>
          <label className="text-secondary" style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.875rem' }}>Fitur Produk (satu per baris)</label>
          <textarea name="features" rows="3" className="input" placeholder={'No Encrypt\nSupport 24 jam'} style={{ resize: 'vertical', fontFamily: 'monospace', fontSize: '0.85rem' }} defaultValue={featuresDefault()}></textarea>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '0.75rem', background: 'rgba(255,255,255,0.02)', borderRadius: '0.5rem', border: '1px solid var(--card-border)' }}>
          <input
            type="checkbox"
            name="featured"
            id={`featured-${editProduct?.id || 'new'}`}
            defaultChecked={editProduct?.featured || false}
            style={{ width: '1rem', height: '1rem', cursor: 'pointer' }}
          />
          <label htmlFor={`featured-${editProduct?.id || 'new'}`} style={{ cursor: 'pointer', fontSize: '0.9rem' }}>⭐ Produk unggulan</label>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button
            type="submit"
            className="btn btn-primary"
            disabled={loading || uploading || (deliveryType === 'FILE' && !uploadedUrl && !isSewa)}
            style={{ flex: 1 }}
          >
            {loading ? '⏳ Menyimpan...' : (isEditMode ? '💾 Simpan Perubahan' : 'Simpan Produk')}
          </button>
          {isEditMode && onCancel && (
            <button type="button" onClick={onCancel} className="btn" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: '#a1a1aa' }}>
              Batal
            </button>
          )}
        </div>
      </form>
    </div>
  )
}
