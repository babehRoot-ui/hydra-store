'use client'
import { useState, useTransition } from 'react'
import { toast } from 'react-hot-toast'
import ProductForm from './ProductForm'

// Komponen client untuk table interaktif dengan edit + hapus
export default function ProductsClient({ products: initialProducts, categories = [] }) {
  const [editProduct, setEditProduct] = useState(null)
  const [products, setProducts] = useState(initialProducts)
  const [searchQuery, setSearchQuery] = useState('')
  const [isPending, startTransition] = useTransition()

  const handleDelete = async (id, name) => {
    if (!confirm(`Yakin ingin menghapus produk "${name}"?`)) return
    try {
      const res = await fetch('/api/admin/products', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      })
      const data = await res.json()
      if (data.success) {
        setProducts(prev => prev.filter(p => p.id !== id))
      } else {
        toast.error('Gagal hapus: ' + data.message)
      }
    } catch (err) {
      toast.error('Error: ' + err.message)
    }
  }

  const handleEditSuccess = () => {
    setEditProduct(null)
    // Refresh data dari server
    startTransition(() => {
      window.location.reload()
    })
  }

  const BADGE_COLORS = {
    HOT: '#ef4444', NEW: '#10b981', SALE: '#f59e0b',
    LIMITED: '#8b5cf6', SPECIAL: '#ec4899'
  }

  const CATEGORY_LABELS = {}
  categories.forEach(c => {
    CATEGORY_LABELS[c.slug] = c.label
  })

  const filteredProducts = products.filter(p => {
    const safeName = p.name || '';
    const safeCategory = CATEGORY_LABELS[p.category] || p.category || '';
    const query = searchQuery.toLowerCase();
    return safeName.toLowerCase().includes(query) || safeCategory.toLowerCase().includes(query);
  })

  return (
    <div className="admin-grid-layout">
      <style jsx>{`
        .admin-grid-layout {
          display: grid;
          grid-template-columns: 1fr 1.8fr;
          gap: 2rem;
          align-items: start;
        }
        @media (max-width: 1024px) {
          .admin-grid-layout {
            grid-template-columns: 1fr;
            gap: 1.5rem;
          }
          .sticky-form-container {
            position: relative !important;
            top: 0 !important;
            margin-bottom: 2rem;
          }
        }
        .mobile-hide {
          display: table-cell;
        }
        .mobile-card-row {
          display: none;
          padding: 1rem;
          border-bottom: 1px solid var(--card-border);
          flex-direction: column;
          gap: 0.75rem;
        }
        @media (max-width: 768px) {
          .mobile-hide {
            display: none !important;
          }
          .mobile-card-row {
            display: flex;
          }
          .desktop-table {
            display: none;
          }
          .mobile-card-row-wrapper {
            display: block !important;
          }
        }
      `}</style>

      {/* Form Tambah / Edit Produk */}
      <div className="sticky-form-container" style={{ position: 'sticky', top: '5rem', zIndex: 20 }}>
        <ProductForm
          editProduct={editProduct}
          onCancel={editProduct ? () => setEditProduct(null) : null}
          categories={categories}
        />
      </div>

      {/* List Produk */}
      <div className="glass-card" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Daftar Produk ({filteredProducts.length})</h2>
          
          {/* Kolom Pencarian */}
          <div style={{ flex: '1 1 300px', maxWidth: '400px' }}>
            <input 
              type="text" 
              className="input" 
              placeholder="🔍 Cari nama produk atau kategori..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{ width: '100%', padding: '0.6rem 1rem', borderRadius: '8px' }}
            />
          </div>
        </div>

        {filteredProducts.length === 0 ? (
          <p className="text-secondary" style={{ textAlign: 'center', padding: '2rem' }}>
            {products.length === 0 ? 'Belum ada produk.' : 'Produk tidak ditemukan.'}
          </p>
        ) : (
          <>
            {/* View Mobile (Card Style) */}
            <div className="mobile-card-row-wrapper" style={{ display: 'none' }}>
              {filteredProducts.map(product => (
                <div key={product.id} className="mobile-card-row">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '1rem' }}>{product.name}</div>
                      <div style={{ fontSize: '0.75rem', color: '#8b5cf6', fontWeight: 600 }}>{CATEGORY_LABELS[product.category] || product.category}</div>
                    </div>
                    <div style={{ fontWeight: 800, color: '#10b981' }}>Rp {product.price.toLocaleString('id-ID')}</div>
                  </div>
                  <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                    {product.badge && (
                      <span style={{ background: BADGE_COLORS[product.badge], color: 'white', fontSize: '0.65rem', padding: '0.2rem 0.5rem', borderRadius: '4px', fontWeight: 800 }}>{product.badge}</span>
                    )}
                    {product.featured && <span style={{ fontSize: '0.7rem', color: '#f59e0b' }}>⭐ Unggulan</span>}
                  </div>
                  <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.5rem' }}>
                    <button onClick={() => { setEditProduct(product); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="btn btn-outline" style={{ flex: 1, padding: '0.5rem', fontSize: '0.8rem' }}>✏️ Edit</button>
                    <button onClick={() => handleDelete(product.id, product.name)} className="btn" style={{ flex: 1, padding: '0.5rem', fontSize: '0.8rem', background: 'rgba(239,68,68,0.1)', color: '#ef4444', border: '1px solid rgba(239,68,68,0.2)' }}>🗑️ Hapus</button>
                  </div>
                </div>
              ))}
            </div>

            {/* View Desktop (Table Style) */}
            <div className="desktop-table" style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid var(--card-border)' }}>
                    <th style={{ padding: '0.75rem 1rem', fontWeight: 500, color: '#a1a1aa' }}>Nama</th>
                    <th style={{ padding: '0.75rem 1rem', fontWeight: 500, color: '#a1a1aa' }}>Kategori</th>
                    <th style={{ padding: '0.75rem 1rem', fontWeight: 500, color: '#a1a1aa' }}>Harga</th>
                    <th style={{ padding: '0.75rem 1rem', fontWeight: 500, color: '#a1a1aa' }}>Content</th>
                    <th style={{ padding: '0.75rem 1rem', fontWeight: 500, color: '#a1a1aa' }}>Badge</th>
                    <th style={{ padding: '0.75rem 1rem', fontWeight: 500, color: '#a1a1aa' }}>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map(product => (
                    <tr
                      key={product.id}
                      style={{
                        borderBottom: '1px solid rgba(255,255,255,0.04)',
                        background: editProduct?.id === product.id ? 'rgba(251,191,36,0.06)' : 'transparent',
                        transition: 'background 0.2s'
                      }}
                    >
                      <td style={{ padding: '0.75rem 1rem' }}>
                        <div style={{ fontWeight: 500 }}>{product.name}</div>
                        {product.subcategory && <div style={{ fontSize: '0.75rem', color: '#52525b' }}>{product.subcategory}</div>}
                        {product.featured && <span style={{ fontSize: '0.7rem', color: '#f59e0b' }}>⭐ Unggulan</span>}
                      </td>
                      <td style={{ padding: '0.75rem 1rem', color: '#a1a1aa', fontSize: '0.8rem' }}>
                        {CATEGORY_LABELS[product.category] || product.category}
                      </td>
                      <td style={{
                        padding: '0.75rem 1rem', fontWeight: 600,
                        background: 'linear-gradient(to right, #60a5fa, #c084fc)',
                        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text'
                      }}>
                        Rp {product.price.toLocaleString('id-ID')}
                      </td>
                      <td style={{ padding: '0.75rem 1rem', color: '#6b7280', fontSize: '0.75rem', maxWidth: '150px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {product.deliveryContent ? (
                          <a href={product.deliveryContent} target="_blank" rel="noreferrer" style={{ color: '#60a5fa', textDecoration: 'none' }} title={product.deliveryContent}>
                            🔗 Link
                          </a>
                        ) : (product.category === 'sewa' ? '📱 Via WA' : '-')}
                      </td>
                      <td style={{ padding: '0.75rem 1rem' }}>
                        {product.badge && (
                          <span style={{
                            background: BADGE_COLORS[product.badge] || '#8b5cf6',
                            color: 'white', fontSize: '0.7rem', fontWeight: 700,
                            padding: '0.2rem 0.6rem', borderRadius: '9999px'
                          }}>
                            {product.badge}
                          </span>
                        )}
                      </td>
                      <td style={{ padding: '0.75rem 1rem' }}>
                        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                          <button
                            onClick={() => {
                              setEditProduct(product)
                              window.scrollTo({ top: 0, behavior: 'smooth' })
                            }}
                            className="btn btn-outline"
                            style={{ padding: '0.35rem 0.8rem', borderRadius: '0.5rem', fontSize: '0.75rem', fontWeight: 600 }}
                          >
                            ✏️ Edit
                          </button>
                          <button
                            onClick={() => handleDelete(product.id, product.name)}
                            className="btn"
                            style={{ color: '#ef4444', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)', padding: '0.35rem 0.8rem', borderRadius: '0.5rem', fontSize: '0.75rem', fontWeight: 600 }}
                          >
                            🗑️ Hapus
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>


          </>
        )}
      </div>
    </div>
  )
}
