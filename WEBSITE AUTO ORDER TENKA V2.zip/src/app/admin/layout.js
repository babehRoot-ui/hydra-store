import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { verify } from '@/lib/auth'

export default async function AdminLayout({ children }) {
  const cookieStore = await cookies()
  const session = cookieStore.get('admin_session')?.value

  if (!session) {
    redirect('/login')
  }

  const payload = await verify(session)
  if (!payload) {
    redirect('/login')
  }

  return (
    <>
      {children}
    </>
  )
}
