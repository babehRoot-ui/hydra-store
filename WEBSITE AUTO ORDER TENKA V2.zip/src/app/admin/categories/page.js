'use client'
import { useState, useEffect } from 'react'
import { toast } from 'react-hot-toast'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

export const dynamic = 'force-dynamic'

const LAYOUTS = [
  { value: 'grid-card', label: '🔲 Grid Kartu Klasik' },
  { value: 'masonry', label: '🧱 Masonry Dinamis' },
  { value: 'showcase', label: '🌟 Showcase Lebar' }
]

const BG_VARIANTS = [
  { value: '0', label: 'Latar Gelap Elegan' },
  { value: '1', label: 'Latar Kaca Buram' },
  { value: '2', label: 'Latar Bertekstur' },
  { value: '3', label: 'Latar Premium Space' }
]

const ROBOT_POSES = [
  { value: 'wave', label: '👋 Melambai' },
  { value: 'sit-moon', label: '🌙 Duduk di Bulan' },
  { value: 'fly', label: '🚀 Terbang' },
  { value: 'none', label: '🚫 Tanpa Robot' }
]

export default function CategoryManager() {
  const router = useRouter()
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  const [editIndex, setEditIndex] = useState(-1) // -1 means no edit, new category form
  const [form, setForm] = useState(null)

  useEffect(() => {
    fetchCategories()
  }, [])

  const fetchCategories = async () => {
    try {
      const res = await fetch('/api/admin/categories')
      const data = await res.json()
      if (data.success) {
        setCategories(data.data)
      }
    } catch (e) {
      toast.error('Gagal memuat kategori')
    } finally {
      setLoading(false)
    }
  }

  const handleSaveAll = async (newCategories = categories) => {
    setSaving(true)
    try {
      const res = await fetch('/api/admin/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newCategories)
      })
      const data = await res.json()
      if (data.success) {
        toast.success('Kategori berhasil disimpan!')
        setCategories(newCategories)
      } else {
        toast.error('Gagal menyimpan: ' + data.message)
      }
    } catch (e) {
      toast.error('Error menyimpan kategori')
    } finally {
      setSaving(false)
    }
  }

  const handleEdit = (index) => {
    setEditIndex(index)
    setForm({ ...categories[index], tags: categories[index].tags?.join(', ') || '' })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleDelete = (index) => {
    if (!confirm('Apakah Anda yakin ingin menghapus kategori ini?')) return
    const newCategories = categories.filter((_, i) => i !== index)
    handleSaveAll(newCategories)
  }

  const handleCreateNew = () => {
    setEditIndex(categories.length)
    setForm({
      slug: '', label: '', icon: '📁', heroDesc: '',
      accentFrom: '#60a5fa', accentTo: '#c084fc',
      layout: 'grid-card', bgVariant: 0, robotPose: 'wave', robotSide: 'right',
      tags: ''
    })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleSubmitForm = (e) => {
    e.preventDefault()
    if (!form.slug || !form.label) return toast.error('URL Slug dan Label wajib diisi!')
    
    // Process tags
    const processedForm = {
      ...form,
      slug: form.slug.toLowerCase().replace(/[^a-z0-9-]/g, '-'),
      bgVariant: parseInt(form.bgVariant),
      tags: form.tags ? form.tags.split(',').map(t => t.trim()).filter(Boolean) : [form.slug]
    }

    const newCategories = [...categories]
    newCategories[editIndex] = processedForm
    
    handleSaveAll(newCategories)
    setForm(null)
    setEditIndex(-1)
  }

  if (loading) return <div className="container" style={{ padding: '4rem 0', textAlign: 'center' }}>Memuat kategori...</div>

  return (
    <main className="container" style={{ padding: '3rem 0', maxWidth: '1000px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '2rem' }}>
        <div>
          <Link href="/admin" style={{ color: '#a1a1aa', textDecoration: 'none', fontSize: '0.9rem', marginBottom: '0.5rem', display: 'inline-block' }}>← Kembali ke Dashboard</Link>
          <h1 style={{ fontSize: '2rem', fontWeight: 800 }}>📁 Manajemen Kategori</h1>
          <p style={{ color: '#71717a', fontSize: '0.9rem', marginTop: '0.2rem' }}>Atur tema warna, ikon, dan layout untuk setiap kategori.</p>
        </div>
        {!form && (
          <button onClick={handleCreateNew} className="btn" style={{ background: 'linear-gradient(to right, #60a5fa, #c084fc)', padding: '0.6rem 1.2rem', borderRadius: '10px' }}>
            + Kategori Baru
          </button>
        )}
      </div>

      {form && (
        <div className="glass-card animate-fadeInDown" style={{ marginBottom: '3rem', border: '1px solid rgba(139, 92, 246, 0.4)', boxShadow: '0 20px 40px -10px rgba(139, 92, 246, 0.15)' }}>
          <h2 style={{ fontSize: '1.3rem', fontWeight: 700, marginBottom: '1.5rem', color: '#c084fc' }}>
            {editIndex >= categories.length ? 'Tambah Kategori Baru' : 'Edit Kategori: ' + form.label}
          </h2>
          <form onSubmit={handleSubmitForm} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr 1fr', gap: '1rem' }}>
              <div>
                <label style={labelStyle}>URL Slug</label>
                <input required className="input" value={form.slug} onChange={e => setForm({...form, slug: e.target.value})} placeholder="script-bot" style={{ width: '100%' }} />
                <p style={{ fontSize: '0.7rem', color: '#71717a', marginTop: '4px' }}>Hanya huruf, angka, dan strip (-).</p>
              </div>
              <div>
                <label style={labelStyle}>Nama Label (Tampil di Menu)</label>
                <input required className="input" value={form.label} onChange={e => setForm({...form, label: e.target.value})} placeholder="Script & Bot WhatsApp" style={{ width: '100%' }} />
              </div>
              <div>
                <label style={labelStyle}>Ikon / Emoji</label>
                <input className="input" value={form.icon} onChange={e => setForm({...form, icon: e.target.value})} placeholder="🤖" style={{ width: '100%' }} />
              </div>
            </div>

            <div>
              <label style={labelStyle}>Deskripsi Kategori (Tampil di Halaman Kategori)</label>
              <textarea className="input" value={form.heroDesc} onChange={e => setForm({...form, heroDesc: e.target.value})} placeholder="Deskripsi menarik tentang kategori ini..." style={{ width: '100%', resize: 'vertical' }} rows={2} />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div>
                <label style={labelStyle}>Warna Tema (Gradasi Dari)</label>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <input type="color" value={form.accentFrom} onChange={e => setForm({...form, accentFrom: e.target.value})} style={{ width: '50px', height: '40px', padding: 0, border: 'none', background: 'transparent', cursor: 'pointer' }} />
                  <input className="input" value={form.accentFrom} onChange={e => setForm({...form, accentFrom: e.target.value})} style={{ width: '100%' }} />
                </div>
              </div>
              <div>
                <label style={labelStyle}>Warna Tema (Gradasi Ke)</label>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <input type="color" value={form.accentTo} onChange={e => setForm({...form, accentTo: e.target.value})} style={{ width: '50px', height: '40px', padding: 0, border: 'none', background: 'transparent', cursor: 'pointer' }} />
                  <input className="input" value={form.accentTo} onChange={e => setForm({...form, accentTo: e.target.value})} style={{ width: '100%' }} />
                </div>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', background: 'rgba(0,0,0,0.2)', padding: '1.5rem', borderRadius: '12px' }}>
              <div>
                <label style={labelStyle}>Style / Layout Produk</label>
                <select className="input" value={form.layout} onChange={e => setForm({...form, layout: e.target.value})} style={{ width: '100%', cursor: 'pointer' }}>
                  {LAYOUTS.map(l => <option key={l.value} value={l.value}>{l.label}</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Latar Belakang (Style)</label>
                <select className="input" value={form.bgVariant} onChange={e => setForm({...form, bgVariant: e.target.value})} style={{ width: '100%', cursor: 'pointer' }}>
                  {BG_VARIANTS.map(l => <option key={l.value} value={l.value}>{l.label}</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Animasi Maskot (Robot)</label>
                <select className="input" value={form.robotPose} onChange={e => setForm({...form, robotPose: e.target.value})} style={{ width: '100%', cursor: 'pointer' }}>
                  {ROBOT_POSES.map(l => <option key={l.value} value={l.value}>{l.label}</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Posisi Maskot</label>
                <select className="input" value={form.robotSide} onChange={e => setForm({...form, robotSide: e.target.value})} style={{ width: '100%', cursor: 'pointer' }}>
                  <option value="right">Kanan</option>
                  <option value="left">Kiri</option>
                </select>
              </div>
            </div>

            <div>
              <label style={labelStyle}>Tag Filter Pencarian (Pisahkan dengan koma)</label>
              <input className="input" value={form.tags} onChange={e => setForm({...form, tags: e.target.value})} placeholder="bot, script, panel" style={{ width: '100%' }} />
              <p style={{ fontSize: '0.7rem', color: '#71717a', marginTop: '4px' }}>Jika produk memiliki tag ini, ia akan otomatis masuk ke kategori ini.</p>
            </div>

            <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
              <button type="submit" disabled={saving} className="btn" style={{ background: `linear-gradient(135deg, ${form.accentFrom}, ${form.accentTo})`, flex: 1, padding: '0.8rem', borderRadius: '10px' }}>
                {saving ? 'Menyimpan...' : 'Simpan Kategori'}
              </button>
              <button type="button" onClick={() => setForm(null)} className="btn btn-outline" style={{ padding: '0.8rem 2rem', borderRadius: '10px' }}>
                Batal
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Categories List */}
      {!form && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.5rem' }}>
          {categories.map((cat, i) => (
            <div key={i} className="glass-card" style={{ 
              position: 'relative', overflow: 'hidden', padding: '1.5rem',
              borderTop: `4px solid ${cat.accentFrom}`
            }}>
              <div style={{ position: 'absolute', top: '-20px', right: '-20px', fontSize: '6rem', opacity: 0.05, transform: 'rotate(15deg)' }}>
                {cat.icon}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
                <span style={{ fontSize: '1.8rem', background: `linear-gradient(135deg, ${cat.accentFrom}, ${cat.accentTo})`, padding: '0.5rem', borderRadius: '12px', width: '50px', height: '50px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{cat.icon}</span>
                <div>
                  <h3 style={{ fontSize: '1.1rem', fontWeight: 800, margin: 0 }}>{cat.label}</h3>
                  <span style={{ fontSize: '0.75rem', color: '#71717a' }}>/{cat.slug}</span>
                </div>
              </div>
              
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem', fontSize: '0.8rem', color: '#a1a1aa', marginBottom: '1.5rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Layout:</span> <strong style={{ color: 'white' }}>{LAYOUTS.find(l => l.value === cat.layout)?.label.split(' ')[1] || cat.layout}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Robot:</span> <strong style={{ color: 'white' }}>{cat.robotPose !== 'none' ? `${cat.robotPose} (${cat.robotSide})` : 'Mati'}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span>Tema Warna:</span> 
                  <div style={{ display: 'flex', gap: '5px' }}>
                    <div style={{ width: '15px', height: '15px', borderRadius: '50%', background: cat.accentFrom }}></div>
                    <div style={{ width: '15px', height: '15px', borderRadius: '50%', background: cat.accentTo }}></div>
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button onClick={() => handleEdit(i)} className="btn btn-outline" style={{ flex: 1, padding: '0.5rem', fontSize: '0.85rem' }}>✏️ Edit</button>
                <button onClick={() => handleDelete(i)} className="btn btn-outline" style={{ flex: 1, padding: '0.5rem', fontSize: '0.85rem', color: '#ef4444', borderColor: 'rgba(239, 68, 68, 0.2)' }}>🗑️ Hapus</button>
              </div>
            </div>
          ))}
        </div>
      )}

      <style jsx>{`
        .animate-fadeInDown { animation: fadeInDown 0.4s ease-out; }
        @keyframes fadeInDown {
          from { opacity: 0; transform: translateY(-20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </main>
  )
}

const labelStyle = { display: 'block', fontSize: '0.8rem', fontWeight: 600, color: '#a1a1aa', marginBottom: '0.4rem' }
