'use client'
import { useState, useEffect } from 'react'
import { toast } from 'react-hot-toast'
import Link from 'next/link'

// Supabase API Configuration from User Screenshot
const SUPABASE_UPLOAD_URL = 'https://yxwcqbvumcxyahiknszr.supabase.co/functions/v1/api-upload'
const SUPABASE_API_KEYS = [
  'zzzz_JWXDHqIlDu5qPVr8C5yIM14NCxKP1WR1Fw9NgDwF', // Key Utama
  'zzzz_BKpEaA01t9yKYDhQ8h8NSUf6CR6J40mXqsy5c7Ec'  // Key Cadangan
]

export default function AdminUpload() {
  const [file, setFile] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [history, setHistory] = useState([])
  const [loadingHistory, setLoadingHistory] = useState(true)

  const fetchHistory = async () => {
    try {
      const res = await fetch('/api/upload')
      const data = await res.json()
      if (Array.isArray(data)) setHistory(data)
    } catch (e) {
      console.error('Failed to fetch history', e)
    } finally {
      setLoadingHistory(false)
    }
  }

  useEffect(() => {
    fetchHistory()
  }, [])

  const handleUpload = async (e) => {
    e.preventDefault()
    if (!file) return

    if (file.size > 2 * 1024 * 1024 * 1024) {
      setError('File terlalu besar! Maksimal 2GB.')
      return
    }

    setUploading(true)
    setError(null)
    setResult(null)
    setProgress(0)

    let lastError = null
    let uploadSuccess = false
    let finalData = null

    // Dual Key Failover Loop
    for (const key of SUPABASE_API_KEYS) {
      try {
        const formData = new FormData()
        formData.append('file', file)

        const response = await fetch(SUPABASE_UPLOAD_URL, {
          method: 'POST',
          headers: { 'x-api-key': key },
          body: formData
        })

        const data = await response.json()

        if (data.success && data.url) {
          uploadSuccess = true
          finalData = data
          break // Success! Exit loop
        } else {
          lastError = data.message || data.error || 'Gagal dengan API Key ini.'
        }
      } catch (err) {
        lastError = 'Terjadi kesalahan koneksi saat mengunggah.'
      }
    }

    if (uploadSuccess) {
      try {
        const regRes = await fetch('/api/upload', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            url: finalData.url,
            fileName: file.name,
            fileSize: file.size,
            fileType: file.type
          })
        })

        const regData = await regRes.json()

        if (regData.success) {
          setResult({ url: finalData.url })
          setFile(null)
          fetchHistory()
        } else {
          setError('File terunggah tapi gagal dicatat ke riwayat.')
        }
      } catch (e) {
        setError('Error saat mencatat ke riwayat: ' + e.message)
      }
    } else {
      setError(lastError)
    }

    setUploading(false)
    setProgress(0)
  }

  const handleDelete = async (id) => {
    if (!confirm('Hapus file ini dari riwayat? (File di CDN mungkin tetap ada)')) return
    
    try {
      const res = await fetch('/api/upload', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      })
      const data = await res.json()
      if (data.success) {
        fetchHistory()
      } else {
        toast.error('Gagal menghapus: ' + data.error)
      }
    } catch (e) {
      toast.error('Error: ' + e.message)
    }
  }

  const copyToClipboard = (text) => {
    const fullUrl = text.startsWith('http') ? text : window.location.origin + text
    navigator.clipboard.writeText(fullUrl)
    toast.success('Link berhasil disalin!')
  }

  const formatSize = (bytes) => {
    if (!bytes) return '0 B'
    const k = 1024
    const sizes = ['B', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  return (
    <main className="container" style={{ padding: '2rem 1rem 6rem' }}>
      <div className="upload-header flex items-center gap-4" style={{ marginBottom: '2rem' }}>
        <Link href="/admin" className="btn btn-outline" style={{ padding: '0.4rem 0.8rem', fontSize: '0.85rem' }}>← Dashboard</Link>
        <h1 className="title-responsive" style={{ fontWeight: 900, letterSpacing: '-0.02em' }}>Upload Center (CDN)</h1>
      </div>

      <div className="upload-grid">
        <div className="flex flex-col gap-6">
          <div className="glass-card">
            <h2 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '1.2rem' }}>Upload File (Supabase CDN)</h2>
            <p className="text-secondary" style={{ fontSize: '0.85rem', marginBottom: '1.5rem', lineHeight: 1.5 }}>
              Mendukung semua format file hingga **2GB**. Menggunakan API CDN Eksternal.
            </p>

            <form onSubmit={handleUpload} className="flex flex-col gap-4">
              <div 
                style={{ 
                  border: '2px dashed rgba(139, 92, 246, 0.3)', 
                  borderRadius: '1rem', 
                  padding: '2rem 1rem', 
                  textAlign: 'center',
                  cursor: 'pointer',
                  background: file ? 'rgba(139, 92, 246, 0.05)' : 'rgba(255,255,255,0.01)',
                  transition: 'all 0.3s ease'
                }}
                onClick={() => document.getElementById('fileInput').click()}
              >
                <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>{file ? '📄' : '📤'}</div>
                <p style={{ fontWeight: 700, fontSize: '0.9rem', color: file ? '#c084fc' : '#fff' }}>
                  {file ? file.name : 'Klik atau Taruh File'}
                </p>
                {file && <p style={{ fontSize: '0.75rem', color: '#71717a', marginTop: '0.5rem' }}>{formatSize(file.size)}</p>}
                <input id="fileInput" type="file" hidden onChange={(e) => setFile(e.target.files[0])} />
              </div>

              <button 
                type="submit" 
                className="btn btn-primary" 
                disabled={!file || uploading}
                style={{ width: '100%', padding: '0.85rem', fontWeight: 800 }}
              >
                {uploading ? 'SEDANG MENGUNGGAH...' : 'UPLOAD SEKARANG'}
              </button>
            </form>

            {error && (
              <div style={{ marginTop: '1.5rem', padding: '1rem', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: '0.75rem', color: '#f87171', fontSize: '0.85rem', fontWeight: 600 }}>
                ⚠️ {error}
              </div>
            )}
          </div>

          {result && (
            <div className="glass-card animate-fadeInDown" style={{ border: '1px solid #10b981' }}>
              <h3 style={{ color: '#10b981', fontWeight: 800, fontSize: '1rem', marginBottom: '1rem' }}>✓ Upload Berhasil!</h3>
              <div style={{ background: 'rgba(0,0,0,0.2)', padding: '1rem', borderRadius: '0.75rem', fontSize: '0.85rem' }}>
                <p className="text-secondary" style={{ marginBottom: '0.5rem' }}>Link File Supabase:</p>
                <div className="flex flex-col gap-2">
                  <input readOnly value={result.url} className="input" style={{ background: '#000', fontSize: '0.8rem' }} />
                  <button className="btn btn-outline" style={{ width: '100%' }} onClick={() => copyToClipboard(result.url)}>Salin URL</button>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="glass-card flex flex-col" style={{ minWidth: 0 }}>
          <div className="flex justify-between items-center" style={{ marginBottom: '1.5rem' }}>
            <h2 style={{ fontSize: '1.25rem', fontWeight: 800 }}>Riwayat Upload</h2>
            <button onClick={fetchHistory} className="btn btn-outline" style={{ fontSize: '0.75rem', padding: '0.4rem 0.8rem' }}>🔄 Refresh</button>
          </div>

          {loadingHistory ? (
            <div style={{ textAlign: 'center', padding: '3rem', color: '#71717a', fontSize: '0.9rem' }}>Memuat riwayat...</div>
          ) : history.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '3rem', color: '#71717a', fontSize: '0.9rem' }}>Belum ada file.</div>
          ) : (
            <div className="flex flex-col gap-3">
              {history.map((item) => (
                <div key={item.id} className="history-item flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3" style={{ flex: 1, minWidth: 0 }}>
                    <div className="file-icon-box">
                      {item.fileType?.includes('image') ? '🖼️' : item.fileName?.match(/\.(zip|7z|rar)$/i) ? '📦' : '📄'}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p className="file-name">{item.fileName}</p>
                      <p className="file-meta">{formatSize(item.fileSize)} • {new Date(item.createdAt).toLocaleDateString('id-ID')}</p>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => copyToClipboard(item.url)} className="action-btn" title="Salin Link">🔗</button>
                    <a href={item.url} target="_blank" className="action-btn" title="Buka">↗️</a>
                    <button onClick={() => handleDelete(item.id)} className="action-btn" title="Hapus" style={{ color: '#ef4444' }}>🗑️</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      
      <style jsx>{`
        .upload-grid { display: grid; grid-template-columns: 1fr; gap: 1.5rem; }
        @media (min-width: 1024px) { .upload-grid { grid-template-columns: 420px 1fr; gap: 2rem; } }
        .title-responsive { font-size: clamp(1.25rem, 5vw, 2.25rem); }
        .history-item { padding: 0.85rem 1rem; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); border-radius: 0.85rem; }
        .file-icon-box { width: 36px; height: 36px; background: rgba(139, 92, 246, 0.1); border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; }
        .file-name { font-weight: 700; font-size: 0.85rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: #fff; }
        .file-meta { font-size: 0.7rem; color: #71717a; margin-top: 2px; }
        .action-btn { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 6px; cursor: pointer; font-size: 0.85rem; transition: all 0.2s; color: #fff; text-decoration: none; }
        .action-btn:hover { background: rgba(139, 92, 246, 0.2); border-color: rgba(139, 92, 246, 0.4); }
        .animate-fadeInDown { animation: fadeInDown 0.4s ease-out; }
        @media (max-width: 640px) { .upload-header { flex-direction: column; align-items: flex-start; gap: 0.75rem; } }
      `}</style>
    </main>
  )
}
