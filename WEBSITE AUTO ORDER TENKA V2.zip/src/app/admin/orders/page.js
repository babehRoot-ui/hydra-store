import { prisma } from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import OrdersClient from './OrdersClient'

async function updateResi(formData) {
  'use server'
  const id = formData.get('id')
  const resi = formData.get('resi')
  const status = formData.get('status')

  await prisma.order.update({
    where: { id },
    data: { 
      receiptCode: resi,
      status: status
    }
  })

  revalidatePath('/admin/orders')
}

export default async function AdminOrders() {
  const orders = await prisma.order.findMany({
    include: { product: true },
    orderBy: { createdAt: 'desc' }
  })

  return <OrdersClient orders={orders} updateResiAction={updateResi} />
}
