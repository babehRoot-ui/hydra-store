'use client'
import Link from 'next/link'

export default function OrdersClient({ orders, updateResiAction }) {
  return (
    <main className="container" style={{ padding: '2rem 0' }}>
      <style jsx>{`
        .mobile-order-card {
          display: none;
          padding: 1.5rem;
          border-bottom: 1px solid var(--card-border);
          flex-direction: column;
          gap: 1rem;
        }
        @media (max-width: 768px) {
          .mobile-order-card {
            display: flex;
          }
          .desktop-order-table {
            display: none;
          }
          .header-flex {
            flex-direction: column;
            align-items: flex-start !important;
            gap: 1rem;
          }
        }
      `}</style>

      <div className="header-flex flex justify-between items-center" style={{ marginBottom: '2rem' }}>
        <div className="flex items-center gap-4">
          <Link href="/admin" className="text-secondary" style={{ fontSize: '0.9rem' }}>← Kembali</Link>
          <h1 style={{ fontSize: 'clamp(1.5rem, 4vw, 2rem)', fontWeight: 800 }}>Manajemen Pesanan</h1>
        </div>
      </div>

      <div className="glass-card" style={{ padding: 0, overflow: 'hidden' }}>
        {/* View Mobile */}
        <div className="mobile-order-wrapper">
          {orders.map(order => (
            <div key={order.id} className="mobile-order-card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontFamily: 'monospace', fontSize: '0.75rem', color: '#a1a1aa' }}>#{order.id.slice(-8)}</span>
                <span style={{ 
                  padding: '0.25rem 0.75rem', 
                  borderRadius: '9999px', 
                  fontSize: '0.7rem',
                  fontWeight: 700,
                  background: order.status === 'SUCCESS' ? 'rgba(16,185,129,0.1)' : 'rgba(245,158,11,0.1)',
                  color: order.status === 'SUCCESS' ? '#10b981' : '#f59e0b'
                }}>
                  {order.status}
                </span>
              </div>
              
              <div>
                <div style={{ fontWeight: 700, fontSize: '1rem' }}>{order.product.name}</div>
                <div style={{ fontSize: '0.85rem', color: '#10b981', fontWeight: 600 }}>Rp {order.amount.toLocaleString('id-ID')}</div>
              </div>

              <div style={{ background: 'rgba(255,255,255,0.03)', padding: '0.75rem', borderRadius: '10px', fontSize: '0.85rem' }}>
                <div style={{ fontWeight: 600 }}>{order.customerName}</div>
                <div style={{ color: '#a1a1aa' }}>{order.customerPhone}</div>
              </div>

              <form action={updateResiAction} style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                <input type="hidden" name="id" value={order.id} />
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <input 
                    type="text" 
                    name="resi" 
                    placeholder="Kode Resi" 
                    className="input" 
                    defaultValue={order.receiptCode || ''}
                    style={{ flex: 1, padding: '0.5rem', fontSize: '0.85rem' }}
                  />
                  <select name="status" className="input" defaultValue={order.status} style={{ width: 'auto', padding: '0.5rem' }}>
                      <option value="PENDING">PENDING</option>
                      <option value="SUCCESS">SUCCESS</option>
                      <option value="FAILED">FAILED</option>
                  </select>
                </div>
                <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '0.6rem', fontSize: '0.85rem' }}>Update Pesanan</button>
              </form>
              
              <div style={{ fontSize: '0.7rem', color: '#52525b', textAlign: 'right' }}>
                {new Date(order.createdAt).toLocaleString('id-ID')}
              </div>
            </div>
          ))}
        </div>

        {/* View Desktop */}
        <div className="desktop-order-table" style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--card-border)', background: 'rgba(255,255,255,0.02)' }}>
                <th style={{ padding: '1rem' }}>Order ID</th>
                <th style={{ padding: '1rem' }}>Pelanggan</th>
                <th style={{ padding: '1rem' }}>Produk</th>
                <th style={{ padding: '1rem' }}>Status</th>
                <th style={{ padding: '1rem' }}>Update Resi & Status</th>
                <th style={{ padding: '1rem' }}>Waktu</th>
              </tr>
            </thead>
            <tbody>
              {orders.map(order => (
                <tr key={order.id} style={{ borderBottom: '1px solid var(--card-border)' }}>
                  <td style={{ padding: '1rem', fontFamily: 'monospace', fontSize: '0.85rem' }}>
                    {order.id}
                  </td>
                  <td style={{ padding: '1rem' }}>
                    <div style={{ fontWeight: 600 }}>{order.customerName}</div>
                    <div style={{ fontSize: '0.8rem', color: '#a1a1aa' }}>{order.customerPhone}</div>
                  </td>
                  <td style={{ padding: '1rem' }}>
                    {order.product.name}
                    <div style={{ fontSize: '0.8rem', color: '#10b981' }}>Rp {order.amount.toLocaleString('id-ID')}</div>
                  </td>
                  <td style={{ padding: '1rem' }}>
                    <span style={{ 
                      padding: '0.2rem 0.6rem', 
                      borderRadius: '9999px', 
                      fontSize: '0.75rem',
                      background: order.status === 'SUCCESS' ? 'rgba(16,185,129,0.1)' : 'rgba(245,158,11,0.1)',
                      color: order.status === 'SUCCESS' ? '#10b981' : '#f59e0b'
                    }}>
                      {order.status}
                    </span>
                  </td>
                  <td style={{ padding: '1rem' }}>
                    <form action={updateResiAction} className="flex gap-2">
                      <input type="hidden" name="id" value={order.id} />
                      <input 
                        type="text" 
                        name="resi" 
                        placeholder="Kode Resi" 
                        className="input" 
                        defaultValue={order.receiptCode || ''}
                        style={{ padding: '0.4rem 0.75rem', fontSize: '0.85rem' }}
                      />
                      <select name="status" className="input" defaultValue={order.status} style={{ padding: '0.4rem', width: 'auto' }}>
                          <option value="PENDING">PENDING</option>
                          <option value="SUCCESS">SUCCESS</option>
                          <option value="FAILED">FAILED</option>
                      </select>
                      <button type="submit" className="btn btn-primary" style={{ padding: '0.4rem 1rem', fontSize: '0.85rem' }}>Save</button>
                    </form>
                  </td>
                  <td style={{ padding: '1rem', fontSize: '0.8rem', color: '#52525b' }}>
                    {new Date(order.createdAt).toLocaleString('id-ID')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </main>
  )
}
