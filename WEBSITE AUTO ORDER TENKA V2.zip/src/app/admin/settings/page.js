'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'

const WELCOME_TYPES = [
  { value: 'image', label: '🖼️ Foto + Teks', desc: 'Tampilkan gambar/foto dengan judul & deskripsi' },
  { value: 'video', label: '🎬 Video + Teks', desc: 'Tampilkan video dengan judul & deskripsi' },
  { value: 'text', label: '✍️ Teks Saja', desc: 'Tampilkan teks sambutan tanpa media' },
  { value: 'audio', label: '🎵 Audio + Teks', desc: 'Musik latar dengan sambutan teks' },
]

// Supabase CDN Configuration with Dual Key Failover
const SUPABASE_UPLOAD_URL = 'https://yxwcqbvumcxyahiknszr.supabase.co/functions/v1/api-upload'
const SUPABASE_API_KEYS = [
  'zzzz_JWXDHqIlDu5qPVr8C5yIM14NCxKP1WR1Fw9NgDwF', // Key Utama
  'zzzz_BKpEaA01t9yKYDhQ8h8NSUf6CR6J40mXqsy5c7Ec'  // Key Cadangan
]

async function robustUpload(file) {
  let lastError = null
  for (const key of SUPABASE_API_KEYS) {
    try {
      const fd = new FormData()
      fd.append('file', file)
      const res = await fetch(SUPABASE_UPLOAD_URL, {
        method: 'POST',
        headers: { 'x-api-key': key },
        body: fd
      })
      const data = await res.json()
      if (data.success && data.url) return { success: true, url: data.url }
      lastError = data.message || data.error || 'API Error'
    } catch (err) {
      lastError = err.message
    }
  }
  return { success: false, error: lastError }
}

const Section = ({ title, icon, color = '#8b5cf6', children }) => (
  <div style={{
    background: 'rgba(255,255,255,0.02)',
    border: `1px solid ${color}33`,
    borderRadius: '16px',
    padding: '1.5rem',
    marginBottom: '1.5rem'
  }}>
    <h2 style={{ fontSize: '1.1rem', fontWeight: 700, color, marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
      <span>{icon}</span> {title}
    </h2>
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
      {children}
    </div>
  </div>
)

const Field = ({ label, hint, children }) => (
  <div>
    <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: '#a1a1aa', marginBottom: '0.4rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
      {label}
    </label>
    {children}
    {hint && <p style={{ fontSize: '0.72rem', color: '#52525b', marginTop: '0.35rem' }}>{hint}</p>}
  </div>
)

const Input = (props) => (
  <input
    {...props}
    className="input"
    style={{ width: '100%', ...props.style }}
  />
)

const Textarea = (props) => (
  <textarea
    {...props}
    className="input"
    style={{ width: '100%', resize: 'vertical', ...props.style }}
  />
)

export default function SettingsPage() {
  const [env, setEnv] = useState({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState(null)
  const [activeTab, setActiveTab] = useState('welcome')

  // Uploading states
  const [upImage, setUpImage] = useState(false)
  const [upVideo, setUpVideo] = useState(false)
  const [upAudio, setUpAudio] = useState(false)
  const [upGlobalBg, setUpGlobalBg] = useState(false)

  useEffect(() => {
    fetch('/api/admin/settings')
      .then(r => r.json())
      .then(d => {
        if (d.success) setEnv(d.env)
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  const set = (key, val) => setEnv(prev => ({ ...prev, [key]: val }))

  const handleSave = async () => {
    setSaving(true)
    setMsg(null)
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(env)
      })
      const data = await res.json()
      setMsg({ ok: data.success, text: data.message })
    } catch (err) {
      setMsg({ ok: false, text: 'Error: ' + err.message })
    } finally {
      setSaving(false)
      setTimeout(() => setMsg(null), 4000)
    }
  }

  const handleMediaUpload = async (e, type) => {
    const file = e.target.files[0]
    if (!file) return

    if (type === 'image') setUpImage(true)
    if (type === 'video') setUpVideo(true)
    if (type === 'audio') setUpAudio(true)

    const res = await robustUpload(file)
    if (res.success) {
      if (type === 'image') set('WELCOME_IMAGE', res.url)
      if (type === 'video') set('WELCOME_VIDEO', res.url)
      if (type === 'audio') set('WELCOME_MUSIC_URL', res.url)
      setMsg({ ok: true, text: 'File berhasil diunggah!' })
    } else {
      setMsg({ ok: false, text: 'Gagal unggah: ' + res.error })
    }

    setUpImage(false)
    setUpVideo(false)
    setUpAudio(false)
    setUpGlobalBg(false)
    setTimeout(() => setMsg(null), 3000)
  }

  const handleGlobalBgDrop = async (e) => {
    e.preventDefault()
    e.stopPropagation()
    const file = e.dataTransfer?.files[0]
    if (!file) return
    await processGlobalBgUpload(file)
  }

  const handleGlobalBgFile = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    await processGlobalBgUpload(file)
  }

  const processGlobalBgUpload = async (file) => {
    // 3GB is huge, but we allow it visually. CDN limits might still apply.
    if (file.size > 3 * 1024 * 1024 * 1024) {
      setMsg({ ok: false, text: 'File melebihi batas 3GB.' })
      return
    }

    setUpGlobalBg(true)
    const res = await robustUpload(file)
    if (res.success) {
      set('GLOBAL_BG_URL', res.url)
      // Auto detect type based on MIME
      if (file.type.startsWith('video/')) set('GLOBAL_BG_TYPE', 'video')
      else set('GLOBAL_BG_TYPE', 'image')
      
      setMsg({ ok: true, text: 'Background berhasil diunggah!' })
    } else {
      setMsg({ ok: false, text: 'Gagal unggah: ' + res.error })
    }
    setUpGlobalBg(false)
    setTimeout(() => setMsg(null), 3000)
  }

  const tabs = [
    { id: 'welcome', label: '🏠 Tampilan Awal', },
    { id: 'background', label: '🌌 Latar Web', },
    { id: 'music', label: '🎵 Musik Latar', },
    { id: 'store', label: '🏪 Info Toko', },
    { id: 'payment', label: '💳 Pembayaran', },
    { id: 'ptero', label: '🦕 Panel/Server', },
    { id: 'admin', label: '🔑 Akun Admin', },
  ]

  if (loading) return (
    <main className="container" style={{ padding: '4rem 0', textAlign: 'center' }}>
      <div style={{ color: '#a1a1aa' }}>⏳ Memuat konfigurasi...</div>
    </main>
  )

  return (
    <main className="container" style={{ padding: '3rem 0', maxWidth: '860px' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
        <Link href="/admin" style={{ color: '#a1a1aa', textDecoration: 'none', fontSize: '0.9rem' }}>← Kembali</Link>
        <div>
          <h1 style={{ fontSize: '2rem', fontWeight: 800 }}>⚙️ Pengaturan Sistem</h1>
          <p style={{ color: '#71717a', fontSize: '0.85rem', marginTop: '0.2rem' }}>Konfigurasi lengkap toko & tampilan</p>
        </div>
      </div>

      {/* Tab Navigation */}
      <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '2rem', padding: '0.5rem', background: 'rgba(255,255,255,0.03)', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.06)' }}>
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            style={{
              padding: '0.5rem 1rem',
              borderRadius: '8px',
              fontSize: '0.82rem',
              fontWeight: 600,
              border: 'none',
              cursor: 'pointer',
              fontFamily: 'inherit',
              transition: 'all 0.2s',
              background: activeTab === t.id ? 'linear-gradient(135deg, #8b5cf6, #ec4899)' : 'transparent',
              color: activeTab === t.id ? 'white' : '#71717a',
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ─── TAB: TAMPILAN AWAL ─── */}
      {activeTab === 'welcome' && (
        <div>
          <Section title="Tipe Tampilan Sambutan" icon="🎨" color="#8b5cf6">
            <Field label="Pilih Tipe Tampilan" hint="Tipe ini menentukan konten apa yang muncul saat pengunjung pertama kali membuka web.">
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                {WELCOME_TYPES.map(t => (
                  <div
                    key={t.value}
                    onClick={() => set('WELCOME_TYPE', t.value)}
                    style={{
                      padding: '1rem',
                      borderRadius: '10px',
                      border: `2px solid ${env.WELCOME_TYPE === t.value ? '#8b5cf6' : 'rgba(255,255,255,0.07)'}`,
                      background: env.WELCOME_TYPE === t.value ? 'rgba(139,92,246,0.15)' : 'rgba(255,255,255,0.02)',
                      cursor: 'pointer',
                      transition: 'all 0.2s'
                    }}
                  >
                    <div style={{ fontWeight: 700, fontSize: '0.9rem', marginBottom: '0.3rem' }}>{t.label}</div>
                    <div style={{ fontSize: '0.75rem', color: '#71717a' }}>{t.desc}</div>
                  </div>
                ))}
              </div>
            </Field>
          </Section>

          <Section title="Konten Sambutan" icon="📝" color="#3b82f6">
            <Field label="Judul Sambutan" hint="Teks besar yang muncul sebagai judul utama halaman sambutan.">
              <Input value={env.WELCOME_TITLE || ''} onChange={e => set('WELCOME_TITLE', e.target.value)} placeholder="Selamat Datang di Tenka Store 🚀" />
            </Field>
            <Field label="Teks Deskripsi / Sambutan" hint="Paragraf pendek di bawah judul. Bisa berisi promosi, tagline, atau informasi toko.">
              <Textarea
                value={env.WELCOME_TEXT || ''}
                onChange={e => set('WELCOME_TEXT', e.target.value)}
                rows={4}
                placeholder="Toko script & bot WhatsApp terpercaya. No encrypt, update seumur hidup, support 24 jam..."
              />
            </Field>
            <Field label="Link Tombol Dokumen / Info" hint="URL tombol CTA (call-to-action) di bawah sambutan. Bisa link WhatsApp, Telegram, atau halaman lain.">
              <Input value={env.WELCOME_DOC_LINK || ''} onChange={e => set('WELCOME_DOC_LINK', e.target.value)} placeholder="https://wa.me/628xxx atau https://t.me/xxx" />
            </Field>
          </Section>

          <Section title="Media Sambutan" icon="🖼️" color="#10b981">
            {/* FOTO */}
            <Field label="Foto / Gambar Sambutan" hint="JPG/PNG/GIF/WebP. Aktif jika tipe = Foto + Teks.">
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                <Input value={env.WELCOME_IMAGE || ''} onChange={e => set('WELCOME_IMAGE', e.target.value)} placeholder="https://i.imgur.com/xxx.png" />
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                   <input type="file" accept="image/*" onChange={e => handleMediaUpload(e, 'image')} style={{ fontSize: '0.75rem', flex: 1 }} />
                   {upImage && <span style={{ fontSize: '0.7rem', color: '#3b82f6' }}>⏳ Uploading...</span>}
                </div>
              </div>
              {env.WELCOME_IMAGE && (
                <img src={env.WELCOME_IMAGE} alt="Preview" style={{ marginTop: '0.75rem', maxHeight: '160px', borderRadius: '10px', objectFit: 'cover', border: '1px solid rgba(255,255,255,0.1)' }} />
              )}
            </Field>

            {/* VIDEO */}
            <Field label="Video Sambutan" hint="Link video MP4 atau embed YouTube. Aktif jika tipe = Video + Teks.">
               <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                <Input value={env.WELCOME_VIDEO || ''} onChange={e => set('WELCOME_VIDEO', e.target.value)} placeholder="https://cdn.../video.mp4" />
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                   <input type="file" accept="video/*" onChange={e => handleMediaUpload(e, 'video')} style={{ fontSize: '0.75rem', flex: 1 }} />
                   {upVideo && <span style={{ fontSize: '0.7rem', color: '#3b82f6' }}>⏳ Uploading...</span>}
                </div>
              </div>
            </Field>
          </Section>
        </div>
      )}

      {/* ─── TAB: LATAR WEB (GLOBAL BG) ─── */}
      {activeTab === 'background' && (
        <div>
          <Section title="Latar Belakang Website (Global)" icon="🌌" color="#6366f1">
            <div style={{ padding: '0.8rem 1rem', background: 'rgba(99,102,241,0.1)', border: '1px solid rgba(99,102,241,0.3)', borderRadius: '10px', fontSize: '0.85rem', color: '#a5b4fc', marginBottom: '1rem', lineHeight: 1.5 }}>
              Latar belakang ini akan menimpa warna gelap standar website dan terlihat di <strong>seluruh halaman</strong>. Disarankan menggunakan media yang agak gelap agar teks tetap terbaca.
            </div>

            <Field label="Tipe Latar Belakang">
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.75rem', marginBottom: '1rem' }}>
                {['default', 'image', 'video'].map(type => (
                  <div
                    key={type}
                    onClick={() => set('GLOBAL_BG_TYPE', type)}
                    style={{
                      padding: '0.8rem',
                      textAlign: 'center',
                      borderRadius: '10px',
                      border: `2px solid ${env.GLOBAL_BG_TYPE === type || (type === 'default' && !env.GLOBAL_BG_TYPE) ? '#6366f1' : 'rgba(255,255,255,0.07)'}`,
                      background: env.GLOBAL_BG_TYPE === type || (type === 'default' && !env.GLOBAL_BG_TYPE) ? 'rgba(99,102,241,0.15)' : 'rgba(255,255,255,0.02)',
                      cursor: 'pointer',
                      fontSize: '0.85rem',
                      fontWeight: 600,
                      transition: 'all 0.2s'
                    }}
                  >
                    {type === 'default' ? '🌑 Standar (Gelap)' : type === 'image' ? '🖼️ Foto / Gambar' : '🎬 Video'}
                  </div>
                ))}
              </div>
            </Field>

            {(env.GLOBAL_BG_TYPE === 'image' || env.GLOBAL_BG_TYPE === 'video') && (
              <>
                <Field label={`URL ${env.GLOBAL_BG_TYPE === 'image' ? 'Gambar' : 'Video'} Latar`} hint="Masukkan link langsung, atau gunakan area upload di bawah.">
                  <Input value={env.GLOBAL_BG_URL || ''} onChange={e => set('GLOBAL_BG_URL', e.target.value)} placeholder={`https://cdn.../${env.GLOBAL_BG_TYPE === 'image' ? 'bg.png' : 'bg.mp4'}`} />
                </Field>

                <Field label="Upload Latar (Max 3GB)" hint="Drag & Drop file ke kotak di bawah, atau klik untuk memilih file dari komputer.">
                  <label 
                    onDragOver={e => { e.preventDefault(); e.stopPropagation() }}
                    onDrop={handleGlobalBgDrop}
                    style={{
                      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                      gap: '0.5rem', padding: '2.5rem 1rem', marginTop: '0.5rem',
                      border: '2px dashed rgba(99,102,241,0.5)', borderRadius: '12px',
                      background: 'rgba(99,102,241,0.05)', cursor: 'pointer',
                      transition: 'all 0.2s'
                    }}
                  >
                    <input type="file" accept={env.GLOBAL_BG_TYPE === 'image' ? "image/*" : "video/*"} onChange={handleGlobalBgFile} style={{ display: 'none' }} />
                    <div style={{ fontSize: '2rem' }}>☁️</div>
                    <div style={{ fontWeight: 600, color: '#a5b4fc', textAlign: 'center' }}>
                      {upGlobalBg ? '⏳ Sedang Mengunggah...' : 'Drag & Drop File di Sini'}
                    </div>
                    {!upGlobalBg && <div style={{ fontSize: '0.75rem', color: '#6366f1' }}>atau klik untuk mencari</div>}
                  </label>
                </Field>

                {env.GLOBAL_BG_URL && (
                  <div style={{ marginTop: '1rem', borderRadius: '12px', overflow: 'hidden', border: '1px solid rgba(255,255,255,0.1)', height: '200px', position: 'relative' }}>
                    {env.GLOBAL_BG_TYPE === 'video' ? (
                      <video src={env.GLOBAL_BG_URL} autoPlay loop muted playsInline style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    ) : (
                      <img src={env.GLOBAL_BG_URL} alt="Global BG" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    )}
                    <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(0,0,0,0.8), transparent)', display: 'flex', alignItems: 'flex-end', padding: '1rem' }}>
                      <span style={{ fontSize: '0.8rem', fontWeight: 600, color: 'white' }}>Preview Latar Belakang</span>
                    </div>
                  </div>
                )}
              </>
            )}
          </Section>
        </div>
      )}

      {/* ─── TAB: MUSIK LATAR ─── */}
      {activeTab === 'music' && (
        <div>
          <Section title="Musik Latar Background" icon="🎵" color="#ec4899">
            <Field label="URL Audio / Musik" hint="Link audio MP3/OGG/WAV langsung.">
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                <Input value={env.WELCOME_MUSIC_URL || ''} onChange={e => set('WELCOME_MUSIC_URL', e.target.value)} placeholder="https://cdn.../musik.mp3" />
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                   <input type="file" accept="audio/*" onChange={e => handleMediaUpload(e, 'audio')} style={{ fontSize: '0.75rem', flex: 1 }} />
                   {upAudio && <span style={{ fontSize: '0.7rem', color: '#3b82f6' }}>⏳ Uploading...</span>}
                </div>
              </div>
            </Field>

            {env.WELCOME_MUSIC_URL && (
              <Field label="Preview Audio">
                <audio controls key={env.WELCOME_MUSIC_URL} style={{ width: '100%', marginTop: '0.5rem' }}>
                  <source src={env.WELCOME_MUSIC_URL} />
                  Browser tidak mendukung pemutar audio.
                </audio>
              </Field>
            )}
            <div style={{ padding: '1rem', background: 'rgba(236,72,153,0.05)', border: '1px solid rgba(236,72,153,0.2)', borderRadius: '10px', fontSize: '0.8rem', color: '#f9a8d4', marginTop: '1rem' }}>
              💡 <strong>Tips sumber audio gratis:</strong> SoundCloud, Pixabay Music, Free Music Archive, atau upload ke Supabase CDN Anda lalu salin URL-nya.
            </div>
          </Section>
        </div>
      )}

      {/* ─── TAB: INFO TOKO ─── */}
      {activeTab === 'store' && (
        <div>
          <Section title="Identitas Toko" icon="🏪" color="#f59e0b">
            <Field label="Nama Toko" hint="Nama toko yang tampil di navbar dan halaman utama.">
              <Input value={env.STORE_NAME || ''} onChange={e => set('STORE_NAME', e.target.value)} placeholder="Tenka Store" />
            </Field>
            <Field label="Tagline Toko" hint="Kalimat singkat di bawah nama toko.">
              <Input value={env.STORE_TAGLINE || ''} onChange={e => set('STORE_TAGLINE', e.target.value)} placeholder="Script & Bot WhatsApp Terpercaya" />
            </Field>
          </Section>

          <Section title="Tombol Hubungi Admin" icon="💬" color="#10b981">
            <Field label="Teks Tombol" hint="Tulisan yang akan tampil pada tombol melayang di pojok layar. (Contoh: Hubungi Admin, Chat WhatsApp)">
              <Input value={env.CONTACT_ADMIN_TEXT || ''} onChange={e => set('CONTACT_ADMIN_TEXT', e.target.value)} placeholder="Hubungi Admin" />
            </Field>
            <Field label="Link Tujuan / Nomor WhatsApp" hint="Bisa berupa nomor WA (contoh: 628123456789) atau link penuh (https://wa.me/...). Kosongkan jika tidak ingin tombol tampil.">
              <Input value={env.CONTACT_ADMIN_LINK || ''} onChange={e => set('CONTACT_ADMIN_LINK', e.target.value)} placeholder="628xxxxxxxxxxx atau https://..." />
            </Field>
          </Section>

          <Section title="Tombol Bio Links (Connect)" icon="🔗" color="#c084fc">
            <Field label="Tampilkan Tombol Bio Links" hint="Apakah tombol menuju halaman link bio ditampilkan di navbar?">
              <select 
                className="input" 
                value={env.LINKBIO_SHOW || 'no'} 
                onChange={e => set('LINKBIO_SHOW', e.target.value)}
              >
                <option value="yes">Tampilkan</option>
                <option value="no">Sembunyikan</option>
              </select>
            </Field>
            <Field label="Nama Tombol" hint="Teks yang tampil di navbar (Contoh: Connect, Link Kami, Sosial Media)">
              <Input value={env.LINKBIO_NAME || ''} onChange={e => set('LINKBIO_NAME', e.target.value)} placeholder="Connect" />
            </Field>
          </Section>

          <Section title="Pengaturan Urutan Produk" icon="🔃" color="#ec4899">
            <Field label="Urutkan Produk Berdasarkan" hint="Tentukan bagaimana produk diurutkan di halaman depan website Anda.">
              <select 
                className="input" 
                value={env.PRODUCT_SORT || 'cheapest'} 
                onChange={e => set('PRODUCT_SORT', e.target.value)}
                style={{ width: '100%', cursor: 'pointer' }}
              >
                <option value="cheapest">Default (Termurah ke Termahal)</option>
                <option value="expensive">Termahal ke Termurah</option>
                <option value="latest">Terbaru (Waktu Upload)</option>
                <option value="random">Acak (Random)</option>
              </select>
            </Field>
          </Section>
        </div>
      )}

      {/* ─── TAB: PEMBAYARAN ─── */}
      {activeTab === 'payment' && (
        <div>
          <Section title="Payment Gateway Aktif" icon="🔀" color="#8b5cf6">
            <Field label="Pilih Gateway Utama" hint="Sistem pembayaran yang akan digunakan oleh pembeli saat checkout.">
              <select 
                className="input" 
                value={env.ACTIVE_GATEWAY || 'PAKASIR'} 
                onChange={e => set('ACTIVE_GATEWAY', e.target.value)}
                style={{ width: '100%', cursor: 'pointer' }}
              >
                <option value="PAKASIR">Pakasir (QRIS)</option>
                <option value="ATLANTIC">Atlantic Payment (QRIS & E-Wallet)</option>
                <option value="DOKU">DOKU (QRIS, E-Wallet, VA)</option>
                <option value="TRIPAY">Tripay (QRIS, E-Wallet, Retail, VA)</option>
                <option value="MAYAR">Mayar (Payment Link, QRIS, Creator)</option>
                <option value="DURIANPAY">Durianpay (VA, E-Wallet, QRIS)</option>
                <option value="UANGX">UangX (QRIS, E-Wallet, VA)</option>
                <option value="MIDTRANS">Midtrans (QRIS, E-Wallet, VA, Bank Transfer)</option>
                <option value="XENDIT">Xendit (Invoice, VA, QRIS, E-Wallet, Retail)</option>
                <option value="FASPAY">Faspay (VA, Credit Card, E-Wallet, Retail)</option>
                <option value="IPAYMU">iPaymu (QRIS, VA, Bank Transfer, Retail)</option>
                <option value="FINPAY">Finpay (VA, E-Wallet, Retail, CC)</option>
                <option value="ESPAY">Espay (QRIS, VA, E-Wallet, Retail, CC)</option>
                <option value="DUITKU">Duitku (VA, E-Wallet, Retail, CC, QRIS)</option>
                <option value="OY">OY! Bisnis (Invoice, VA, QRIS, E-Wallet)</option>
              </select>
            </Field>
          </Section>

          <Section title="OY! Bisnis Payment Gateway" icon="💳" color="#10b981">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <Field label="OY! User ID" hint="User ID / Username dari Dashboard OY! Bisnis Anda.">
                <Input value={env.OY_USER_ID || ''} onChange={e => set('OY_USER_ID', e.target.value)} placeholder="Misal: tenkastore" disabled={env.ACTIVE_GATEWAY !== 'OY'} />
              </Field>
              <Field label="API Key" hint="API Key dari Dashboard OY! Bisnis.">
                <Input type="password" value={env.OY_API_KEY || ''} onChange={e => set('OY_API_KEY', e.target.value)} placeholder="API-Key-..." disabled={env.ACTIVE_GATEWAY !== 'OY'} />
              </Field>
            </div>
            <Field label="Environment Mode">
              <select 
                className="input" 
                value={env.OY_IS_PRODUCTION || 'no'} 
                onChange={e => set('OY_IS_PRODUCTION', e.target.value)}
                disabled={env.ACTIVE_GATEWAY !== 'OY'}
              >
                <option value="no">Sandbox / Staging</option>
                <option value="yes">Production / Live</option>
              </select>
            </Field>
          </Section>

          <Section title="Duitku Payment Gateway" icon="💳" color="#0ea5e9">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <Field label="Merchant Code" hint="Merchant Code dari Dashboard Duitku Anda.">
                <Input value={env.DUITKU_MERCHANT_CODE || ''} onChange={e => set('DUITKU_MERCHANT_CODE', e.target.value)} placeholder="Misal: D1234" disabled={env.ACTIVE_GATEWAY !== 'DUITKU'} />
              </Field>
              <Field label="API Key" hint="API Key / Merchant Key dari Dashboard Duitku.">
                <Input type="password" value={env.DUITKU_API_KEY || ''} onChange={e => set('DUITKU_API_KEY', e.target.value)} placeholder="API-Key-..." disabled={env.ACTIVE_GATEWAY !== 'DUITKU'} />
              </Field>
            </div>
            <Field label="Environment Mode">
              <select 
                className="input" 
                value={env.DUITKU_IS_PRODUCTION || 'no'} 
                onChange={e => set('DUITKU_IS_PRODUCTION', e.target.value)}
                disabled={env.ACTIVE_GATEWAY !== 'DUITKU'}
              >
                <option value="no">Sandbox / Testing</option>
                <option value="yes">Production / Live</option>
              </select>
            </Field>
          </Section>

          <Section title="Espay Payment Gateway" icon="💳" color="#3b82f6">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <Field label="Espay API Key" hint="API Key dari Dashboard Espay Anda.">
                <Input value={env.ESPAY_API_KEY || ''} onChange={e => set('ESPAY_API_KEY', e.target.value)} placeholder="API-Key-..." disabled={env.ACTIVE_GATEWAY !== 'ESPAY'} />
              </Field>
              <Field label="Signature Key" hint="Signature Key untuk verifikasi data.">
                <Input type="password" value={env.ESPAY_SIGNATURE_KEY || ''} onChange={e => set('ESPAY_SIGNATURE_KEY', e.target.value)} placeholder="Signature-Key-..." disabled={env.ACTIVE_GATEWAY !== 'ESPAY'} />
              </Field>
            </div>
            <Field label="Environment Mode">
              <select 
                className="input" 
                value={env.ESPAY_IS_PRODUCTION || 'no'} 
                onChange={e => set('ESPAY_IS_PRODUCTION', e.target.value)}
                disabled={env.ACTIVE_GATEWAY !== 'ESPAY'}
              >
                <option value="no">Sandbox / Testing</option>
                <option value="yes">Production / Live</option>
              </select>
            </Field>
          </Section>

          <Section title="Finpay Payment Gateway" icon="💳" color="#ef4444">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <Field label="Merchant ID" hint="Merchant ID dari Finpay.">
                <Input value={env.FINPAY_MERCHANT_ID || ''} onChange={e => set('FINPAY_MERCHANT_ID', e.target.value)} placeholder="Misal: 123456" disabled={env.ACTIVE_GATEWAY !== 'FINPAY'} />
              </Field>
              <Field label="Merchant Key" hint="Merchant Secret Key Finpay.">
                <Input type="password" value={env.FINPAY_MERCHANT_KEY || ''} onChange={e => set('FINPAY_MERCHANT_KEY', e.target.value)} placeholder="Secret-Key-..." disabled={env.ACTIVE_GATEWAY !== 'FINPAY'} />
              </Field>
            </div>
            <Field label="Environment Mode">
              <select 
                className="input" 
                value={env.FINPAY_IS_PRODUCTION || 'no'} 
                onChange={e => set('FINPAY_IS_PRODUCTION', e.target.value)}
                disabled={env.ACTIVE_GATEWAY !== 'FINPAY'}
              >
                <option value="no">Sandbox / Testing</option>
                <option value="yes">Production / Live</option>
              </select>
            </Field>
          </Section>

          <Section title="iPaymu Payment Gateway" icon="💳" color="#3b82f6">
            <Field label="iPaymu VA (Virtual Account)" hint="Nomor Virtual Account utama dari akun iPaymu Anda.">
              <Input value={env.IPAYMU_VA || ''} onChange={e => set('IPAYMU_VA', e.target.value)} placeholder="000000xxxxxxxxxx" disabled={env.ACTIVE_GATEWAY !== 'IPAYMU'} />
            </Field>
            <Field label="iPaymu API Key" hint="API Key dari Dashboard iPaymu Anda.">
              <Input type="password" value={env.IPAYMU_API_KEY || ''} onChange={e => set('IPAYMU_API_KEY', e.target.value)} placeholder="API-Key-..." disabled={env.ACTIVE_GATEWAY !== 'IPAYMU'} />
            </Field>
            <Field label="Environment Mode">
              <select 
                className="input" 
                value={env.IPAYMU_IS_PRODUCTION || 'no'} 
                onChange={e => set('IPAYMU_IS_PRODUCTION', e.target.value)}
                disabled={env.ACTIVE_GATEWAY !== 'IPAYMU'}
              >
                <option value="no">Sandbox (Testing)</option>
                <option value="yes">Production (Live)</option>
              </select>
            </Field>
          </Section>

          <Section title="Faspay Payment Gateway" icon="💎" color="#f59e0b">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <Field label="Merchant ID" hint="Merchant ID dari Faspay.">
                <Input value={env.FASPAY_MERCHANT_ID || ''} onChange={e => set('FASPAY_MERCHANT_ID', e.target.value)} placeholder="Misal: 12345" disabled={env.ACTIVE_GATEWAY !== 'FASPAY'} />
              </Field>
              <Field label="Merchant Name" hint="Nama toko yang terdaftar di Faspay.">
                <Input value={env.FASPAY_MERCHANT_NAME || ''} onChange={e => set('FASPAY_MERCHANT_NAME', e.target.value)} placeholder="Tenka Store" disabled={env.ACTIVE_GATEWAY !== 'FASPAY'} />
              </Field>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <Field label="User ID" hint="User ID untuk API Faspay.">
                <Input value={env.FASPAY_USER_ID || ''} onChange={e => set('FASPAY_USER_ID', e.target.value)} placeholder="fasp-..." disabled={env.ACTIVE_GATEWAY !== 'FASPAY'} />
              </Field>
              <Field label="Password" hint="Password API Faspay.">
                <Input type="password" value={env.FASPAY_PASSWORD || ''} onChange={e => set('FASPAY_PASSWORD', e.target.value)} placeholder="••••••••" disabled={env.ACTIVE_GATEWAY !== 'FASPAY'} />
              </Field>
            </div>
            <Field label="Environment Mode">
              <select 
                className="input" 
                value={env.FASPAY_IS_PRODUCTION || 'no'} 
                onChange={e => set('FASPAY_IS_PRODUCTION', e.target.value)}
                disabled={env.ACTIVE_GATEWAY !== 'FASPAY'}
              >
                <option value="no">Development / Sandbox</option>
                <option value="yes">Production / Live</option>
              </select>
            </Field>
          </Section>

          <Section title="Xendit Payment Gateway" icon="💳" color="#10b981">
            <Field label="Xendit Secret Key" hint="Secret Key dari Dashboard Xendit Anda. Jaga kerahasiaannya.">
              <Input type="password" value={env.XENDIT_SECRET_KEY || ''} onChange={e => set('XENDIT_SECRET_KEY', e.target.value)} placeholder="xnd_development_..." disabled={env.ACTIVE_GATEWAY !== 'XENDIT'} />
            </Field>
            <Field label="Xendit Callback Token" hint="Callback Verification Token dari pengaturan Webhook Xendit Anda.">
              <Input type="password" value={env.XENDIT_CALLBACK_TOKEN || ''} onChange={e => set('XENDIT_CALLBACK_TOKEN', e.target.value)} placeholder="Token untuk verifikasi webhook..." disabled={env.ACTIVE_GATEWAY !== 'XENDIT'} />
            </Field>
          </Section>

          <Section title="Midtrans Payment Gateway" icon="🛡️" color="#3b82f6">
            <Field label="Midtrans Client Key" hint="Client Key dari Dashboard Midtrans Anda.">
              <Input value={env.MIDTRANS_CLIENT_KEY || ''} onChange={e => set('MIDTRANS_CLIENT_KEY', e.target.value)} placeholder="Mid-client-..." disabled={env.ACTIVE_GATEWAY !== 'MIDTRANS'} />
            </Field>
            <Field label="Midtrans Server Key" hint="Server Key dari Dashboard Midtrans Anda.">
              <Input type="password" value={env.MIDTRANS_SERVER_KEY || ''} onChange={e => set('MIDTRANS_SERVER_KEY', e.target.value)} placeholder="Mid-server-..." disabled={env.ACTIVE_GATEWAY !== 'MIDTRANS'} />
            </Field>
            <Field label="Environment Mode" hint="Gunakan 'Sandbox' untuk percobaan, 'Production' untuk jualan asli.">
              <select 
                className="input" 
                value={env.MIDTRANS_IS_PRODUCTION || 'no'} 
                onChange={e => set('MIDTRANS_IS_PRODUCTION', e.target.value)}
                disabled={env.ACTIVE_GATEWAY !== 'MIDTRANS'}
              >
                <option value="no">Sandbox (Testing)</option>
                <option value="yes">Production (Live)</option>
              </select>
            </Field>
          </Section>

          <Section title="Pakasir QRIS Gateway" icon="💳" color="#10b981">
            <Field label="Pakasir Slug" hint="Slug unik akun Pakasir Anda (bukan username, cek di dashboard Pakasir).">
              <Input value={env.PAKASIR_SLUG || ''} onChange={e => set('PAKASIR_SLUG', e.target.value)} placeholder="paizweb" disabled={env.ACTIVE_GATEWAY !== 'PAKASIR' && env.ACTIVE_GATEWAY !== undefined} />
            </Field>
            <Field label="Pakasir API Key" hint="API Key dari dashboard Pakasir Anda. Jaga kerahasiaannya.">
              <Input type="password" value={env.PAKASIR_API_KEY || ''} onChange={e => set('PAKASIR_API_KEY', e.target.value)} placeholder="•••••••••••••••" disabled={env.ACTIVE_GATEWAY !== 'PAKASIR' && env.ACTIVE_GATEWAY !== undefined} />
            </Field>
          </Section>

          <Section title="Atlantic Payment Gateway" icon="🌊" color="#3b82f6">
            <Field label="Atlantic API Key" hint="API Key dari Atlantic Group / Atlantic Pedia.">
              <Input type="password" value={env.ATLANTIC_API_KEY || ''} onChange={e => set('ATLANTIC_API_KEY', e.target.value)} placeholder="Atlantic API Key Anda..." disabled={env.ACTIVE_GATEWAY !== 'ATLANTIC'} />
            </Field>
          </Section>

          <Section title="DOKU Payment Gateway" icon="🛡️" color="#ef4444">
            <Field label="DOKU Client ID" hint="Client ID / Merchant ID dari Dashboard DOKU (Jokul).">
              <Input value={env.DOKU_CLIENT_ID || ''} onChange={e => set('DOKU_CLIENT_ID', e.target.value)} placeholder="Misal: MCH-12345..." disabled={env.ACTIVE_GATEWAY !== 'DOKU'} />
            </Field>
            <Field label="DOKU Secret Key" hint="Secret Key dari Dashboard DOKU.">
              <Input type="password" value={env.DOKU_SECRET_KEY || ''} onChange={e => set('DOKU_SECRET_KEY', e.target.value)} placeholder="SK-..." disabled={env.ACTIVE_GATEWAY !== 'DOKU'} />
            </Field>
          </Section>

          <Section title="Tripay Payment Gateway" icon="🚀" color="#f59e0b">
            <Field label="Tripay Merchant Code" hint="Kode Merchant (T-Code) dari Dashboard Tripay.">
              <Input value={env.TRIPAY_MERCHANT_CODE || ''} onChange={e => set('TRIPAY_MERCHANT_CODE', e.target.value)} placeholder="Txxxx" disabled={env.ACTIVE_GATEWAY !== 'TRIPAY'} />
            </Field>
            <Field label="Tripay API Key" hint="API Key untuk integrasi Tripay.">
              <Input type="password" value={env.TRIPAY_API_KEY || ''} onChange={e => set('TRIPAY_API_KEY', e.target.value)} placeholder="DEV-xxxx atau prod-xxxx" disabled={env.ACTIVE_GATEWAY !== 'TRIPAY'} />
            </Field>
            <Field label="Tripay Private Key" hint="Private Key untuk validasi keamanan (Signature) Tripay.">
              <Input type="password" value={env.TRIPAY_PRIVATE_KEY || ''} onChange={e => set('TRIPAY_PRIVATE_KEY', e.target.value)} placeholder="xxxx-xxxx-xxxx" disabled={env.ACTIVE_GATEWAY !== 'TRIPAY'} />
            </Field>
          </Section>

          <Section title="Mayar Payment Gateway" icon="⚡" color="#0ea5e9">
            <Field label="Mayar API Key" hint="Secret API Key dari Dashboard Developer Mayar Anda.">
              <Input type="password" value={env.MAYAR_API_KEY || ''} onChange={e => set('MAYAR_API_KEY', e.target.value)} placeholder="sk_live_xxxx" disabled={env.ACTIVE_GATEWAY !== 'MAYAR'} />
            </Field>
          </Section>

          <Section title="Durianpay Payment Gateway" icon="🍈" color="#84cc16">
            <Field label="Durianpay API Key" hint="Secret Key dari Dashboard Durianpay Anda.">
              <Input type="password" value={env.DURIANPAY_API_KEY || ''} onChange={e => set('DURIANPAY_API_KEY', e.target.value)} placeholder="dp_test_xxxx atau dp_live_xxxx" disabled={env.ACTIVE_GATEWAY !== 'DURIANPAY'} />
            </Field>
          </Section>

          <Section title="UangX Payment Gateway" icon="💰" color="#16a34a">
            <Field label="UangX API Key" hint="API Key dari Dashboard UangX Anda.">
              <Input type="password" value={env.UANGX_API_KEY || ''} onChange={e => set('UANGX_API_KEY', e.target.value)} placeholder="API-xxxx" disabled={env.ACTIVE_GATEWAY !== 'UANGX'} />
            </Field>
            <Field label="UangX Secret Key" hint="Secret Key untuk validasi keamanan UangX.">
              <Input type="password" value={env.UANGX_SECRET_KEY || ''} onChange={e => set('UANGX_SECRET_KEY', e.target.value)} placeholder="SEC-xxxx" disabled={env.ACTIVE_GATEWAY !== 'UANGX'} />
            </Field>
          </Section>
        </div>
      )}

      {/* ─── TAB: PANEL/SERVER ─── */}
      {activeTab === 'ptero' && (
        <div>
          {[1, 2, 3].map(n => (
            <Section key={n} title={`Server ${n} (Failover Node ${n})`} icon="🦕" color={n === 1 ? '#10b981' : n === 2 ? '#3b82f6' : '#f59e0b'}>
              <Field label={`URL Panel Server ${n}`} hint={`URL lengkap panel Pterodactyl server ${n}. Contoh: https://panel.domain.com`}>
                <Input value={env[`PTERO_URL_${n}`] || ''} onChange={e => set(`PTERO_URL_${n}`, e.target.value)} placeholder={`https://panel${n}.domain.com`} />
              </Field>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <Field label="Application Key (PTLA)" hint="Pterodactyl Application API Key">
                  <Input type="password" value={env[`PTERO_PTLA_${n}`] || ''} onChange={e => set(`PTERO_PTLA_${n}`, e.target.value)} placeholder="ptla_••••••••" />
                </Field>
                <Field label="Client Key (PTLC)" hint="Pterodactyl Client API Key">
                  <Input type="password" value={env[`PTERO_PTLC_${n}`] || ''} onChange={e => set(`PTERO_PTLC_${n}`, e.target.value)} placeholder="ptlc_••••••••" />
                </Field>
              </div>
            </Section>
          ))}
        </div>
      )}

      {/* ─── TAB: ADMIN ─── */}
      {activeTab === 'admin' && (
        <div>
          <Section title="Akun Administrator" icon="🔑" color="#ef4444">
            <div style={{ padding: '0.75rem 1rem', background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: '10px', fontSize: '0.8rem', color: '#fca5a5', marginBottom: '0.5rem' }}>
              ⚠️ Setelah simpan, Anda perlu login ulang dengan kredensial baru.
            </div>
            <Field label="Username Admin">
              <Input value={env.ADMIN_USERNAME || ''} onChange={e => set('ADMIN_USERNAME', e.target.value)} placeholder="King-paiz" />
            </Field>
            <Field label="Email Admin">
              <Input type="email" value={env.ADMIN_EMAIL || ''} onChange={e => set('ADMIN_EMAIL', e.target.value)} placeholder="admin@email.com" />
            </Field>
            <Field label="Password Admin" hint="Minimal 6 karakter. Gunakan kombinasi huruf & angka.">
              <Input type="password" value={env.ADMIN_PASSWORD || ''} onChange={e => set('ADMIN_PASSWORD', e.target.value)} placeholder="•••••••••" />
            </Field>
          </Section>
        </div>
      )}

      {/* Sticky Save Bar */}
      <div style={{
        position: 'sticky', bottom: '1.5rem',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        gap: '1rem',
        padding: '1rem 1.5rem',
        background: 'rgba(15,15,25,0.95)',
        border: '1px solid rgba(139,92,246,0.3)',
        borderRadius: '14px',
        backdropFilter: 'blur(12px)',
        zIndex: 100,
        marginTop: '2rem'
      }}>
        <div>
          {msg && (
            <span style={{ fontSize: '0.85rem', color: msg.ok ? '#10b981' : '#ef4444', fontWeight: 600 }}>
              {msg.ok ? '✅ ' : '❌ '}{msg.text}
            </span>
          )}
          {!msg && <span style={{ fontSize: '0.8rem', color: '#52525b' }}>Semua perubahan tersimpan ke file .env lokal</span>}
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          style={{
            padding: '0.65rem 2rem',
            borderRadius: '10px',
            border: 'none',
            cursor: saving ? 'not-allowed' : 'pointer',
            fontFamily: 'inherit',
            fontWeight: 700,
            fontSize: '0.9rem',
            background: saving ? '#374151' : 'linear-gradient(135deg, #8b5cf6, #ec4899)',
            color: 'white',
            transition: 'all 0.2s',
            whiteSpace: 'nowrap'
          }}
        >
          {saving ? '⏳ Menyimpan...' : '💾 Simpan Semua'}
        </button>
      </div>
    </main>
  )
}
