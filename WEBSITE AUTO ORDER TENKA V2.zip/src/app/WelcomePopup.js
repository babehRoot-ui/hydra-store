'use client'
import { useState, useEffect, useRef } from 'react'
import { createPortal } from 'react-dom'

export default function WelcomePopup({ type = 'text', title, text, image, video, docLink, musicUrl }) {
  const [isOpen, setIsOpen] = useState(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const hasSeen = sessionStorage.getItem('hasSeenWelcomePopup')
    const hasContent = title || text || image || video
    if (!hasSeen && hasContent) {
      setIsOpen(true)
    }
  }, [title, text, image, video])

  const closePopup = () => {
    setIsOpen(false)
    sessionStorage.setItem('hasSeenWelcomePopup', 'true')
  }

  if (!mounted) return null

  if (!isOpen) return null

  // Deteksi apakah video YouTube
  const isYoutube = video && (video.includes('youtube.com') || video.includes('youtu.be'))
  const getYoutubeEmbed = (url) => {
    if (!url) return ''
    const match = url.match(/(?:v=|embed\/|youtu\.be\/)([A-Za-z0-9_-]{11})/)
    return match ? `https://www.youtube.com/embed/${match[1]}?autoplay=0` : url
  }

  const content = (
    <>
      {/* Backdrop */}
      <div
        onClick={closePopup}
        style={{
          position: 'fixed', inset: 0, zIndex: 9998,
          background: 'rgba(0,0,0,0.88)',
          backdropFilter: 'blur(10px)',
          animation: 'wp-fade 0.35s ease-out'
        }}
      />

      {/* Modal */}
      <div style={{
        position: 'fixed', inset: 0, zIndex: 9999,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '1.5rem', pointerEvents: 'none'
      }}>
        <div
          onClick={e => e.stopPropagation()}
          style={{
            pointerEvents: 'auto',
            maxWidth: type === 'video' ? '700px' : '560px',
            width: '100%',
            background: 'linear-gradient(145deg, rgba(15,15,25,0.97), rgba(20,10,35,0.98))',
            border: '1px solid rgba(139,92,246,0.45)',
            borderRadius: '20px',
            overflow: 'hidden',
            boxShadow: '0 0 60px rgba(139,92,246,0.25), 0 0 120px rgba(236,72,153,0.1)',
            animation: 'wp-slide 0.4s cubic-bezier(0.34,1.56,0.64,1)',
            position: 'relative'
          }}
        >
          {/* Close button */}
          <button onClick={closePopup} style={{
            position: 'absolute', top: '14px', right: '14px', zIndex: 10,
            background: 'rgba(0,0,0,0.6)', color: 'white', border: '1px solid rgba(255,255,255,0.1)',
            width: '32px', height: '32px', borderRadius: '50%', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.85rem',
            backdropFilter: 'blur(6px)'
          }}>✕</button>

          {/* ── TIPE: IMAGE ── */}
          {type === 'image' && image && (
            <div style={{ width: '100%', maxHeight: '320px', overflow: 'hidden' }}>
              <img src={image} alt="Welcome" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            </div>
          )}

          {/* ── TIPE: VIDEO ── */}
          {type === 'video' && video && (
            <div style={{ position: 'relative', paddingBottom: '56.25%', height: 0, background: '#000' }}>
              {isYoutube ? (
                <iframe
                  src={getYoutubeEmbed(video)}
                  style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', border: 'none' }}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <video
                  src={video}
                  controls
                  style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }}
                />
              )}
            </div>
          )}

          {/* Konten Teks */}
          <div style={{ padding: '2rem', textAlign: 'center' }}>
            {title && (
              <h2 style={{
                fontSize: 'clamp(1.4rem, 4vw, 2rem)', fontWeight: 900, marginBottom: '1rem',
                background: 'linear-gradient(to right, #60a5fa, #c084fc, #f472b6)',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
                lineHeight: 1.2
              }}>{title}</h2>
            )}
            {text && (
              <p style={{
                color: '#a1a1aa', fontSize: '0.95rem', lineHeight: 1.75,
                marginBottom: '1.75rem', whiteSpace: 'pre-wrap'
              }}>{text}</p>
            )}

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {docLink && (
                <a
                  href={docLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
                    padding: '0.8rem 1.5rem', borderRadius: '12px',
                    background: 'rgba(139,92,246,0.15)',
                    border: '1px solid rgba(139,92,246,0.35)',
                    color: '#c084fc', fontWeight: 600, fontSize: '0.9rem', textDecoration: 'none',
                    transition: 'all 0.2s'
                  }}
                >
                  🔗 Buka Link
                </a>
              )}
              <button
                onClick={closePopup}
                style={{
                  padding: '0.85rem 1.5rem', borderRadius: '12px', border: 'none',
                  background: 'linear-gradient(135deg, #8b5cf6, #ec4899)',
                  color: 'white', fontWeight: 700, fontSize: '0.95rem',
                  cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.2s',
                  boxShadow: '0 4px 20px rgba(139,92,246,0.35)'
                }}
              >
                🚀 Masuk ke Toko
              </button>
            </div>
          </div>

          {/* Glow decorations */}
          <div style={{ position: 'absolute', bottom: '-40px', left: '-40px', width: '150px', height: '150px', background: 'radial-gradient(circle, rgba(139,92,246,0.15), transparent)', borderRadius: '50%', pointerEvents: 'none' }} />
          <div style={{ position: 'absolute', top: '-40px', right: '-40px', width: '150px', height: '150px', background: 'radial-gradient(circle, rgba(236,72,153,0.12), transparent)', borderRadius: '50%', pointerEvents: 'none' }} />
        </div>
      </div>

      {/* Music floating btn removed */}

      <style>{`
        @keyframes wp-fade { from { opacity: 0; } to { opacity: 1; } }
        @keyframes wp-slide { from { opacity: 0; transform: translateY(30px) scale(0.95); } to { opacity: 1; transform: translateY(0) scale(1); } }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </>
  )

  return createPortal(content, document.body)
}
