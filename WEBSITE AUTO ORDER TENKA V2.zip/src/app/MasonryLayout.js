'use client'
import Link from 'next/link'

function BadgePill({ badge }) {
  const colors = { HOT: '#ef4444', NEW: '#10b981', SALE: '#f59e0b', LIMITED: '#8b5cf6' }
  return (
    <span className={badge === 'HOT' ? 'badge-hot' : ''} style={{
      background: colors[badge] || '#8b5cf6', color: 'white',
      fontSize: '0.7rem', fontWeight: 700, padding: '0.2rem 0.65rem', borderRadius: '9999px'
    }}>{badge}</span>
  )
}

// Heights vary to create masonry effect
const HEIGHTS = [220, 160, 280, 200, 170, 250, 190, 240]

export default function MasonryLayout({ products, gradient, onBuy }) {
  const features = (p) => { try { return JSON.parse(p.features || '[]') } catch { return [] } }

  return (
    <div style={{
      columns: '3', columnGap: '1.5rem',
      '@media(max-width:900px)': { columns: '2' }
    }}>
      {products.map((p, idx) => {
        const h = HEIGHTS[idx % HEIGHTS.length]
        const feats = features(p)
        return (
          <div key={p.id} className="glass-card" style={{
            breakInside: 'avoid', marginBottom: '1.5rem', display: 'flex',
            flexDirection: 'column', gap: '0.75rem', cursor: 'default',
            animation: `fadeIn 0.5s ease both`, animationDelay: `${idx * 0.06}s`
          }}>
            {/* Image area */}
            <div style={{
              width: '100%', height: `${h}px`, borderRadius: '0.75rem', overflow: 'hidden',
              background: 'linear-gradient(135deg, rgba(139,92,246,0.15), rgba(236,72,153,0.15))',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0
            }}>
              {p.imageUrl
                ? <img src={p.imageUrl} alt={p.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                : <span style={{ fontSize: `${2 + (idx % 3)}rem` }}>📊</span>}
            </div>

            {/* Badge row */}
            <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
              {p.badge && <BadgePill badge={p.badge} />}
              {p.featured && <span style={{ background: 'rgba(245,158,11,0.15)', color: '#fbbf24', fontSize: '0.7rem', fontWeight: 600, padding: '0.2rem 0.6rem', borderRadius: '9999px', border: '1px solid rgba(245,158,11,0.3)' }}>⭐ Unggulan</span>}
            </div>

            {/* Category */}
            <span style={{ fontSize: '0.75rem', color: '#8b5cf6', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{p.subcategory || p.category}</span>

            {/* Title */}
            <h3 style={{ fontSize: '1rem', fontWeight: 700, lineHeight: 1.3 }}>{p.name}</h3>

            {/* Description (only for taller cards) */}
            {h >= 200 && p.description && (
              <p style={{ fontSize: '0.85rem', color: '#a1a1aa', lineHeight: 1.5, display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                {p.description}
              </p>
            )}

            {/* Features (only for tallest) */}
            {h >= 250 && feats.length > 0 && (
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.3rem' }}>
                {feats.slice(0, 3).map((f, i) => (
                  <li key={i} style={{ display: 'flex', gap: '0.4rem', fontSize: '0.8rem', color: '#cbd5e1' }}>
                    <span style={{ color: '#10b981' }}>✓</span>{f}
                  </li>
                ))}
              </ul>
            )}

            {/* Price + Buy */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'auto', paddingTop: '0.5rem', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
              <p style={{ fontSize: '1.1rem', fontWeight: 800, background: gradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
                Rp {p.price.toLocaleString('id-ID')}
              </p>
              <button onClick={() => onBuy(p)} className="btn btn-primary" style={{ fontSize: '0.8rem', padding: '0.5rem 1rem' }}>
                Beli
              </button>
            </div>
          </div>
        )
      })}
    </div>
  )
}
