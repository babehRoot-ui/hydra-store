import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { processProductDelivery } from '@/lib/ptero'

export const dynamic = 'force-dynamic'

// Webhook untuk Atlantic Payment Gateway
export async function POST(request) {
  try {
    const formData = await request.formData()
    
    // Sesuaikan parameter berdasarkan dokumentasi spesifik penyedia Atlantic Anda
    const status = formData.get('status') 
    const reff = formData.get('reff') // Ini adalah ID Transaksi di sistem kita (order.id) yang dikirim saat request deposit

    if (!reff) {
      return NextResponse.json({ success: false, message: 'Invalid payload' }, { status: 400 })
    }

    // Jika status Success
    if (status === 'success' || status === 'Success' || status === 'SUCCESS') {
      const order = await prisma.order.findUnique({
        where: { id: reff },
        include: { product: true }
      })

      if (!order) {
        return NextResponse.json({ success: false, message: 'Order tidak ditemukan' }, { status: 404 })
      }

      if (order.status === 'SUCCESS') {
        return NextResponse.json({ success: true, message: 'Order sudah diproses sebelumnya' })
      }

      // Update status menjadi sukses
      await prisma.order.update({
        where: { id: order.id },
        data: { status: 'SUCCESS', paidAt: new Date() }
      })

      // Proses otomatisasi pengiriman (Pterodactyl / File / Link)
      await processProductDelivery(order)

      return NextResponse.json({ success: true, message: 'Webhook processed' })
    }

    return NextResponse.json({ success: true, message: 'Status diabaikan' })

  } catch (error) {
    console.error('Atlantic Webhook Error:', error)
    return NextResponse.json({ success: false, message: 'Internal error' }, { status: 500 })
  }
}
