import { PrismaClient } from '@prisma/client'
import { NextResponse } from 'next/server'

const prisma = new PrismaClient()

// GET /api/links - Public: Fetch active links
export async function GET() {
  try {
    const links = await prisma.link.findMany({
      where: { active: true },
      orderBy: { order: 'asc' }
    })
    return NextResponse.json({ success: true, data: links })
  } catch (err) {
    return NextResponse.json({ success: false, message: err.message }, { status: 500 })
  }
}

// POST /api/links - Admin: Create new link
export async function POST(req) {
  try {
    const body = await req.json()
    const { title, url, icon, order } = body

    if (!title || !url) {
      return NextResponse.json({ success: false, message: 'Title and URL are required' }, { status: 400 })
    }

    const newLink = await prisma.link.create({
      data: {
        title,
        url,
        icon: icon || '🔗',
        order: parseInt(order) || 0
      }
    })

    return NextResponse.json({ success: true, data: newLink })
  } catch (err) {
    return NextResponse.json({ success: false, message: err.message }, { status: 500 })
  }
}
