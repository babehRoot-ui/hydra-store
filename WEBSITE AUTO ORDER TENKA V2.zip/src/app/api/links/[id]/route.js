import { PrismaClient } from '@prisma/client'
import { NextResponse } from 'next/server'

const prisma = new PrismaClient()

export async function PUT(req, { params }) {
  try {
    const { id } = await params
    const body = await req.json()
    const { title, url, icon, order, active } = body

    const updatedLink = await prisma.link.update({
      where: { id },
      data: {
        title,
        url,
        icon,
        order: parseInt(order),
        active: active ?? true
      }
    })

    return NextResponse.json({ success: true, data: updatedLink })
  } catch (err) {
    return NextResponse.json({ success: false, message: err.message }, { status: 500 })
  }
}

export async function DELETE(req, { params }) {
  try {
    const { id } = await params
    await prisma.link.delete({ where: { id } })
    return NextResponse.json({ success: true, message: 'Link deleted' })
  } catch (err) {
    return NextResponse.json({ success: false, message: err.message }, { status: 500 })
  }
}
