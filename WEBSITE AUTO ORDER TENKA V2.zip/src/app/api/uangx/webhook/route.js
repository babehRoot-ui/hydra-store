import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { processProductDelivery } from '@/lib/ptero'

export const dynamic = 'force-dynamic'

// Webhook untuk UangX Payment Gateway
export async function POST(request) {
  try {
    const body = await request.json()
    
    // UangX Webhook Payload
    const orderId = body.order_id;
    const status = body.status;

    if (!orderId) {
      return NextResponse.json({ success: false, message: 'Invalid payload' }, { status: 400 })
    }

    // Jika status SUCCESS / PAID
    if (status === 'SUCCESS' || status === 'PAID') {
      const order = await prisma.order.findUnique({
        where: { id: orderId },
        include: { product: true }
      })

      if (!order) {
        return NextResponse.json({ success: false, message: 'Order tidak ditemukan' }, { status: 404 })
      }

      if (order.status === 'SUCCESS') {
        return NextResponse.json({ success: true, message: 'Order sudah diproses sebelumnya' })
      }

      // Update status menjadi sukses
      await prisma.order.update({
        where: { id: order.id },
        data: { status: 'SUCCESS', paidAt: new Date() }
      })

      // Proses otomatisasi pengiriman (Pterodactyl / File / Link)
      await processProductDelivery(order)

      return NextResponse.json({ success: true, message: 'Webhook processed' })
    }

    return NextResponse.json({ success: true, message: 'Status diabaikan' })

  } catch (error) {
    console.error('UangX Webhook Error:', error)
    return NextResponse.json({ success: false, message: 'Internal error' }, { status: 500 })
  }
}
