import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { createPteroServer } from '@/lib/ptero';

export const dynamic = 'force-dynamic';

export async function POST(req) {
  try {
    // 0. VERIFIKASI KEAMANAN (SANGAT PENTING UNTUK MENCEGAH BYPASS)
    // Untuk mencegah orang iseng menembak webhook dan membuat order SUCCESS secara gratis
    const { getSettings } = await import('@/lib/settings')
    const settings = await getSettings(['WEBHOOK_SECRET', 'PAKASIR_API_KEY'])
    
    const { searchParams } = new URL(req.url)
    const token = searchParams.get('token') || req.headers.get('x-webhook-token')
    const expectedToken = settings.WEBHOOK_SECRET || process.env.WEBHOOK_SECRET || settings.PAKASIR_API_KEY || process.env.PAKASIR_API_KEY
    
    if (!token || token !== expectedToken) {
      return NextResponse.json({ error: 'Unauthorized Webhook' }, { status: 401 })
    }

    const body = await req.json();
    const order_id = body.order_id || body.reference;
    const status = body.status || body.transaction_status;

    if (!order_id) {
      return NextResponse.json({ error: 'Missing order_id' }, { status: 400 });
    }

    const isSuccess = ['success', 'settlement', 'paid'].includes(status?.toLowerCase());
    const isFailed = ['failed', 'expired', 'cancel', 'deny'].includes(status?.toLowerCase());

    let newStatus = 'PENDING';
    if (isSuccess) newStatus = 'SUCCESS';
    if (isFailed) newStatus = 'FAILED';

    // 1. Update status
    const order = await prisma.order.update({
      where: { id: order_id },
      data: { status: newStatus },
      include: { product: true }
    });

    if (!order) return NextResponse.json({ error: 'Order not found' }, { status: 404 });

    // 2. Jika sukses, proses pengiriman
    if (newStatus === 'SUCCESS') {
      const { processOrderSuccess } = await import('@/lib/orderProcessor');
      await processOrderSuccess(order_id);
    }

    return NextResponse.json({ success: true, message: 'Webhook processed successfully' });
  } catch (error) {
    console.error('Webhook processing error:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
