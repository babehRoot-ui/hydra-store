import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { verify } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

// Kunci yang boleh diubah via dashboard
const ALLOWED_KEYS = [
  'ADMIN_USERNAME', 'ADMIN_EMAIL', 'ADMIN_PASSWORD',
  'PAKASIR_SLUG', 'PAKASIR_API_KEY',
  'PTERO_URL_1', 'PTERO_PTLA_1', 'PTERO_PTLC_1',
  'PTERO_URL_2', 'PTERO_PTLA_2', 'PTERO_PTLC_2',
  'PTERO_URL_3', 'PTERO_PTLA_3', 'PTERO_PTLC_3',
  'WELCOME_TITLE', 'WELCOME_TEXT', 'WELCOME_IMAGE',
  'WELCOME_VIDEO', 'WELCOME_DOC_LINK', 'WELCOME_MUSIC_URL',
  'WELCOME_TYPE', 'STORE_NAME', 'STORE_TAGLINE',
  'GLOBAL_BG_URL', 'GLOBAL_BG_TYPE', 'CONTACT_ADMIN_TEXT', 'CONTACT_ADMIN_LINK',
  'LINKBIO_SHOW', 'LINKBIO_NAME', 'PRODUCT_SORT',
  'MIDTRANS_SERVER_KEY', 'MIDTRANS_CLIENT_KEY', 'MIDTRANS_IS_PRODUCTION',
  'XENDIT_SECRET_KEY', 'XENDIT_CALLBACK_TOKEN',
  'FASPAY_MERCHANT_ID', 'FASPAY_MERCHANT_NAME', 'FASPAY_USER_ID', 'FASPAY_PASSWORD', 'FASPAY_IS_PRODUCTION',
  'IPAYMU_VA', 'IPAYMU_API_KEY', 'IPAYMU_IS_PRODUCTION',
  'FINPAY_MERCHANT_ID', 'FINPAY_MERCHANT_KEY', 'FINPAY_IS_PRODUCTION',
  'ESPAY_API_KEY', 'ESPAY_SIGNATURE_KEY', 'ESPAY_IS_PRODUCTION',
  'DUITKU_MERCHANT_CODE', 'DUITKU_API_KEY', 'DUITKU_IS_PRODUCTION',
  'OY_USER_ID', 'OY_API_KEY', 'OY_IS_PRODUCTION'
]

async function getAuth() {
  const cookieStore = await cookies()
  const session = cookieStore.get('admin_session')?.value
  if (!session || !(await verify(session))) return false
  return true
}

// GET - baca nilai dari database (fallback ke .env)
export async function GET() {
  try {
    if (!(await getAuth())) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }

    // Ambil semua settings dari DB
    const dbSettings = await prisma.setting.findMany()
    const settingsMap = {}
    dbSettings.forEach(s => {
      settingsMap[s.key] = s.value
    })

    const safe = {}
    for (const key of ALLOWED_KEYS) {
      // Prioritas: DB -> .env -> empty string
      safe[key] = settingsMap[key] || process.env[key] || ''
    }

    return NextResponse.json({ success: true, env: safe })
  } catch (err) {
    return NextResponse.json({ success: false, message: err.message }, { status: 500 })
  }
}

// POST - update nilai di database
export async function POST(req) {
  try {
    if (!(await getAuth())) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }
    const body = await req.json()
    
    // Gunakan transaction untuk update/upsert multiple keys
    const operations = Object.entries(body)
      .filter(([k]) => ALLOWED_KEYS.includes(k))
      .map(([k, v]) => {
        return prisma.setting.upsert({
          where: { key: k },
          update: { value: String(v) },
          create: { key: k, value: String(v) }
        })
      })

    if (operations.length > 0) {
      await prisma.$transaction(operations)
    }

    // Revalidate paths jika diperlukan
    const { revalidatePath } = await import('next/cache')
    revalidatePath('/')
    revalidatePath('/admin/settings')

    return NextResponse.json({ success: true, message: 'Konfigurasi berhasil disimpan di Database!' })
  } catch (err) {
    console.error('Settings API Error:', err)
    return NextResponse.json({ success: false, message: err.message }, { status: 500 })
  }
}
