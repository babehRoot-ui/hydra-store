import { PrismaClient } from '@prisma/client'
import { NextResponse } from 'next/server'

const prisma = new PrismaClient()

export async function POST() {
  try {
    // Jalankan SQL mentah untuk membuat tabel Link jika belum ada
    // Ini adalah solusi jika npx prisma db push tidak bisa dijalankan
    await prisma.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS "Link" (
          "id" TEXT NOT NULL,
          "title" TEXT NOT NULL,
          "url" TEXT NOT NULL,
          "icon" TEXT,
          "active" BOOLEAN NOT NULL DEFAULT true,
          "order" INTEGER NOT NULL DEFAULT 0,
          "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

          CONSTRAINT "Link_pkey" PRIMARY KEY ("id")
      );
    `)

    return NextResponse.json({ success: true, message: 'Database synced successfully (Table Link created)' })
  } catch (err) {
    console.error('DB Sync Error:', err)
    return NextResponse.json({ success: false, message: err.message }, { status: 500 })
  } finally {
    await prisma.$disconnect()
  }
}
