import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { verify } from '@/lib/auth'
import { cookies } from 'next/headers'

export const DEFAULT_CATEGORIES = [
  {
    slug: 'script', label: 'Script & Bot MD', icon: '🤖',
    heroDesc: 'Script WhatsApp Bot terlengkap & Script CPanel. No encrypt, ready pakai!',
    accentFrom: '#3b82f6', accentTo: '#8b5cf6', layout: 'grid-card',
    bgVariant: 0, robotPose: 'wave', robotSide: 'right', tags: ['script', 'bot', 'baileys', 'md', 'wa', 'cpanel', 'hosting']
  },
  {
    slug: 'panel', label: 'Open Tier Panel', icon: '📊',
    heroDesc: 'Panel manajemen reseller bot WhatsApp. Kelola member, sewa, dan monitor dengan mudah.',
    accentFrom: '#8b5cf6', accentTo: '#ec4899', layout: 'masonry',
    bgVariant: 2, robotPose: 'sit-moon', robotSide: 'right', tags: ['panel', 'reseller', 'manajemen', 'tier']
  },
  {
    slug: 'ptero', label: 'Panel / Server', icon: '🦕',
    heroDesc: 'Theme, egg, dan addon untuk Panel / Server. Tampilkan server Anda dengan elegan.',
    accentFrom: '#f59e0b', accentTo: '#ef4444', layout: 'showcase',
    bgVariant: 3, robotPose: 'fly', robotSide: 'left', tags: ['pterodactyl', 'ptero', 'game', 'server']
  },
  {
    slug: 'sewa', label: 'Sewa Bot WA', icon: '🤖',
    heroDesc: 'Layanan sewa bot WhatsApp Tenka-MD. Aktif 24 jam dengan fitur lengkap.',
    accentFrom: '#ec4899', accentTo: '#f43f5e', layout: 'grid-card',
    bgVariant: 2, robotPose: 'wave', robotSide: 'right', tags: ['sewa', 'bot', 'wa']
  }
];

export async function GET() {
  try {
    const setting = await prisma.setting.findUnique({
      where: { key: 'CATEGORIES' }
    });
    
    let categories = DEFAULT_CATEGORIES;
    if (setting && setting.value) {
      try {
        categories = JSON.parse(setting.value);
      } catch (e) {
        console.error("Failed to parse CATEGORIES from DB", e);
      }
    }
    
    return NextResponse.json({ success: true, data: categories });
  } catch (error) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

export async function POST(req) {
  try {
    const cookieStore = await cookies();
    const session = cookieStore.get('admin_session')?.value;
    if (!session || !(await verify(session))) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 });
    }

    const categories = await req.json();
    
    await prisma.setting.upsert({
      where: { key: 'CATEGORIES' },
      update: { value: JSON.stringify(categories) },
      create: { key: 'CATEGORIES', value: JSON.stringify(categories) }
    });

    return NextResponse.json({ success: true, message: 'Kategori berhasil disimpan!' });
  } catch (error) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}
