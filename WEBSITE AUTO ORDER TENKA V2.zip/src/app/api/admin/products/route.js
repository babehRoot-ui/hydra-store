import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { verify } from '@/lib/auth'

async function getAuth() {
  const cookieStore = await cookies()
  const session = cookieStore.get('admin_session')?.value
  if (!session || !(await verify(session))) return false
  return true
}

function parseFormData(formData) {
  const featuresRaw = formData.get('features') || ''
  return {
    name: formData.get('name'),
    description: formData.get('description') || null,
    price: parseInt(formData.get('price')),
    category: formData.get('category'),
    subcategory: formData.get('subcategory') || null,
    imageUrl: formData.get('imageUrl') || null,
    badge: formData.get('badge') || null,
    deliveryType: formData.get('deliveryType') || 'LINK',
    deliveryContent: formData.get('deliveryContent') || null,
    deliveryLink2: formData.get('deliveryLink2') || null,
    deliveryLink2Desc: formData.get('deliveryLink2Desc') || null,
    featured: formData.get('featured') === 'on',
    features: featuresRaw.trim()
      ? JSON.stringify(featuresRaw.split('\n').map(f => f.trim()).filter(Boolean))
      : null,
  }
}

export async function POST(req) {
  try {
    if (!(await getAuth())) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }
    const formData = await req.formData()
    const data = parseFormData(formData)
    const product = await prisma.product.create({ data })
    const { revalidatePath } = await import('next/cache')
    revalidatePath('/')
    revalidatePath(`/kategori/${data.category}`)
    return NextResponse.json({ success: true, product })
  } catch (error) {
    console.error('API POST Error:', error)
    return NextResponse.json({ success: false, message: error.message }, { status: 500 })
  }
}

export async function PUT(req) {
  try {
    if (!(await getAuth())) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }
    const formData = await req.formData()
    const id = formData.get('id')
    if (!id) return NextResponse.json({ success: false, message: 'ID wajib diisi' }, { status: 400 })
    const data = parseFormData(formData)
    const product = await prisma.product.update({ where: { id }, data })
    const { revalidatePath } = await import('next/cache')
    revalidatePath('/')
    revalidatePath(`/kategori/${data.category}`)
    revalidatePath('/admin/products')
    return NextResponse.json({ success: true, product })
  } catch (error) {
    console.error('API PUT Error:', error)
    return NextResponse.json({ success: false, message: error.message }, { status: 500 })
  }
}

export async function DELETE(req) {
  try {
    if (!(await getAuth())) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }
    const { id } = await req.json()
    if (!id) return NextResponse.json({ success: false, message: 'ID wajib diisi' }, { status: 400 })
    await prisma.product.delete({ where: { id } })
    const { revalidatePath } = await import('next/cache')
    revalidatePath('/')
    revalidatePath('/admin/products')
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('API DELETE Error:', error)
    return NextResponse.json({ success: false, message: error.message }, { status: 500 })
  }
}
