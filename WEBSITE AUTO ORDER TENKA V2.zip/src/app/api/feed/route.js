import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const orders = await prisma.order.findMany({
      where: { status: 'SUCCESS' },
      include: { product: true },
      take: 10,
      orderBy: { createdAt: 'desc' }
    })
    
    // Transform to unified feed format
    const feed = orders.map(o => ({
      id: o.id,
      label: o.product.name,
      amount: o.amount,
      ts: o.createdAt.getTime(),
      username: o.customerName.substring(0, 4) + '***',
      user: o.customerPhone.substring(0, 5) + '***',
      action: 'Membeli',
      product: o.product.name,
      time: 'Baru saja'
    }))

    return NextResponse.json(feed)
  } catch (error) {
    return NextResponse.json([])
  }
}
