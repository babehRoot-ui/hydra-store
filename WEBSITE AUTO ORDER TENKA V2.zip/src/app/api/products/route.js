import { prisma } from '@/lib/prisma'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    // 1. Ambil setting urutan dari DB
    const sortSetting = await prisma.setting.findUnique({
      where: { key: 'PRODUCT_SORT' }
    })
    const sortType = sortSetting?.value || 'cheapest'

    // 2. Tentukan orderBy
    let orderBy = { price: 'asc' } // Default: cheapest
    if (sortType === 'expensive') orderBy = { price: 'desc' }
    if (sortType === 'latest') orderBy = { createdAt: 'desc' }

    // 3. Ambil produk
    let products = await prisma.product.findMany({
      orderBy: sortType === 'random' ? undefined : orderBy,
    })

    // 4. Jika random, acak di level JS
    if (sortType === 'random') {
      products = products.sort(() => Math.random() - 0.5)
    }

    return NextResponse.json(products)
  } catch (error) {
    console.error('API Products Error:', error)
    return NextResponse.json({ error: 'Failed to fetch products', details: error.message, stack: error.stack }, { status: 500 })
  }
}
