import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { processProductDelivery } from '@/lib/ptero'

export const dynamic = 'force-dynamic'

// Webhook untuk DOKU Payment Gateway
export async function POST(request) {
  try {
    const body = await request.json()
    
    // Sesuaikan parameter berdasarkan dokumentasi spesifik Jokul / DOKU
    const orderId = body.order?.invoice_number;
    const status = body.transaction?.status;

    if (!orderId) {
      return NextResponse.json({ success: false, message: 'Invalid payload' }, { status: 400 })
    }

    // Jika status SUCCESS / SETTLED
    if (status === 'SUCCESS' || status === 'SETTLED') {
      const order = await prisma.order.findUnique({
        where: { id: orderId },
        include: { product: true }
      })

      if (!order) {
        return NextResponse.json({ success: false, message: 'Order tidak ditemukan' }, { status: 404 })
      }

      if (order.status === 'SUCCESS') {
        return NextResponse.json({ success: true, message: 'Order sudah diproses sebelumnya' })
      }

      // Update status menjadi sukses
      await prisma.order.update({
        where: { id: order.id },
        data: { status: 'SUCCESS', paidAt: new Date() }
      })

      // Proses otomatisasi pengiriman (Pterodactyl / File / Link)
      await processProductDelivery(order)

      return NextResponse.json({ success: true, message: 'Webhook processed' })
    }

    return NextResponse.json({ success: true, message: 'Status diabaikan' })

  } catch (error) {
    console.error('DOKU Webhook Error:', error)
    return NextResponse.json({ success: false, message: 'Internal error' }, { status: 500 })
  }
}
