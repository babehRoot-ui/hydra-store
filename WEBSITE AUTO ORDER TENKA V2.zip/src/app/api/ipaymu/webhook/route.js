import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function POST(request) {
  try {
    // iPaymu bisa mengirim data via Form-Data (POST) atau JSON
    // Kita coba handle keduanya
    let body = {}
    const contentType = request.headers.get('content-type') || ''
    
    if (contentType.includes('application/json')) {
      body = await request.json()
    } else {
      const formData = await request.formData()
      formData.forEach((value, key) => {
        body[key] = value
      })
    }

    console.log('iPaymu Webhook Received:', body)

    // iPaymu parameter standar
    const { 
      status, 
      reference_id, 
      trx_id, 
      sid // Session ID
    } = body

    // Cek Status Pembayaran
    // 'berhasil' adalah status sukses iPaymu
    if (status === 'berhasil') {
      const order = await prisma.order.findUnique({
        where: { id: reference_id }
      })

      if (order && order.status === 'PENDING') {
        // Update Order ke SUCCESS
        await prisma.order.update({
          where: { id: reference_id },
          data: { status: 'SUCCESS' }
        })

        console.log(`Order ${reference_id} marked as SUCCESS via iPaymu Webhook (Trx: ${trx_id})`)
      }
    }

    return NextResponse.json({ message: 'OK' })
  } catch (error) {
    console.error('iPaymu Webhook Error:', error)
    return NextResponse.json({ message: 'Error', error: error.message }, { status: 500 })
  }
}
