import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import crypto from 'crypto'

export async function POST(request) {
  try {
    const body = await request.json()
    console.log('Espay Webhook Received:', body)

    const { 
      order_id, 
      payment_status, 
      amount, 
      signature,
      trx_id
    } = body

    // 1. Verifikasi Signature (Security)
    const { getSettings } = await import('@/lib/settings')
    const settings = await getSettings(['ESPAY_API_KEY', 'ESPAY_SIGNATURE_KEY'])
    const apiKey = settings.ESPAY_API_KEY || process.env.ESPAY_API_KEY
    const signatureKey = settings.ESPAY_SIGNATURE_KEY || process.env.ESPAY_SIGNATURE_KEY

    // Signature Espay: SHA256(API_KEY + ORDER_ID + AMOUNT + SIGNATURE_KEY)
    const expectedSignature = crypto
      .createHash('sha256')
      .update(apiKey + order_id + amount + signatureKey)
      .digest('hex')

    if (signature !== expectedSignature) {
      console.error('Invalid Espay Signature!')
      return NextResponse.json({ message: 'Invalid Signature' }, { status: 403 })
    }

    // 2. Cek Status Pembayaran
    // Espay status 'paid' atau 'success'
    if (payment_status === 'paid' || payment_status === 'success') {
      const order = await prisma.order.findUnique({
        where: { id: order_id }
      })

      if (order && order.status === 'PENDING') {
        // Update Order ke SUCCESS
        await prisma.order.update({
          where: { id: order_id },
          data: { status: 'SUCCESS' }
        })

        console.log(`Order ${order_id} marked as SUCCESS via Espay Webhook (Trx: ${trx_id})`)
      }
    }

    return NextResponse.json({ message: 'OK', res_code: '0000', res_desc: 'Success' })
  } catch (error) {
    console.error('Espay Webhook Error:', error)
    return NextResponse.json({ message: 'Error', error: error.message }, { status: 500 })
  }
}
