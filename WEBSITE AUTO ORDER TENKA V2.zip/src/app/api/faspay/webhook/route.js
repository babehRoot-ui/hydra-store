import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import crypto from 'crypto'

export async function POST(request) {
  try {
    const body = await request.json()
    console.log('Faspay Webhook Received:', body)

    // Parameter standar Faspay
    const { 
      bill_no, 
      payment_status_code, 
      signature,
      payment_date
    } = body

    // 1. Verifikasi Signature (Security)
    const { getSettings } = await import('@/lib/settings')
    const settings = await getSettings(['FASPAY_USER_ID', 'FASPAY_PASSWORD'])
    const userId = settings.FASPAY_USER_ID || process.env.FASPAY_USER_ID
    const password = settings.FASPAY_PASSWORD || process.env.FASPAY_PASSWORD

    // Signature Faspay: MD5(USER_ID + PASSWORD + BILL_NO)
    const expectedSignature = crypto
      .createHash('md5')
      .update(userId + password + bill_no)
      .digest('hex')

    if (signature !== expectedSignature) {
      console.error('Invalid Faspay Signature!')
      return NextResponse.json({ 
        response: "Payment Notification",
        trx_id: body.trx_id,
        merchant_id: body.merchant_id,
        bill_no: bill_no,
        response_code: "403",
        response_desc: "Invalid Signature"
      })
    }

    // 2. Cek Status Pembayaran
    // Faspay status '2' berarti PAID / SUCCESS
    if (payment_status_code === '2') {
      const order = await prisma.order.findUnique({
        where: { id: bill_no }
      })

      if (order && order.status === 'PENDING') {
        // Update Order ke SUCCESS
        await prisma.order.update({
          where: { id: bill_no },
          data: { status: 'SUCCESS' }
        })

        console.log(`Order ${bill_no} marked as SUCCESS via Faspay Webhook`)
      }
    }

    // Faspay memerlukan format response khusus (biasanya JSON atau XML sesuai setup)
    return NextResponse.json({ 
      response: "Payment Notification",
      trx_id: body.trx_id,
      merchant_id: body.merchant_id,
      bill_no: bill_no,
      response_code: "00",
      response_desc: "Success"
    })
    
  } catch (error) {
    console.error('Faspay Webhook Error:', error)
    return NextResponse.json({ message: 'Error', error: error.message }, { status: 500 })
  }
}
