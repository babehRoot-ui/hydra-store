import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function POST(request) {
  try {
    const body = await request.json()
    const callbackToken = request.headers.get('x-callback-token')
    
    console.log('Xendit Webhook Received:', body)

    // 1. Verifikasi Callback Token (Security)
    const { getSettings } = await import('@/lib/settings')
    const settings = await getSettings(['XENDIT_CALLBACK_TOKEN'])
    const expectedToken = settings.XENDIT_CALLBACK_TOKEN || process.env.XENDIT_CALLBACK_TOKEN

    if (expectedToken && callbackToken !== expectedToken) {
      console.error('Invalid Xendit Callback Token!')
      return NextResponse.json({ message: 'Invalid Token' }, { status: 403 })
    }

    // 2. Cek Status Transaksi
    // Xendit Invoice Webhook status biasanya 'PAID' atau 'SETTLED'
    const { status, external_id, id } = body

    if (status === 'PAID' || status === 'SETTLED') {
      const order = await prisma.order.findUnique({
        where: { id: external_id }
      })

      if (order && order.status === 'PENDING') {
        // Update Order ke SUCCESS
        await prisma.order.update({
          where: { id: external_id },
          data: { status: 'SUCCESS' }
        })

        console.log(`Order ${external_id} marked as SUCCESS via Xendit Webhook (Invoice: ${id})`)
      }
    }

    return NextResponse.json({ message: 'OK' })
  } catch (error) {
    console.error('Xendit Webhook Error:', error)
    return NextResponse.json({ message: 'Error', error: error.message }, { status: 500 })
  }
}
