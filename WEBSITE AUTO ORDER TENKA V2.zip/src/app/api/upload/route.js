import { put } from '@vercel/blob'
import { NextResponse } from 'next/server'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'
import { v4 as uuidv4 } from 'uuid'
import { cookies } from 'next/headers'
import { verify } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export const dynamic = 'force-dynamic'

const MAX_FILE_SIZE = 2 * 1024 * 1024 * 1024; // 2GB

export async function GET(req) {
  try {
    const cookieStore = await cookies()
    const session = cookieStore.get('admin_session')?.value
    if (!session || !(await verify(session))) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const uploads = await prisma.upload.findMany({
      orderBy: { createdAt: 'desc' },
      take: 50
    })

    return NextResponse.json(uploads)
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function DELETE(req) {
  try {
    const cookieStore = await cookies()
    const session = cookieStore.get('admin_session')?.value
    if (!session || !(await verify(session))) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await req.json()
    if (!id) return NextResponse.json({ error: 'Missing ID' }, { status: 400 })

    await prisma.upload.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

// Handler for client-side registration after Blob upload
export async function PATCH(req) {
  try {
    const cookieStore = await cookies()
    const session = cookieStore.get('admin_session')?.value
    if (!session || !(await verify(session))) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { url, fileName, fileSize, fileType } = await req.json()

    if (!url || !fileName) {
      return NextResponse.json({ error: 'Data tidak lengkap' }, { status: 400 })
    }

    const dbRecord = await prisma.upload.create({
      data: {
        url,
        fileName,
        fileSize,
        fileType
      }
    })

    return NextResponse.json({ 
      success: true, 
      id: dbRecord.id,
      url: dbRecord.url
    })
  } catch (error) {
    console.error('Registration Error:', error)
    return NextResponse.json({ error: 'Gagal registrasi file: ' + error.message }, { status: 500 })
  }
}

// Legacy / Small file handler (keeps supporting older methods if needed)
export async function POST(req) {
  try {
    const cookieStore = await cookies()
    const session = cookieStore.get('admin_session')?.value
    if (!session || !(await verify(session))) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const formData = await req.formData()
    const file = formData.get('file')

    if (!file) {
      return NextResponse.json({ error: 'No file uploaded' }, { status: 400 })
    }

    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json({ error: 'File too large (Max 2GB)' }, { status: 400 })
    }

    const filename = `${uuidv4()}-${file.name}`
    let finalUrl = ''

    if (process.env.BLOB_READ_WRITE_TOKEN) {
      const blob = await put(filename, file, { access: 'public' })
      finalUrl = blob.url
    } else {
      const bytes = await file.arrayBuffer()
      const buffer = Buffer.from(bytes)
      const uploadDir = join(process.cwd(), 'public', 'uploads')
      
      try { await mkdir(uploadDir, { recursive: true }) } catch (e) {}

      const path = join(uploadDir, filename)
      await writeFile(path, buffer)
      finalUrl = `/uploads/${filename}`
    }

    const dbRecord = await prisma.upload.create({
      data: {
        url: finalUrl,
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type
      }
    })

    return NextResponse.json({ 
      success: true, 
      url: dbRecord.url,
      fileName: dbRecord.fileName,
      id: dbRecord.id
    })

  } catch (error) {
    console.error('Upload Error:', error)
    return NextResponse.json({ error: 'Upload failed: ' + error.message }, { status: 500 })
  }
}
