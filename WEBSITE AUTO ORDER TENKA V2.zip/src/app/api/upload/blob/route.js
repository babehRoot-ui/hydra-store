import { handleUpload } from '@vercel/blob/client'
import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { verify } from '@/lib/auth'

export async function POST(req) {
  const body = await req.json()

  try {
    // SECURITY: Only admin can generate tokens for upload
    const cookieStore = await cookies()
    const session = cookieStore.get('admin_session')?.value
    if (!session || !(await verify(session))) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const jsonResponse = await handleUpload({
      body,
      request: req,
      onBeforeGenerateToken: async (pathname) => {
        return {
          allowedContentTypes: [
            'application/zip', 
            'application/x-7z-compressed', 
            'application/x-rar-compressed',
            'image/jpeg', 
            'image/png', 
            'image/gif',
            'video/mp4',
            'application/octet-stream'
          ],
          tokenPayload: JSON.stringify({
            // optional, sent to your client-side onUploadCompleted callback
            userId: 'admin',
          }),
        }
      },
      onUploadCompleted: async ({ blob, tokenPayload }) => {
        // This occurs after the client-side upload is completed
        console.log('blob upload completed', blob, tokenPayload)
        
        try {
          // You could optionally save to DB here too if you want it in the history
        } catch (error) {
          throw new Error('Could not update DB')
        }
      },
    })

    return NextResponse.json(jsonResponse)
  } catch (error) {
    return NextResponse.json(
      { error: (error).message },
      { status: 400 },
    )
  }
}
