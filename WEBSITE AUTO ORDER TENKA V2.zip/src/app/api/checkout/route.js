import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export const dynamic = 'force-dynamic'

export async function POST(request) {
  try {
    const body = await request.json()
    const { productId, items, customerName, customerPhone, customerEmail, amount } = body

    if ((!productId && (!items || items.length === 0)) || !customerPhone) {
      return NextResponse.json({ success: false, message: 'Data tidak lengkap' }, { status: 400 })
    }

    // 1. Buat order di database dengan status PENDING
    // Kita set paymentMethod ke 'Pakasir' secara default
    const order = await prisma.order.create({
      data: {
        productId: productId || null,
        cartItems: items ? JSON.stringify(items) : null,
        customerName: customerName || 'Pelanggan',
        customerPhone,
        customerEmail: customerEmail || 'no-email@domain.com',
        amount: Number(amount),
        status: 'PENDING',
        paymentMethod: 'Pakasir (QRIS)',
        receiptCode: `TNKA-${Math.random().toString(36).substring(2, 8).toUpperCase()}`
      }
    })

    // 2. Cek Pengaturan Gateway
    try {
      const { getSettings } = await import('@/lib/settings')
      const settings = await getSettings(['ACTIVE_GATEWAY', 'PAKASIR_SLUG', 'PAKASIR_API_KEY', 'ATLANTIC_API_KEY', 'DOKU_CLIENT_ID', 'DOKU_SECRET_KEY', 'TRIPAY_API_KEY', 'TRIPAY_PRIVATE_KEY', 'TRIPAY_MERCHANT_CODE', 'MAYAR_API_KEY', 'DURIANPAY_API_KEY', 'UANGX_API_KEY', 'UANGX_SECRET_KEY', 'MIDTRANS_SERVER_KEY', 'MIDTRANS_CLIENT_KEY', 'MIDTRANS_IS_PRODUCTION', 'XENDIT_SECRET_KEY', 'XENDIT_CALLBACK_TOKEN', 'FASPAY_MERCHANT_ID', 'FASPAY_MERCHANT_NAME', 'FASPAY_USER_ID', 'FASPAY_PASSWORD', 'FASPAY_IS_PRODUCTION', 'IPAYMU_VA', 'IPAYMU_API_KEY', 'IPAYMU_IS_PRODUCTION', 'FINPAY_MERCHANT_ID', 'FINPAY_MERCHANT_KEY', 'FINPAY_IS_PRODUCTION', 'ESPAY_API_KEY', 'ESPAY_SIGNATURE_KEY', 'ESPAY_IS_PRODUCTION', 'DUITKU_MERCHANT_CODE', 'DUITKU_API_KEY', 'DUITKU_IS_PRODUCTION', 'OY_USER_ID', 'OY_API_KEY', 'OY_IS_PRODUCTION'])
      const activeGateway = settings.ACTIVE_GATEWAY || 'PAKASIR'

      let qrisString = ''
      let paymentUrl = null

      if (activeGateway === 'UANGX') {
        // --- UANGX PAYMENT GATEWAY ---
        const apiKey = settings.UANGX_API_KEY || process.env.UANGX_API_KEY;
        const secretKey = settings.UANGX_SECRET_KEY || process.env.UANGX_SECRET_KEY;
        
        // Setup payload untuk UangX (Membuat Transaksi QRIS/E-Wallet)
        const url = "https://api.uangx.id/v1/transaction/create"; 
        const payload = {
          order_id: order.id,
          amount: Number(amount),
          customer_name: customerName || 'Pelanggan Tenka',
          method: 'qris', // Default QRIS
        };

        const res = await fetch(url, {
          method: 'POST',
          headers: { 
            "Content-Type": "application/json",
            "x-api-key": apiKey,
            // "x-signature": signature // Biasanya butuh signature HMAC
          },
          body: JSON.stringify(payload)
        });
        
        const resData = await res.json();
        
        if (!res.ok || !resData.data) {
           throw new Error("UangX API Error: " + JSON.stringify(resData));
        }

        qrisString = resData.data.qr_content; // UangX biasanya memberikan qr_content
        paymentUrl = resData.data.checkout_url;
        
        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: 'UangX (QRIS)',
            pakasirRef: qrisString
          }
        });

      } else if (activeGateway === 'DURIANPAY') {
        // --- DURIANPAY PAYMENT GATEWAY ---
        const apiKey = settings.DURIANPAY_API_KEY || process.env.DURIANPAY_API_KEY;
        
        // Setup payload untuk Durianpay (Membuat Order)
        const url = "https://api.durianpay.com/v1/orders"; 
        const payload = {
          amount: amount.toString(),
          currency: 'IDR',
          order_ref_id: order.id,
          customer: {
            name: customerName || 'Pelanggan Tenka',
            email: customerEmail || 'no-email@domain.com',
            phone: customerPhone
          },
          items: [
            {
              name: 'Produk Tenka Store',
              qty: 1,
              price: amount.toString()
            }
          ]
        };

        // Durianpay menggunakan Basic Auth (API Key sebagai username)
        const res = await fetch(url, {
          method: 'POST',
          headers: { 
            "Content-Type": "application/json",
            "Authorization": `Basic ${Buffer.from(apiKey + ':').toString('base64')}`
          },
          body: JSON.stringify(payload)
        });
        
        const resData = await res.json();
        
        if (!res.ok || !resData.data) {
           throw new Error("Durianpay API Error: " + JSON.stringify(resData));
        }

        // Durianpay biasanya memberikan checkout_url atau kita bisa generate payment link
        paymentUrl = resData.data.payment_url || `https://checkout.durianpay.com/order/${resData.data.id}`;
        
        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: 'Durianpay',
            pakasirRef: paymentUrl
          }
        });

      } else if (activeGateway === 'MAYAR') {
        // --- MAYAR PAYMENT GATEWAY ---
        const apiKey = settings.MAYAR_API_KEY || process.env.MAYAR_API_KEY;
        
        // Setup payload untuk Mayar (Membuat Payment Link Tunggal)
        const url = "https://api.mayar.id/v1/payment/create"; 
        const payload = {
          name: customerName || 'Pelanggan Tenka',
          email: customerEmail || 'no-email@domain.com',
          amount: Number(amount),
          description: `Pembelian Produk Tenka Store - Order ID: ${order.id}`,
          referenceId: order.id,
          paymentMethod: ['QRIS'] // Bisa disesuaikan dengan jenis metode yang diizinkan Mayar
        };

        const res = await fetch(url, {
          method: 'POST',
          headers: { 
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
          },
          body: JSON.stringify(payload)
        });
        
        const resData = await res.json();
        
        if (!res.ok || !resData.link) {
           throw new Error("Mayar API Error: " + JSON.stringify(resData));
        }

        // Mayar biasanya memberikan link pembayaran, namun kita bisa menggunakan property qr_link jika tersedia
        paymentUrl = resData.link;
        qrisString = resData.qr_code || null; 
        
        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: 'Mayar (Payment Link)',
            pakasirRef: paymentUrl // Simpan link Mayar
          }
        });

      } else if (activeGateway === 'TRIPAY') {
        // --- TRIPAY PAYMENT GATEWAY ---
        const apiKey = settings.TRIPAY_API_KEY || process.env.TRIPAY_API_KEY;
        const privateKey = settings.TRIPAY_PRIVATE_KEY || process.env.TRIPAY_PRIVATE_KEY;
        const merchantCode = settings.TRIPAY_MERCHANT_CODE || process.env.TRIPAY_MERCHANT_CODE;
        
        // Setup payload untuk Tripay (Closed Payment / QRIS)
        const url = "https://tripay.co.id/api/transaction/create"; // Ganti ke /api-sandbox/ untuk mode tes
        const payload = {
          method: 'QRIS',
          merchant_ref: order.id,
          amount: Number(amount),
          customer_name: customerName || 'Pelanggan',
          customer_email: customerEmail || 'no-email@domain.com',
          customer_phone: customerPhone,
          order_items: [
            {
              name: 'Produk Tenka Store',
              price: Number(amount),
              quantity: 1
            }
          ],
          return_url: 'https://domain-anda.com' // Bisa diganti dengan env var return url
        };

        // Di Tripay yang sebenarnya, Anda perlu men-generate HMAC-SHA256 Signature
        // Menggunakan library crypto (node:crypto). Contoh:
        // const crypto = require('crypto');
        // const signature = crypto.createHmac('sha256', privateKey).update(merchantCode + order.id + amount).digest('hex');

        const res = await fetch(url, {
          method: 'POST',
          headers: { 
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
            // "Signature": signature // Jika benar-benar diaktifkan, ini wajib.
          },
          body: JSON.stringify(payload)
        });
        
        const resData = await res.json();
        
        // Asumsi respons dari Tripay (Mocking)
        if (!resData.success) {
           throw new Error("Tripay API Error: " + JSON.stringify(resData));
        }

        qrisString = resData.data.qr_url; // Tripay biasanya mereturn qr_url
        paymentUrl = resData.data.checkout_url;
        
        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: 'Tripay (QRIS)',
            pakasirRef: qrisString // Simpan QR String atau checkout url
          }
        });

      } else if (activeGateway === 'DOKU') {
        // --- DOKU PAYMENT GATEWAY ---
        const clientId = settings.DOKU_CLIENT_ID || process.env.DOKU_CLIENT_ID;
        const secretKey = settings.DOKU_SECRET_KEY || process.env.DOKU_SECRET_KEY;
        const url = "https://api.doku.com/jokul/v1/checkout/qris"; // URL Mock/Contoh untuk DOKU QRIS Jokul

        const dokuBody = {
          order: {
            invoice_number: order.id,
            amount: Number(amount)
          }
        };

        const res = await fetch(url, {
          method: 'POST',
          headers: { 
            "Content-Type": "application/json",
            "Client-Id": clientId,
            "Request-Id": order.id,
            "Request-Timestamp": new Date().toISOString(),
            // DOKU biasanya butuh Signature (HMAC-SHA256). Di sini diasumsikan sistem library Doku.
          },
          body: JSON.stringify(dokuBody)
        });
        
        const resData = await res.json();
        
        // Asumsi struktur respons DOKU
        if (!resData?.response?.qr_string) {
           throw new Error("DOKU API Error / Key Salah: " + JSON.stringify(resData));
        }

        qrisString = resData.response.qr_string;
        
        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: 'DOKU (QRIS)',
            pakasirRef: qrisString
          }
        });

      } else if (activeGateway === 'ATLANTIC') {
        // --- ATLANTIC PAYMENT GATEWAY ---
        const apiKey = settings.ATLANTIC_API_KEY || process.env.ATLANTIC_API_KEY;
        const url = "https://atlantic-pedia.co.id/api/v1/deposit"; // Sesuaikan jika menggunakan layanan turunan Atlantic lain
        
        // Standar parameter Atlantic
        const body = new URLSearchParams({
          key: apiKey,
          action: 'deposit',
          method: 'qris',
          amount: amount.toString(),
        });

        const res = await fetch(url, {
          method: 'POST',
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: body.toString()
        });
        
        const resData = await res.json();
        
        // Asumsi data mereturn qr_string
        if (!resData.result || !resData.data?.qr_string) {
           throw new Error("Atlantic API Error / Saldo Tidak Cukup / IP Tidak Whitelist: " + JSON.stringify(resData));
        }

        qrisString = resData.data.qr_string;
        
        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: 'Atlantic (QRIS)',
            pakasirRef: qrisString // Simpan QR String
          }
        });

      } else if (activeGateway === 'MIDTRANS') {
        // --- MIDTRANS PAYMENT GATEWAY ---
        const serverKey = settings.MIDTRANS_SERVER_KEY || process.env.MIDTRANS_SERVER_KEY;
        const isProd = settings.MIDTRANS_IS_PRODUCTION === 'yes';
        const url = isProd 
          ? "https://app.midtrans.com/snap/v1/transactions" 
          : "https://app.sandbox.midtrans.com/snap/v1/transactions";

        const midtransBody = {
          transaction_details: {
            order_id: order.id,
            gross_amount: Number(amount)
          },
          customer_details: {
            first_name: customerName || 'Pelanggan',
            email: customerEmail || 'no-email@domain.com',
            phone: customerPhone
          },
          item_details: [{
            id: productId,
            price: Number(amount),
            quantity: 1,
            name: 'Produk Tenka Store'
          }]
        };

        const auth = Buffer.from(serverKey + ':').toString('base64');
        const res = await fetch(url, {
          method: 'POST',
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": `Basic ${auth}`
          },
          body: JSON.stringify(midtransBody)
        });

        const resData = await res.json();

        if (!res.ok || !resData.token) {
          throw new Error("Midtrans API Error: " + JSON.stringify(resData));
        }

        // Midtrans Snap mengembalikan 'token' dan 'redirect_url'
        paymentUrl = resData.redirect_url;
        
        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: `Midtrans (${isProd ? 'Prod' : 'Sandbox'})`,
            pakasirRef: resData.token // Simpan token snap
          }
        });

      } else if (activeGateway === 'XENDIT') {
        // --- XENDIT PAYMENT GATEWAY ---
        const secretKey = settings.XENDIT_SECRET_KEY || process.env.XENDIT_SECRET_KEY;
        const url = "https://api.xendit.co/v2/invoices";

        const xenditBody = {
          external_id: order.id,
          amount: Number(amount),
          payer_email: customerEmail || 'no-email@domain.com',
          description: `Pembelian Produk Tenka Store - ${order.id}`,
          customer: {
            given_names: customerName || 'Pelanggan',
            mobile_number: customerPhone
          },
          success_redirect_url: `https://${request.headers.get('host')}/checkout/success`,
          failure_redirect_url: `https://${request.headers.get('host')}/checkout/failure`,
          items: [{
            name: 'Produk Tenka Store',
            quantity: 1,
            price: Number(amount)
          }]
        };

        const auth = Buffer.from(secretKey + ':').toString('base64');
        const res = await fetch(url, {
          method: 'POST',
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Basic ${auth}`
          },
          body: JSON.stringify(xenditBody)
        });

        const resData = await res.json();

        if (!res.ok || !resData.invoice_url) {
          throw new Error("Xendit API Error: " + JSON.stringify(resData));
        }

        paymentUrl = resData.invoice_url;
        
        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: 'Xendit (Invoice)',
            pakasirRef: resData.id // Simpan invoice id xendit
          }
        });

      } else if (activeGateway === 'FASPAY') {
        // --- FASPAY PAYMENT GATEWAY ---
        const merchantId = settings.FASPAY_MERCHANT_ID || process.env.FASPAY_MERCHANT_ID;
        const merchantName = settings.FASPAY_MERCHANT_NAME || process.env.FASPAY_MERCHANT_NAME;
        const userId = settings.FASPAY_USER_ID || process.env.FASPAY_USER_ID;
        const password = settings.FASPAY_PASSWORD || process.env.FASPAY_PASSWORD;
        const isProd = settings.FASPAY_IS_PRODUCTION === 'yes';

        const url = isProd
          ? "https://web.faspay.co.id/pws/post_data_transaksi"
          : "https://sandbox.faspay.co.id/pws/post_data_transaksi";

        const crypto = await import('crypto');
        const signature = crypto.createHash('md5').update(userId + password + order.id).digest('hex');

        const faspayBody = {
          request: "Post Data Transaksi",
          merchant_id: merchantId,
          merchant: merchantName,
          bill_no: order.id,
          bill_date: new Date().toISOString().replace(/T/, ' ').replace(/\..+/, ''),
          bill_desc: `Pembelian Produk Tenka Store`,
          bill_items: [{
            item: 'Produk Tenka Store',
            qty: 1,
            price: amount.toString(),
            amount: amount.toString(),
            type: 'digital'
          }],
          bill_total: amount.toString(),
          cust_no: customerPhone,
          cust_name: customerName || 'Pelanggan',
          msisdn: customerPhone,
          email: customerEmail || 'no-email@domain.com',
          terminal: '10',
          signature: signature,
          return_url: `https://${request.headers.get('host')}/checkout/success`
        };

        const res = await fetch(url, {
          method: 'POST',
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(faspayBody)
        });

        const resData = await res.json();

        if (!res.ok || !resData.redirect_url) {
          throw new Error("Faspay API Error: " + JSON.stringify(resData));
        }

        paymentUrl = resData.redirect_url;

        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: `Faspay (${isProd ? 'Prod' : 'Dev'})`,
            pakasirRef: resData.trx_id // Simpan Faspay Trx ID
          }
        });

      } else if (activeGateway === 'IPAYMU') {
        // --- IPAYMU PAYMENT GATEWAY ---
        const va = settings.IPAYMU_VA || process.env.IPAYMU_VA;
        const apiKey = settings.IPAYMU_API_KEY || process.env.IPAYMU_API_KEY;
        const isProd = settings.IPAYMU_IS_PRODUCTION === 'yes';

        const url = isProd
          ? "https://my.ipaymu.com/api/v2/payment"
          : "https://sandbox.ipaymu.com/api/v2/payment";

        const ipaymuBody = {
          name: customerName || 'Pelanggan',
          email: customerEmail || 'no-email@domain.com',
          phone: customerPhone,
          amount: amount.toString(),
          notifyUrl: `https://${request.headers.get('host')}/api/ipaymu/webhook`,
          returnUrl: `https://${request.headers.get('host')}/checkout/success`,
          cancelUrl: `https://${request.headers.get('host')}/`,
          referenceId: order.id,
          product: ['Produk Tenka Store'],
          qty: ['1'],
          price: [amount.toString()]
        };

        const crypto = await import('crypto');
        const bodyString = JSON.stringify(ipaymuBody);
        const bodyHash = crypto.createHash('sha256').update(bodyString).digest('hex');
        const stringToSign = `POST:${va}:${bodyHash}:${apiKey}`;
        const signature = crypto.createHmac('sha256', apiKey).update(stringToSign).digest('hex');

        const res = await fetch(url, {
          method: 'POST',
          headers: {
            "Content-Type": "application/json",
            "va": va,
            "signature": signature
          },
          body: bodyString
        });

        const resData = await res.json();

        if (!res.ok || !resData.data?.Url) {
          throw new Error("iPaymu API Error: " + JSON.stringify(resData));
        }

        paymentUrl = resData.data.Url;

        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: `iPaymu (${isProd ? 'Prod' : 'Sandbox'})`,
            pakasirRef: resData.data.SessionId // Simpan Session ID iPaymu
          }
        });

      } else if (activeGateway === 'FINPAY') {
        // --- FINPAY PAYMENT GATEWAY ---
        const merchantId = settings.FINPAY_MERCHANT_ID || process.env.FINPAY_MERCHANT_ID;
        const merchantKey = settings.FINPAY_MERCHANT_KEY || process.env.FINPAY_MERCHANT_KEY;
        const isProd = settings.FINPAY_IS_PRODUCTION === 'yes';

        const url = isProd
          ? "https://bill.finpay.id/capture"
          : "https://sandbox.finpay.id/capture";

        const crypto = await import('crypto');
        const signature = crypto.createHash('sha256').update(merchantId + order.id + amount + merchantKey).digest('hex');

        const finpayBody = {
          merchant_id: merchantId,
          bill_no: order.id,
          amount: amount.toString(),
          customer_name: customerName || 'Pelanggan',
          customer_email: customerEmail || 'no-email@domain.com',
          customer_phone: customerPhone,
          signature: signature,
          return_url: `https://${request.headers.get('host')}/checkout/success`,
          notify_url: `https://${request.headers.get('host')}/api/finpay/webhook`,
          items: [{
            name: 'Produk Tenka Store',
            qty: 1,
            price: amount.toString()
          }]
        };

        const res = await fetch(url, {
          method: 'POST',
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(finpayBody)
        });

        const resData = await res.json();

        if (!res.ok || !resData.redirect_url) {
          throw new Error("Finpay API Error: " + JSON.stringify(resData));
        }

        paymentUrl = resData.redirect_url;

        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: `Finpay (${isProd ? 'Prod' : 'Sandbox'})`,
            pakasirRef: resData.trx_id // Simpan Trx ID Finpay
          }
        });

      } else if (activeGateway === 'ESPAY') {
        // --- ESPAY PAYMENT GATEWAY ---
        const apiKey = settings.ESPAY_API_KEY || process.env.ESPAY_API_KEY;
        const signatureKey = settings.ESPAY_SIGNATURE_KEY || process.env.ESPAY_SIGNATURE_KEY;
        const isProd = settings.ESPAY_IS_PRODUCTION === 'yes';

        const url = isProd
          ? "https://api.espay.id/payment/create"
          : "https://sandbox-api.espay.id/payment/create";

        const crypto = await import('crypto');
        // Signature: SHA256(API_KEY + ORDER_ID + AMOUNT + SIGNATURE_KEY)
        const signature = crypto.createHash('sha256').update(apiKey + order.id + amount + signatureKey).digest('hex');

        const espayBody = {
          api_key: apiKey,
          order_id: order.id,
          amount: Number(amount),
          customer_name: customerName || 'Pelanggan',
          customer_email: customerEmail || 'no-email@domain.com',
          customer_phone: customerPhone,
          signature: signature,
          return_url: `https://${request.headers.get('host')}/checkout/success`,
          notify_url: `https://${request.headers.get('host')}/api/espay/webhook`,
          items: [{
            product_id: productId,
            product_name: 'Produk Tenka Store',
            qty: 1,
            price: Number(amount)
          }]
        };

        const res = await fetch(url, {
          method: 'POST',
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(espayBody)
        });

        const resData = await res.json();

        if (!res.ok || !resData.payment_url) {
          throw new Error("Espay API Error: " + JSON.stringify(resData));
        }

        paymentUrl = resData.payment_url;

        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: `Espay (${isProd ? 'Prod' : 'Sandbox'})`,
            pakasirRef: resData.trx_id // Simpan Trx ID Espay
          }
        });

      } else if (activeGateway === 'DUITKU') {
        // --- DUITKU PAYMENT GATEWAY ---
        const merchantCode = settings.DUITKU_MERCHANT_CODE || process.env.DUITKU_MERCHANT_CODE;
        const apiKey = settings.DUITKU_API_KEY || process.env.DUITKU_API_KEY;
        const isProd = settings.DUITKU_IS_PRODUCTION === 'yes';

        const url = isProd
          ? "https://passport.duitku.com/webapi/api/merchant/v2/inquiry"
          : "https://sandbox.duitku.com/webapi/api/merchant/v2/inquiry";

        const crypto = await import('crypto');
        const signature = crypto.createHash('md5').update(merchantCode + order.id + amount + apiKey).digest('hex');

        const duitkuBody = {
          merchantCode: merchantCode,
          paymentAmount: Number(amount),
          merchantOrderId: order.id,
          productDetails: 'Pembelian Produk Tenka Store',
          email: customerEmail || 'no-email@domain.com',
          phoneNumber: customerPhone,
          customerVaName: customerName || 'Pelanggan Tenka',
          callbackUrl: `https://${request.headers.get('host')}/api/duitku/webhook`,
          returnUrl: `https://${request.headers.get('host')}/checkout/success`,
          signature: signature,
          expiryPeriod: 1440
        };

        const res = await fetch(url, {
          method: 'POST',
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(duitkuBody)
        });

        const resData = await res.json();

        if (!res.ok || !resData.paymentUrl) {
          throw new Error("Duitku API Error: " + (resData.message || JSON.stringify(resData)));
        }

        paymentUrl = resData.paymentUrl;

        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: `Duitku (${isProd ? 'Prod' : 'Sandbox'})`,
            pakasirRef: resData.reference // Simpan Duitku Reference
          }
        });

      } else if (activeGateway === 'OY') {
        // --- OY! BISNIS PAYMENT GATEWAY ---
        const userId = settings.OY_USER_ID || process.env.OY_USER_ID;
        const apiKey = settings.OY_API_KEY || process.env.OY_API_KEY;
        const isProd = settings.OY_IS_PRODUCTION === 'yes';

        const url = isProd
          ? "https://api-rebranding.oyindonesia.com/api/payment-link/create"
          : "https://api-stg-rebranding.oyindonesia.com/api/payment-link/create";

        const oyBody = {
          description: `Pembelian Produk Tenka Store - ${order.id}`,
          partner_tx_id: order.id,
          notes: `Order ID: ${order.id}`,
          sender_name: customerName || 'Pelanggan Tenka',
          amount: Number(amount),
          email: customerEmail || 'no-email@domain.com',
          phone_number: customerPhone,
          is_open: false,
          step: 'payment_method_selection',
          include_admin_fee: true,
          expiration: 1440
        };

        const res = await fetch(url, {
          method: 'POST',
          headers: {
            "Content-Type": "application/json",
            "x-oy-username": userId,
            "x-api-key": apiKey
          },
          body: JSON.stringify(oyBody)
        });

        const resData = await res.json();

        if (!res.ok || !resData.url) {
          throw new Error("OY! API Error: " + (resData.message || JSON.stringify(resData)));
        }

        paymentUrl = resData.url;

        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: `OY! Bisnis (${isProd ? 'Prod' : 'Sandbox'})`,
            pakasirRef: resData.payment_link_id // Simpan OY Payment Link ID
          }
        });

      } else {
        // --- PAKASIR PAYMENT GATEWAY ---
        const pakasirSlug = settings.PAKASIR_SLUG || process.env.PAKASIR_SLUG;
        const pakasirApiKey = settings.PAKASIR_API_KEY || process.env.PAKASIR_API_KEY;

        const url = "https://app.pakasir.com/api/transactioncreate/qris";
        const pakasirBody = {
          project: pakasirSlug,
          order_id: order.id,
          amount: Number(amount),
          api_key: pakasirApiKey
        };

        const res = await fetch(url, {
          method: 'POST',
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(pakasirBody)
        });
        
        const resData = await res.json();
        const payment = resData?.payment;
        
        if (!payment?.payment_number) {
           throw new Error("QR Pakasir tidak ditemukan dalam response API.");
        }

        qrisString = payment.payment_number;
        paymentUrl = resData?.payment_url || null; 
        
        await prisma.order.update({
          where: { id: order.id },
          data: { 
            paymentMethod: 'Pakasir (QRIS)',
            pakasirRef: qrisString 
          }
        });
      }

      return NextResponse.json({ 
        success: true, 
        orderId: order.id,
        paymentUrl,
        qrisString,
        message: `Order created with ${activeGateway}`
      })
    } catch (apiError) {
      console.error('Payment API Error:', apiError)
      return NextResponse.json({ 
        success: false, 
        message: `Gagal memproses gateway: ${apiError.message}` 
      }, { status: 500 })
    }

  } catch (error) {
    console.error('Checkout Error:', error)
    return NextResponse.json({ success: false, message: `Internal server error: ${error.message}` }, { status: 500 })
  }
}
