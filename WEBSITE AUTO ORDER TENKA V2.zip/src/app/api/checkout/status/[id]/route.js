import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(request, { params }) {
  try {
    const { id } = await params
    const order = await prisma.order.findUnique({
      where: { id },
      include: { product: true }
    })

    if (!order) {
      return NextResponse.json({ success: false, message: 'Order tidak ditemukan' }, { status: 404 })
    }

    return NextResponse.json({ 
      success: true, 
      status: order.status, 
      receiptCode: order.receiptCode,
      deliveryType: order.status === 'SUCCESS' ? order.product?.deliveryType : null,
      deliveryContent: order.status === 'SUCCESS' ? order.product?.deliveryContent : null,
      deliveryLink2: order.status === 'SUCCESS' ? order.product?.deliveryLink2 : null,
      deliveryLink2Desc: order.status === 'SUCCESS' ? order.product?.deliveryLink2Desc : null
    })
  } catch (error) {
    console.error('Status Check Error:', error)
    return NextResponse.json({ success: false, message: error.message }, { status: 500 })
  }
}
