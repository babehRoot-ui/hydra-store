import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const methods = await prisma.paymentMethod.findMany({
      where: { active: true }
    })
    return NextResponse.json(methods)
  } catch (error) {
    return NextResponse.json([], { status: 500 })
  }
}
