import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function POST(request) {
  try {
    const body = await request.json()
    console.log('OY! Webhook Received:', body)

    // OY! parameter standar
    // partner_tx_id adalah Order ID kita
    const { 
      status, 
      partner_tx_id, 
      amount,
      payment_method
    } = body

    // Cek Status Pembayaran
    // OY! status 'SUCCESS' berarti lunas
    if (status === 'SUCCESS') {
      const order = await prisma.order.findUnique({
        where: { id: partner_tx_id }
      })

      if (order && order.status === 'PENDING') {
        // Update Order ke SUCCESS
        await prisma.order.update({
          where: { id: partner_tx_id },
          data: { status: 'SUCCESS' }
        })

        console.log(`Order ${partner_tx_id} marked as SUCCESS via OY! Webhook`)
      }
    }

    return NextResponse.json({ status: 'OK' })
  } catch (error) {
    console.error('OY! Webhook Error:', error)
    return NextResponse.json({ message: 'Error', error: error.message }, { status: 500 })
  }
}
