import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import crypto from 'crypto'

export async function POST(request) {
  try {
    const body = await request.json()
    console.log('Midtrans Webhook Received:', body)

    const { 
      order_id, 
      status_code, 
      gross_amount, 
      transaction_status, 
      signature_key,
      payment_type
    } = body

    // 1. Verifikasi Signature (Security)
    const { getSettings } = await import('@/lib/settings')
    const settings = await getSettings(['MIDTRANS_SERVER_KEY'])
    const serverKey = settings.MIDTRANS_SERVER_KEY || process.env.MIDTRANS_SERVER_KEY

    const hashed = crypto
      .createHash('sha512')
      .update(order_id + status_code + gross_amount + serverKey)
      .digest('hex')

    if (hashed !== signature_key) {
      console.error('Invalid Midtrans Signature!')
      return NextResponse.json({ message: 'Invalid Signature' }, { status: 403 })
    }

    // 2. Cek Status Transaksi
    // Status sukses di Midtrans: 'capture' (untuk CC) atau 'settlement' (untuk QRIS/E-Wallet/VA)
    if (transaction_status === 'settlement' || transaction_status === 'capture') {
      const order = await prisma.order.findUnique({
        where: { id: order_id }
      })

      if (order && order.status === 'PENDING') {
        // Update Order ke SUCCESS
        await prisma.order.update({
          where: { id: order_id },
          data: { status: 'SUCCESS' }
        })

        // Opsional: Kirim notifikasi WA atau proses pengiriman produk otomatis di sini
        console.log(`Order ${order_id} marked as SUCCESS via Midtrans Webhook`)
      }
    }

    return NextResponse.json({ message: 'OK' })
  } catch (error) {
    console.error('Midtrans Webhook Error:', error)
    return NextResponse.json({ message: 'Error', error: error.message }, { status: 500 })
  }
}
