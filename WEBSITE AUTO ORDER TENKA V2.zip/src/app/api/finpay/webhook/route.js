import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import crypto from 'crypto'

export async function POST(request) {
  try {
    const body = await request.json()
    console.log('Finpay Webhook Received:', body)

    const { 
      merchant_id, 
      bill_no, 
      amount, 
      result_code, 
      signature 
    } = body

    // 1. Verifikasi Signature (Security)
    const { getSettings } = await import('@/lib/settings')
    const settings = await getSettings(['FINPAY_MERCHANT_KEY'])
    const merchantKey = settings.FINPAY_MERCHANT_KEY || process.env.FINPAY_MERCHANT_KEY

    // Signature Finpay: SHA256(MERCHANT_ID + BILL_NO + AMOUNT + RESULT_CODE + MERCHANT_KEY)
    const expectedSignature = crypto
      .createHash('sha256')
      .update(merchant_id + bill_no + amount + result_code + merchantKey)
      .digest('hex')

    if (signature !== expectedSignature) {
      console.error('Invalid Finpay Signature!')
      return NextResponse.json({ message: 'Invalid Signature' }, { status: 403 })
    }

    // 2. Cek Status Transaksi
    // Finpay result_code '00' berarti SUCCESS
    if (result_code === '00') {
      const order = await prisma.order.findUnique({
        where: { id: bill_no }
      })

      if (order && order.status === 'PENDING') {
        // Update Order ke SUCCESS
        await prisma.order.update({
          where: { id: bill_no },
          data: { status: 'SUCCESS' }
        })

        console.log(`Order ${bill_no} marked as SUCCESS via Finpay Webhook`)
      }
    }

    return NextResponse.json({ message: 'OK', status: 'Success' })
  } catch (error) {
    console.error('Finpay Webhook Error:', error)
    return NextResponse.json({ message: 'Error', error: error.message }, { status: 500 })
  }
}
