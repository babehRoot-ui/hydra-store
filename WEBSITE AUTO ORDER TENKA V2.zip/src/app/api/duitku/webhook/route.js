import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import crypto from 'crypto'

export async function POST(request) {
  try {
    // Duitku biasanya mengirim via Form-Data atau JSON
    const contentType = request.headers.get('content-type') || ''
    let body = {}
    
    if (contentType.includes('application/json')) {
      body = await request.json()
    } else {
      const formData = await request.formData()
      formData.forEach((value, key) => {
        body[key] = value
      })
    }

    console.log('Duitku Webhook Received:', body)

    const { 
      merchantCode, 
      amount, 
      merchantOrderId, 
      signature, 
      resultCode 
    } = body

    // 1. Verifikasi Signature (Security)
    const { getSettings } = await import('@/lib/settings')
    const settings = await getSettings(['DUITKU_API_KEY'])
    const apiKey = settings.DUITKU_API_KEY || process.env.DUITKU_API_KEY

    // Signature Duitku: MD5(MERCHANT_CODE + AMOUNT + MERCHANT_ORDER_ID + API_KEY)
    const expectedSignature = crypto
      .createHash('md5')
      .update(merchantCode + amount + merchantOrderId + apiKey)
      .digest('hex')

    if (signature !== expectedSignature) {
      console.error('Invalid Duitku Signature!')
      return NextResponse.json({ message: 'Invalid Signature' }, { status: 403 })
    }

    // 2. Cek Status Pembayaran
    // Duitku resultCode '00' berarti SUCCESS / PAID
    if (resultCode === '00') {
      const order = await prisma.order.findUnique({
        where: { id: merchantOrderId }
      })

      if (order && order.status === 'PENDING') {
        // Update Order ke SUCCESS
        await prisma.order.update({
          where: { id: merchantOrderId },
          data: { status: 'SUCCESS' }
        })

        console.log(`Order ${merchantOrderId} marked as SUCCESS via Duitku Webhook`)
      }
    }

    return NextResponse.json({ message: 'OK' })
  } catch (error) {
    console.error('Duitku Webhook Error:', error)
    return NextResponse.json({ message: 'Error', error: error.message }, { status: 500 })
  }
}
