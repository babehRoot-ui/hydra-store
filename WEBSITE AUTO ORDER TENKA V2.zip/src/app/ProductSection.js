'use client'
import { useCart } from '@/lib/CartContext'

export default function ProductSection({ products, title = 'Daftar Produk', onBuy }) {
  const { addToCart } = useCart()

  return (
    <>
      <section className="container" style={{ marginBottom: '4rem' }}>
        {title && (
          <div className="flex justify-between items-center" style={{ marginBottom: '1.5rem' }}>
            <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>{title}</h2>
          </div>
        )}
        
        <div className="compact-grid" style={{ gap: '16px' }}>
          {products && products.map(product => (
            <div 
              key={product.id} 
              className="compact-card" 
              style={{ userSelect: 'none', padding: '0.75rem', position: 'relative' }}
            >
              {product.badge && (
                <div className="compact-card-badge" style={{
                  background: product.badge === 'HOT' ? '#ef4444' : product.badge === 'NEW' ? '#10b981' : '#8b5cf6',
                }}>
                  {product.badge}
                </div>
              )}
              
              <div className="compact-card-img-wrapper" onClick={() => onBuy && onBuy(product)} style={{ cursor: 'pointer' }}>
                {product.imageUrl
                  ? <img src={product.imageUrl} alt={product.name} className="compact-card-img" />
                  : <div className="compact-card-img" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2.5rem', background: 'rgba(255,255,255,0.02)' }}>📦</div>
                }
              </div>

              <div className="compact-card-body">
                <div onClick={() => onBuy && onBuy(product)} style={{ cursor: 'pointer' }}>
                  {product.category && (
                    <span className="compact-card-cat">{product.category}</span>
                  )}
                  <h3 className="compact-card-title">{product.name}</h3>
                  <div className="compact-card-price">
                    {Number(product.price) === 0 ? (
                      <span style={{ color: '#f59e0b', fontWeight: 800 }}>GRATIS</span>
                    ) : (
                      `Rp ${product.price.toLocaleString('id-ID')}`
                    )}
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '8px', marginTop: '1rem' }}>
                  <button 
                    onClick={() => onBuy && onBuy(product)}
                    className="btn-buy-now"
                    style={{ flex: 1, padding: '0.5rem', fontSize: '0.75rem', fontWeight: 700, borderRadius: '6px', background: 'rgba(139,92,246,0.2)', border: '1px solid rgba(139,92,246,0.3)', color: '#c084fc', cursor: 'pointer' }}
                  >
                    Beli Langsung
                  </button>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      addToCart(product);
                    }}
                    className="btn-add-cart"
                    style={{ padding: '0.5rem', fontSize: '1rem', borderRadius: '6px', background: 'rgba(16,185,129,0.2)', border: '1px solid rgba(16,185,129,0.3)', color: '#34d399', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                    title="Tambah ke Keranjang"
                  >
                    🛒
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <style jsx>{`
        .btn-buy-now:hover { background: rgba(139,92,246,0.3) !important; }
        .btn-add-cart:hover { background: rgba(16,185,129,0.3) !important; }
      `}</style>
    </>
  )
}
