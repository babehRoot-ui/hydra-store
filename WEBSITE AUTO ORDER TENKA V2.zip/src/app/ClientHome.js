'use client'
import { useState } from 'react'
import CategoryFilter from './CategoryFilter'
import ProductSection from './ProductSection'
import TransactionFeed from './TransactionFeed'
import SpaceBackground from './SpaceBackground'
import WelcomePopup from './WelcomePopup'
import CheckoutSection from './CheckoutSection'
import Link from 'next/link'

export default function ClientHome({ products, initialCategories, welcomeData }) {
  const [filteredProducts, setFilteredProducts] = useState(products)
  const [activeCategory, setActiveCategory] = useState('all')
  const [selectedProduct, setSelectedProduct] = useState(null)

  const handleBuy = (product) => {
    setSelectedProduct(product)
    setTimeout(() => {
      const el = document.getElementById('checkout-section')
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' })
      }
    }, 100)
  }

  const handleFilterChange = (slug) => {
    setActiveCategory(slug)
    if (slug === 'all') {
      setFilteredProducts(products)
    } else {
      setFilteredProducts(products.filter(p => p.category?.toLowerCase() === slug.toLowerCase() || p.subcategory?.toLowerCase() === slug.toLowerCase()))
    }
  }

  return (
    <div style={{ position: 'relative', minHeight: '100vh' }}>
      <SpaceBackground variant={0} />
      <WelcomePopup {...welcomeData} />

      {/* Wrapper for zoomed content - Excluding Modals */}
      <div className="zoom-out-layout">
        {/* Hero Section */}
        <section className="container flex flex-col items-center justify-center text-center" style={{ padding: '8rem 0 4rem', position: 'relative', zIndex: 1 }}>
          <div className="animate-fade-in hero-badge">
            🚀 Premium Digital Solution
          </div>
          <h1 className="animate-fade-in hero-title">
            Tenka x <span className="text-gradient">Paiz Store</span>
          </h1>
          <p className="animate-fade-in hero-desc text-secondary">
            Platform penyedia script bot WhatsApp terbaik, panel reseller eksklusif, dan berbagai kebutuhan digital premium dengan pengiriman otomatis secepat kilat.
          </p>
        </section>

        {/* Modern Filter Section */}
        <section className="container" style={{ position: 'relative', zIndex: 1, marginBottom: '2rem' }}>
          <CategoryFilter categories={initialCategories} onFilterChange={handleFilterChange} />
        </section>

        {/* Product Section */}
        <div style={{ position: 'relative', zIndex: 1 }}>
          {activeCategory === 'all' ? (
            initialCategories.map(cat => {
              const catProducts = filteredProducts.filter(p => p.category?.toLowerCase() === cat.slug.toLowerCase())
              if (catProducts.length === 0) return null;
              return (
                <ProductSection key={cat.slug} products={catProducts} title={`Kategori: ${cat.label}`} onBuy={handleBuy} />
              )
            })
          ) : (
            <ProductSection products={filteredProducts} title={`Produk: ${initialCategories.find(c => c.slug === activeCategory)?.label || ''}`} onBuy={handleBuy} />
          )}
        </div>

        {/* Transaction Feed */}
        <div style={{ position: 'relative', zIndex: 1 }}>
          <TransactionFeed />
        </div>

        {filteredProducts.length === 0 && (
          <section className="container" style={{ position: 'relative', zIndex: 1 }}>
            <div className="glass-card flex flex-col items-center justify-center text-center" style={{ padding: '4rem 2rem' }}>
              <p style={{ fontSize: '3rem', marginBottom: '1rem' }}>📦</p>
              <p style={{ fontSize: '1.25rem', fontWeight: 800, marginBottom: '0.5rem' }}>Tidak ada produk</p>
              <p className="text-secondary" style={{ fontSize: '0.9rem' }}>Produk untuk kategori ini belum tersedia.</p>
            </div>
          </section>
        )}
      </div>

      <div className="container" style={{ paddingBottom: '4rem' }}>
        <CheckoutSection 
          product={selectedProduct} 
          onReset={() => setSelectedProduct(null)} 
        />
      </div>

      <style jsx global>{`
        .zoom-out-layout {
          /* Transform scale is safer than zoom for fixed overlays */
          transform: scale(0.95);
          transform-origin: top center;
          transition: transform 0.5s ease;
          width: 100%;
        }
        @media (max-width: 768px) {
          .zoom-out-layout { transform: scale(1); }
        }
        
        .hero-badge {
          display: inline-block; 
          padding: 0.4rem 1rem; 
          background: rgba(139, 92, 246, 0.1); 
          border: 1px solid rgba(139, 92, 246, 0.2); 
          border-radius: 9999px; 
          marginBottom: 1.5rem; 
          fontSize: 0.85rem; 
          color: #c084fc; 
          fontWeight: 700;
        }
        .hero-title {
          fontSize: clamp(2.5rem, 8vw, 4.5rem); 
          fontWeight: 900; 
          lineHeight: 1.1; 
          marginBottom: 1.5rem; 
          letterSpacing: -0.04em;
        }
        .hero-desc {
          maxWidth: 700px; 
          fontSize: 1.1rem; 
          lineHeight: 1.6;
        }
      `}</style>
    </div>
  )
}
