import { cookies, headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { sign, verify } from '@/lib/auth'
import { checkRateLimit, recordFailedAttempt, clearAttempts } from '@/lib/rateLimiter'
import { getSettings } from '@/lib/settings'

// ─── Captcha Generator ───────────────────────────────────────────────────────
function generateCaptcha() {
  const r = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min
  const ops = ['add', 'sub', 'mul', 'div', 'pow']
  const op = ops[Math.floor(Math.random() * ops.length)]

  let a, b, answer, question
  switch (op) {
    case 'add':
      a = r(1, 500); b = r(1, 500)
      answer = a + b
      question = `Berapa ${a} + ${b}?`
      break
    case 'sub':
      a = r(1, 999); b = r(1, a)
      answer = a - b
      question = `Berapa ${a} − ${b}?`
      break
    case 'mul':
      a = r(2, 30); b = r(2, 30)
      answer = a * b
      question = `Berapa ${a} × ${b}?`
      break
    case 'div': {
      b = r(2, 20); answer = r(2, 50); a = b * answer
      question = `Berapa ${a} ÷ ${b}?`
      break
    }
    case 'pow':
      a = r(2, 9); b = 2
      answer = Math.pow(a, b)
      question = `Berapa ${a}²  (${a} kuadrat)?`
      break
    default:
      a = r(1, 100); b = r(1, 100); answer = a + b
      question = `Berapa ${a} + ${b}?`
  }
  return { question, answer }
}

export default async function LoginPage({ searchParams }) {
  const params = await searchParams
  const error       = params?.error
  const locked      = params?.locked
  const minutesLeft = params?.minutes
  const remaining   = params?.remaining

  const headersList = await headers()
  const ip = headersList.get('x-forwarded-for')?.split(',')[0]?.trim()
           || headersList.get('x-real-ip')
           || 'unknown'

  // Rate limit check sekarang async (DB)
  const rateStatus = await checkRateLimit(ip)

  // ─── Generate captcha fresh every render ──────────────────────────────────
  const settings = await getSettings(['ADMIN_USERNAME', 'ADMIN_EMAIL', 'ADMIN_PASSWORD'])
  const captchaSecret = settings.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD || 'captcha_secret'

  const { question, answer } = generateCaptcha()
  const captchaToken = await new (await import('jose')).SignJWT({ ans: String(answer) })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('10m')
    .sign(new TextEncoder().encode(captchaSecret))

  // ─── Server Action ─────────────────────────────────────────────────────────
  async function handleLogin(formData) {
    'use server'

    const headersList = await headers()
    const ip = headersList.get('x-forwarded-for')?.split(',')[0]?.trim()
             || headersList.get('x-real-ip')
             || 'unknown'

    const status = await checkRateLimit(ip)
    if (!status.allowed) redirect(`/login?locked=1&minutes=${status.minutesLeft}`)

    // Verifikasi captcha
    const token = formData.get('captcha_token')
    const userAnswer = formData.get('captcha')?.trim()
    
    // Get live settings inside server action
    const currentSettings = await getSettings(['ADMIN_USERNAME', 'ADMIN_EMAIL', 'ADMIN_PASSWORD'])
    const actionCaptchaSecret = currentSettings.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD || 'captcha_secret'

    let captchaOk = false
    try {
      const { payload } = await (await import('jose')).jwtVerify(
        token,
        new TextEncoder().encode(actionCaptchaSecret)
      )
      captchaOk = String(payload.ans) === String(userAnswer)
    } catch { captchaOk = false }

    if (!captchaOk) redirect('/login?error=captcha')

    const username   = formData.get('username')
    const email      = formData.get('email')
    const password   = formData.get('password')
    const rememberMe = formData.get('remember') === 'on'

    const isValid = username === (currentSettings.ADMIN_USERNAME || process.env.ADMIN_USERNAME)
                 && email    === (currentSettings.ADMIN_EMAIL || process.env.ADMIN_EMAIL)
                 && password === (currentSettings.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD)

    if (isValid) {
      await clearAttempts(ip)
      
      // Durasi session: 30 hari jika "Ingat Saya", jika tidak 24 jam
      const expiresIn = rememberMe ? '30d' : '24h'
      const session = await sign({ user: currentSettings.ADMIN_USERNAME || process.env.ADMIN_USERNAME }, expiresIn)
      
      const cookieStore = await cookies()
      cookieStore.set('admin_session', session, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        path: '/',
        maxAge: rememberMe ? 30 * 24 * 60 * 60 : 24 * 60 * 60
      })
      redirect('/admin')
    } else {
      const entry = await recordFailedAttempt(ip)
      const remaining = Math.max(0, 5 - entry.count)
      if (entry.lockedUntil) redirect('/login?locked=1&minutes=15')
      else redirect(`/login?error=1&remaining=${remaining}`)
    }
  }

  const isLocked = locked === '1' || !rateStatus.allowed
  const currentRemaining = remaining || (rateStatus.remaining === 5 ? null : rateStatus.remaining)

  return (
    <main className="container flex items-center justify-center" style={{ minHeight: '80vh', position: 'relative' }}>
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', background: 'radial-gradient(circle at 50% 50%, rgba(139,92,246,0.08), transparent 60%)' }} />

      <div className="glass-card flex flex-col gap-5" style={{ maxWidth: '440px', width: '100%', padding: '2.5rem', position: 'relative', zIndex: 1 }}>
        <div className="text-center" style={{ marginBottom: '0.25rem' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '0.75rem' }}>{isLocked ? '🔒' : '🔐'}</div>
          <h1 style={{ fontSize: '1.75rem', fontWeight: 800, marginBottom: '0.4rem' }}>
            <span style={{ background: 'linear-gradient(to right, #60a5fa, #c084fc)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
              Admin Login
            </span>
          </h1>
          <p className="text-secondary" style={{ fontSize: '0.875rem' }}>Masukkan ketiga kredensial untuk masuk.</p>
        </div>

        {isLocked && (
          <div style={{ padding: '1rem', background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.4)', borderRadius: '0.75rem', textAlign: 'center' }}>
            <p style={{ color: '#f87171', fontWeight: 700, fontSize: '1rem', marginBottom: '0.4rem' }}>🚫 Akses Dikunci!</p>
            <p style={{ color: '#fca5a5', fontSize: '0.875rem' }}>
              Terlalu banyak percobaan gagal.<br/>
              Coba lagi dalam <strong>{minutesLeft || rateStatus.minutesLeft || 15} menit</strong>.
            </p>
          </div>
        )}

        {error && !isLocked && (
          <div style={{ padding: '0.875rem 1rem', background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.35)', borderRadius: '0.75rem', color: '#fca5a5', fontSize: '0.875rem' }}>
            <p style={{ marginBottom: '0.3rem' }}>
              ⚠️ <strong>{error === 'captcha' ? '❌ Jawaban verifikasi salah!' : 'Kredensial salah.'}</strong>
            </p>
            {currentRemaining !== null && parseInt(currentRemaining) > 0 && (
              <p style={{ color: '#f87171' }}>Sisa percobaan: <strong>{currentRemaining}x</strong> sebelum akun dikunci.</p>
            )}
          </div>
        )}

        <form action={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <input type="hidden" name="captcha_token" value={captchaToken} />

          <div>
            <label style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.875rem', color: '#a1a1aa' }}>Username</label>
            <input type="text" name="username" required disabled={isLocked} className="input" placeholder="admin" autoComplete="username" />
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.875rem', color: '#a1a1aa' }}>Email</label>
            <input type="email" name="email" required disabled={isLocked} className="input" placeholder="admin@email.com" autoComplete="email" />
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.875rem', color: '#a1a1aa' }}>Password</label>
            <input type="password" name="password" required disabled={isLocked} className="input" placeholder="••••••••" autoComplete="current-password" />
          </div>

          {/* Remember Me */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.2rem' }}>
            <input type="checkbox" name="remember" id="remember" style={{ width: '1.1rem', height: '1.1rem', cursor: 'pointer' }} />
            <label htmlFor="remember" style={{ fontSize: '0.875rem', color: '#d1d5db', cursor: 'pointer' }}>Ingat Saya (30 Hari)</label>
          </div>

          <div style={{ padding: '1rem', background: 'rgba(139,92,246,0.06)', border: '1px solid rgba(139,92,246,0.25)', borderRadius: '0.75rem' }}>
            <p style={{ fontSize: '0.7rem', color: '#71717a', textTransform: 'uppercase', fontWeight: 700, marginBottom: '0.5rem' }}>Verifikasi Matematika</p>
            <p style={{ fontSize: '1.05rem', fontWeight: 800, color: '#c084fc', marginBottom: '0.75rem' }}>{question}</p>
            <input type="number" name="captcha" required disabled={isLocked} className="input" placeholder="Jawaban" />
          </div>

          <button type="submit" disabled={isLocked} className="btn btn-primary" style={{ width: '100%', padding: '0.9rem', fontWeight: 600 }}>
            {isLocked ? '🔒 Akun Dikunci' : 'Masuk ke Dashboard'}
          </button>
        </form>

        {!isLocked && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', justifyContent: 'center' }}>
            {[1,2,3,4,5].map(i => {
              const used = 5 - (parseInt(currentRemaining) || 5)
              return <div key={i} style={{ width: '8px', height: '8px', borderRadius: '50%', background: i <= used ? '#ef4444' : 'rgba(255,255,255,0.15)' }} />
            })}
            <span style={{ color: '#52525b', fontSize: '0.75rem', marginLeft: '0.5rem' }}>Maks 5x percobaan</span>
          </div>
        )}

        {/* Hint */}
        <div style={{ padding: '0.75rem', background: 'rgba(59,130,246,0.06)', border: '1px solid rgba(59,130,246,0.2)', borderRadius: '0.75rem', fontSize: '0.8rem', color: '#60a5b0', lineHeight: 1.6 }}>
          💡 Kredensial dapat diubah melalui <strong>Pengaturan Sistem</strong> di dashboard admin.
        </div>
      </div>
    </main>
  )
}
