'use client'
import Link from 'next/link'
import SpaceBackground from './SpaceBackground'

export default function EmptyState({ category }) {
  return (
    <div style={{ position: 'relative', minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <SpaceBackground variant={Math.floor(Math.random() * 4)} />

      <div style={{ textAlign: 'center', position: 'relative', zIndex: 2, padding: '2rem' }}>
        {/* Moon + Robot (pure CSS inline) */}
        <div style={{ marginBottom: '1.5rem', display: 'inline-block' }}>
          {/* Robot sitting on moon inline SVG */}
          <svg width="180" height="220" viewBox="0 0 180 220" style={{ filter: 'drop-shadow(0 0 20px rgba(139,92,246,0.3))' }}>
            {/* Robot body */}
            <g style={{ animation: 'robot-float 3s ease-in-out infinite' }}>
              {/* Torso */}
              <rect x="65" y="90" width="50" height="45" rx="10" fill="#1e293b" stroke="#3b82f6" strokeWidth="1.8"/>
              <circle cx="90" cy="112" r="7" fill="#60a5fa" style={{ filter: 'drop-shadow(0 0 4px #3b82f6)' }}/>
              {/* Head */}
              <rect x="67" y="55" width="46" height="38" rx="12" fill="#0f172a" stroke="#8b5cf6" strokeWidth="1.8"/>
              {/* Eyes */}
              <circle cx="80" cy="70" r="6" fill="#1e293b"/>
              <circle cx="80" cy="70" r="4" fill="#60a5fa" style={{ filter: 'drop-shadow(0 0 5px #60a5fa)' }}/>
              <circle cx="100" cy="70" r="6" fill="#1e293b"/>
              <circle cx="100" cy="70" r="4" fill="#60a5fa" style={{ filter: 'drop-shadow(0 0 5px #60a5fa)' }}/>
              {/* Smile */}
              <path d="M 76 82 Q 90 90 104 82" stroke="#94a3b8" strokeWidth="2" fill="none" strokeLinecap="round"/>
              {/* Antenna */}
              <line x1="90" y1="55" x2="90" y2="44" stroke="#8b5cf6" strokeWidth="2.5" strokeLinecap="round"/>
              <circle cx="90" cy="42" r="4" fill="#c084fc" style={{ filter: 'drop-shadow(0 0 5px #8b5cf6)' }}/>
              {/* Arms */}
              <rect x="42" y="93" width="24" height="16" rx="8" fill="#1e293b" stroke="#3b82f6" strokeWidth="1.5"/>
              <rect x="114" y="93" width="24" height="16" rx="8" fill="#1e293b" stroke="#3b82f6" strokeWidth="1.5" style={{ animation: 'robot-wave 1.5s ease-in-out infinite' }}/>
            </g>

            {/* Left leg - swinging */}
            <g style={{ transformOrigin: '80px 135px', animation: 'robot-swing-legs 1.2s ease-in-out infinite' }}>
              <rect x="72" y="133" width="15" height="25" rx="7" fill="#0f172a" stroke="#8b5cf6" strokeWidth="1.5"/>
              <rect x="68" y="154" width="20" height="8" rx="4" fill="#1e293b"/>
            </g>
            {/* Right leg - swinging reverse */}
            <g style={{ transformOrigin: '100px 135px', animation: 'robot-swing-legs 1.2s ease-in-out infinite reverse' }}>
              <rect x="93" y="133" width="15" height="25" rx="7" fill="#0f172a" stroke="#8b5cf6" strokeWidth="1.5"/>
              <rect x="92" y="154" width="20" height="8" rx="4" fill="#1e293b"/>
            </g>

            {/* Moon crescent */}
            <ellipse cx="90" cy="175" rx="65" ry="28" fill="#fde68a" style={{ filter: 'drop-shadow(0 0 10px #fbbf24)', animation: 'moon-glow 3s ease-in-out infinite' }}/>
            <ellipse cx="96" cy="170" rx="48" ry="22" fill="#050505"/>

            {/* Small stars around */}
            <circle cx="20" cy="30" r="2" fill="white" style={{ animation: 'twinkle 2s ease-in-out infinite' }}/>
            <circle cx="160" cy="20" r="1.5" fill="white" style={{ animation: 'twinkle 2.5s ease-in-out infinite', animationDelay: '0.5s' }}/>
            <circle cx="155" cy="100" r="1" fill="white" style={{ animation: 'twinkle 3s ease-in-out infinite', animationDelay: '1s' }}/>
            <circle cx="25" cy="110" r="2" fill="#fbbf24" style={{ animation: 'twinkle 1.8s ease-in-out infinite', animationDelay: '0.3s' }}/>
            <circle cx="140" cy="60" r="1.5" fill="#c084fc" style={{ animation: 'twinkle 2.2s ease-in-out infinite', animationDelay: '0.7s' }}/>
          </svg>
        </div>

        <h3 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '0.75rem' }}>
          Belum ada produk di sini 🌙
        </h3>
        <p style={{ color: '#a1a1aa', marginBottom: '0.5rem', fontSize: '0.95rem' }}>
          Robot kami masih duduk-duduk di bulan...
        </p>
        <p style={{ color: '#52525b', marginBottom: '2rem', fontSize: '0.875rem' }}>
          Tambahkan produk dengan kategori <strong style={{ color: '#8b5cf6' }}>{category}</strong> dari halaman Admin.
        </p>
        <Link href="/admin/products" className="btn btn-primary" style={{ padding: '0.75rem 2rem' }}>
          + Tambah Produk
        </Link>
      </div>
    </div>
  )
}
