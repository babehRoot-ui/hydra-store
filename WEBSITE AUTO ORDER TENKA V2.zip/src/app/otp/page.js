'use client'
import { useState } from 'react'
import nextDynamic from 'next/dynamic'
import Link from 'next/link'

export const dynamic = 'force-dynamic'

const SpaceBackground = () => null // Disabled for cleanliness

export default function OtpPage() {
  const [selectedService, setSelectedService] = useState('WhatsApp')
  const [selectedCountry, setSelectedCountry] = useState('Indonesia')

  const services = []
  const countries = []

  return (
    <main style={{ paddingBottom: '8rem', position: 'relative', minHeight: '100vh' }}>
      <SpaceBackground variant={3} />
      
      <section className="container" style={{ padding: '6rem 0 3rem', position: 'relative', zIndex: 2 }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <h1 style={{ fontSize: '3rem', fontWeight: 800, marginBottom: '1.5rem' }}>
            <span className="text-gradient">Beli Nomor OTP</span>
          </h1>
          <p className="text-secondary" style={{ maxWidth: '600px', margin: '0 auto' }}>
            Dapatkan nomor virtual untuk verifikasi akun media sosial secara instan.
          </p>
        </div>

        {services.length === 0 ? (
          <div className="glass-card text-center" style={{ padding: '4rem' }}>
            <p style={{ fontSize: '3rem', marginBottom: '1rem' }}>📱</p>
            <h3 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '0.5rem' }}>Layanan Belum Tersedia</h3>
            <p className="text-secondary">Silahkan kembali lagi nanti atau hubungi admin.</p>
          </div>
        ) : (
          <div className="grid gap-8" style={{ gridTemplateColumns: '1fr 1.5fr' }}>
            {/* ... rest of the code ... */}
          </div>
        )}
      </section>
    </main>
  )
}
