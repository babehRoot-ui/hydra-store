const { PrismaClient } = require('@prisma/client')
const prisma = new PrismaClient()

async function main() {
  console.log('Clearing old data...')
  await prisma.order.deleteMany({})
  await prisma.product.deleteMany({})

  console.log('Seeding products for all categories...')

  const products = [
    // Category: script
    { name: 'Tenka-MD V3 Premium', price: 50000, category: 'script', description: 'Script WhatsApp Bot tercanggih dengan fitur terlengkap.', badge: 'HOT', featured: true },
    { name: 'Simple Bot MD v2', price: 25000, category: 'script', description: 'Script bot ringan untuk pemula.', badge: 'NEW' },
    
    // Category: cpanel
    { name: 'Hosting CPanel 1GB', price: 10000, category: 'cpanel', description: 'Hosting kencang dengan cPanel asli.', badge: 'SALE' },
    { name: 'Hosting CPanel UNLIMITED', price: 50000, category: 'cpanel', description: 'Hosting tanpa batas untuk web besar.', featured: true },

    // Category: panel
    { name: 'Panel Reseller Bot', price: 75000, category: 'panel', description: 'Kelola reseller bot Anda sendiri.', badge: 'HOT' },

    // Category: ptero
    { name: 'Theme Ptero Night', price: 30000, category: 'ptero', description: 'Tema gelap elegan untuk Pterodactyl.', badge: 'NEW' },
    
    // Category: sewa (already had some, but adding fresh ones)
    { name: 'Sewa Bot 3 Hari', price: 3000, category: 'sewa', description: 'Sewa bot durasi singkat.' },
    { name: 'Sewa Bot 30 Hari', price: 15000, category: 'sewa', description: 'Sewa bot durasi 1 bulan.', badge: 'HOT' },
    { name: 'Sewa Bot 1 Tahun', price: 50000, category: 'sewa', description: 'Sewa bot durasi hemat 1 tahun.', featured: true },
  ]

  for (const p of products) {
    await prisma.product.create({ data: p })
  }

  console.log('Seeding fake success orders for feed...')
  const p1 = await prisma.product.findFirst({ where: { category: 'script' } })
  const p2 = await prisma.product.findFirst({ where: { category: 'sewa' } })

  await prisma.order.create({
    data: {
      id: 'ORDER-123',
      customerName: 'Budi',
      customerPhone: '08123456789',
      customerEmail: 'budi@mail.com',
      amount: p1.price,
      status: 'SUCCESS',
      productId: p1.id,
      receiptCode: 'TENKA-XYZ-123'
    }
  })

  await prisma.order.create({
    data: {
      id: 'ORDER-456',
      customerName: 'Ani',
      customerPhone: '08987654321',
      customerEmail: 'ani@mail.com',
      amount: p2.price,
      status: 'SUCCESS',
      productId: p2.id,
      receiptCode: 'BOT-ABC-456'
    }
  })

  console.log('Seeding done!')
}

main()
  .catch(e => console.error(e))
  .finally(async () => await prisma.$disconnect())
