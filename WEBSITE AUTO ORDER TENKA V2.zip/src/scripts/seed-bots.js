const { PrismaClient } = require('@prisma/client')
const prisma = new PrismaClient()

const sewaProducts = [
  { name: 'Sewa Bot 3 Hari', price: 3000, description: 'Sewa bot WhatsApp selama 3 hari.' },
  { name: 'Sewa Bot 7 Hari', price: 6000, description: 'Sewa bot WhatsApp selama 7 hari.' },
  { name: 'Sewa Bot 14 Hari', price: 12000, description: 'Sewa bot WhatsApp selama 14 hari.' },
  { name: 'Sewa Bot 30 Hari', price: 15000, description: 'Sewa bot WhatsApp selama 30 hari.' },
  { name: 'Sewa Bot 2 Bulan', price: 28000, description: 'Sewa bot WhatsApp selama 2 bulan.' },
  { name: 'Sewa Bot 3 Bulan', price: 38000, description: 'Sewa bot WhatsApp selama 3 bulan.' },
  { name: 'Sewa Bot 4 Bulan', price: 42000, description: 'Sewa bot WhatsApp selama 4 bulan.' },
  { name: 'Sewa Bot 5 Bulan', price: 52000, description: 'Sewa bot WhatsApp selama 5 bulan.' },
  { name: 'Sewa Bot 6 Bulan', price: 55000, description: 'Sewa bot WhatsApp selama 6 bulan.' },
  { name: 'Sewa Bot 1 Tahun', price: 68000, description: 'Sewa bot WhatsApp selama 1 tahun.' },
  { name: 'Sewa Bot 2 Tahun', price: 72000, description: 'Sewa bot WhatsApp selama 2 tahun.' },
]

async function main() {
  console.log('Seeding sewa bot products...')
  for (const p of sewaProducts) {
    const exists = await prisma.product.findFirst({ where: { name: p.name } })
    if (exists) {
      await prisma.product.update({
        where: { id: exists.id },
        data: {
          price: p.price,
          category: 'sewa',
          subcategory: 'WhatsApp Bot'
        }
      })
    } else {
      await prisma.product.create({
        data: {
          name: p.name,
          price: p.price,
          description: p.description,
          category: 'sewa',
          subcategory: 'WhatsApp Bot',
          features: JSON.stringify(['24/7 Online', 'Anti Delay', 'Full Fitur'])
        }
      })
    }
  }
  console.log('Seeding done!')
}

main()
  .catch(e => console.error(e))
  .finally(() => prisma.$disconnect())
