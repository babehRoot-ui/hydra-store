const { PrismaClient } = require('@prisma/client')
const prisma = new PrismaClient()

async function main() {
  console.log('SEEDING REAL PRODUCTS...')

  // 1. SEWA BOT WHATSAPP
  const sewaBotData = [
    { name: 'Sewa Bot WA - 3 Hari', price: 3000, duration: '3 Hari' },
    { name: 'Sewa Bot WA - 7 Hari', price: 6000, duration: '7 Hari' },
    { name: 'Sewa Bot WA - 14 Hari', price: 12000, duration: '14 Hari' },
    { name: 'Sewa Bot WA - 30 Hari', price: 15000, duration: '30 Hari' },
    { name: 'Sewa Bot WA - 2 Bulan', price: 28000, duration: '2 Bulan' },
    { name: 'Sewa Bot WA - 3 Bulan', price: 38000, duration: '3 Bulan' },
    { name: 'Sewa Bot WA - 4 Bulan', price: 42000, duration: '4 Bulan' },
    { name: 'Sewa Bot WA - 5 Bulan', price: 52000, duration: '5 Bulan' },
    { name: 'Sewa Bot WA - 6 Bulan', price: 55000, duration: '6 Bulan' },
    { name: 'Sewa Bot WA - 1 Tahun', price: 68000, duration: '1 Tahun' },
    { name: 'Sewa Bot WA - 2 Tahun', price: 72000, duration: '2 Tahun' },
  ]

  for (const item of sewaBotData) {
    await prisma.product.create({
      data: {
        name: item.name,
        price: item.price,
        description: `⚡ 1800+ Fitur • Anti Spam • Anti Link • Anti Bot • Anti Bokep • Stiker • AI • RPG • Game • Downloader • Play Musik/spotify • Tagall member group • HD FOTO • Dan masih banyak lagi. Durasi: ${item.duration}`,
        category: 'sewa',
        badge: item.duration === '30 Hari' ? 'HOT' : (item.duration === '2 Tahun' ? 'LIMITED' : null),
        features: JSON.stringify(['1800+ Fitur', 'Anti Spam/Link', 'Sticker & AI', 'RPG & Game', 'Music & DL'])
      }
    })
  }

  // 2. SELL SCRIPT BOT
  const scriptData = [
    { name: 'Script Bot Tenka-MD (Full)', price: 70000, desc: 'Fitur 1800+ • Free Update • Masuk GB Khusus • Bimbingan Owner • Bisa Req Fitur. Bonus: Panel Unli + 10 SC Acak' },
    { name: 'Paket 5 Script (JPM x Tenka, JPM v4, CPanel x Tenka, CPanel v2, Akane)', price: 40000, desc: '4 SCRIPT CUMA 40K. Bisa JPMHT + Video/Image, JPM Biasa, Status Group, Set Interval. Bonus: Panel Unli + 5 SC Acak' },
    { name: 'SC JPM x Tenka', price: 15000, desc: 'Script JPM x Tenka Original' },
    { name: 'SC JPM v4', price: 20000, desc: 'Script JPM v4 Original' },
    { name: 'SC CPanel x Tenka', price: 18000, desc: 'Script CPanel x Tenka Original' },
    { name: 'SC CPanel v2', price: 15000, desc: 'Script CPanel v2 Original' },
  ]

  for (const item of scriptData) {
    await prisma.product.create({
      data: {
        name: item.name,
        price: item.price,
        description: item.desc,
        category: 'script',
        badge: item.price === 40000 ? 'BEST VALUE' : (item.price === 70000 ? 'PREMIUM' : null),
        features: JSON.stringify(['1800+ Fitur', 'Free Update', 'Bimbingan Owner', 'Full Access'])
      }
    })
  }

  // 3. PANEL PTERODACTYL
  const pteroData = [
    { name: 'Panel Ptero - 5 GB', price: 5000 },
    { name: 'Panel Ptero - 6 GB', price: 7000 },
    { name: 'Panel Ptero - 7 GB', price: 10000 },
    { name: 'Panel Ptero - 8 GB', price: 13000 },
    { name: 'Panel Ptero - 9 GB', price: 15000 },
    { name: 'Panel Ptero - 10 GB', price: 18000 },
    { name: 'Panel Ptero - UNLIMITED', price: 20000 },
  ]

  for (const item of pteroData) {
    await prisma.product.create({
      data: {
        name: item.name,
        price: item.price,
        description: '⚡ Private • Anti Colong SC • Anti Delay • Anti Lag • Garansi 10 Hari • VPS Legal • Anti Mokad. BUY FREE 2 SCRIPT!',
        category: 'ptero',
        badge: item.name.includes('UNLIMITED') ? 'HOT' : null,
        features: JSON.stringify(['Private Server', 'Anti Delay/Lag', 'Garansi 10 Hari', 'Free 2 Script'])
      }
    })
  }

  // 4. RESELLER & MANAGEMENT
  const managementData = [
    { name: 'Reseller Panel (Permanen)', price: 15000 },
    { name: 'Admin Panel (Permanen)', price: 18000 },
    { name: 'Partner Panel (Permanen)', price: 20000 },
    { name: 'Owner Panel (Permanen)', price: 28000 },
    { name: 'TK Panel VVIP (Permanen)', price: 32000 },
    { name: 'CEO Panel (Permanen)', price: 38000 },
  ]

  for (const item of managementData) {
    await prisma.product.create({
      data: {
        name: item.name,
        price: item.price,
        description: '✨ Bisa jualan sepuasnya • Bikin panel kapan aja • Support 24/7 • VPS Legal • Akses 3 Server • Permanen. BUY FREE 3 SCRIPT!',
        category: 'panel',
        badge: 'VVIP',
        features: JSON.stringify(['Unlimited Create', 'Full Support 24/7', 'Permanen', 'Free 3 Script'])
      }
    })
  }

  console.log('SEEDING COMPLETED SUCCESS!')
}

main()
  .catch(e => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
