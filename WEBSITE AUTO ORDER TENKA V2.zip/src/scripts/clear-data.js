const { PrismaClient } = require('@prisma/client')
const prisma = new PrismaClient()

async function main() {
  console.log('--- DATABASE CLEANUP ---')
  
  try {
    const orders = await prisma.order.deleteMany({})
    console.log(`Successfully deleted ${orders.count} orders.`)
    
    const products = await prisma.product.deleteMany({})
    console.log(`Successfully deleted ${products.count} products.`)
    
    console.log('Database is now EMPTY and ready for fresh data.')
  } catch (error) {
    console.error('Error clearing database:', error)
  } finally {
    await prisma.$disconnect()
  }
}

main()
