# 🚀 NEXT-GEN PREMIUM DIGITAL STORE SC (TENKA STORE BASE)
Source Code Website Toko Digital, Panel Pterodactyl, dan Layanan Bot WhatsApp Otomatis dengan Integrasi QRIS Real-Time.

---

## 📑 DAFTAR ISI
1. [Fitur Utama & Keunggulan](#1-fitur-utama--keungg2. [Sistem Pembayaran (15 Opsi Gateway: Midtrans, Xendit, Duitku, dll)](#2-sistem-pembayaran-15-opsi-gateway-terintegrasi)
3. [Apa yang Boleh & Tidak Boleh Diubah](#3-apa-yang-boleh--tidak-boleh-diubah)
4. [Cara Mendapatkan & Mengganti Database PostgreSQL](#4-cara-mendapatkan--mengganti-database-postgresql)
5. [Cara Mengganti Nama, Latar & Identitas (Sampai Akar)](#5-cara-mengganti-nama-latar--identitas-sampai-akar)
6. [Cara Deploy / Hosting Web (Vercel, VPS, Shared Hosting)](#6-cara-deploy--hosting-web-vercel-vps-shared-hosting)
7. [PANDUAN UNTUK SELLER: Cara Menjual SC Ini Tanpa Membocorkan Data Pribadi](#7-panduan-khusus-seller-membersihkan-data-sebelum-dijual)

---

## 1. FITUR UTAMA & KEUNGGULAN
Source Code (SC) ini bukan website toko biasa, melainkan platform otomatisasi tingkat tinggi yang memiliki kelebihan:
*   **Full Auto Delivery:** Pengiriman file, link grup, atau server Pterodactyl terkirim secara otomatis setelah pembayaran sukses, 100% tanpa campur tangan admin!
*   **15 Payment Gateways:** Dukungan gateway terbanyak di kelasnya. Anda tidak akan pernah kehabisan opsi pembayaran.
*   **Keamanan Anti-Bypass:** Halaman pembayaran memiliki sistem polling dan proteksi Webhook, tidak mungkin ditembus oleh pembeli nakal.
*   **Dynamic Dashboard (Tanpa Coding):** Latar belakang, musik, sambutan, API Key, dan daftar produk semuanya diatur langsung dari Panel Admin.
*   **Failover Pterodactyl:** Mendukung hingga 3 server Node Pterodactyl sekaligus.

---

## 2. SISTEM PEMBAYARAN (15 OPSI GATEWAY TERINTEGRASI)
Website ini menggunakan **15 Opsi Payment Gateway**. Anda bisa beralih kapan saja lewat Dashboard!

### 💎 GATEWAY POPULER (REKOMENDASI)
1.  **MIDTRANS:** Gateway #1 di Indonesia. Mendukung QRIS, VA, E-Wallet, Kartu Kredit.
2.  **XENDIT:** Integrasi sangat cepat, Dashboard sangat rapi, mendukung Invoice otomatis.
3.  **DUITKU:** Favorit developer UMKM, biaya admin sangat kompetitif.
4.  **IPAYMU:** Pendaftaran cepat, mendukung QRIS dan banyak gerai retail.
5.  **OY! BISNIS:** Sangat stabil untuk link pembayaran dan VA.

### 🚀 GATEWAY SPESIALIS & ALTERNATIF
6.  **PAKASIR:** QRIS real-time sangat stabil.
7.  **TRIPAY:** Favorit seller digital/top-up game.
8.  **FINPAY:** Layanan dari Telkom, sangat kredibel.
9.  **FASPAY:** Mendukung gerai retail sangat lengkap.
10. **ESPAY:** Fokus pada transaksi cepat dan aman.
11. **DOKU:** Standar korporat, pendaftaran resmi.
12. **ATLANTIC-PEDIA:** Favorit seller bot dan SMM.
13. **MAYAR:** Modern, simple, pendaftaran instan.
14. **DURIANPAY:** Satu integrasi untuk semua metode.
15. **UANGX:** Settlement cepat dan interface bersih.

**PENTING:** Untuk setiap gateway, pastikan Anda mengisi API Key di **Dashboard Admin > Pengaturan Sistem > Tab Pembayaran** dan mengatur **Webhook/Callback URL** di dashboard masing-masing penyedia ke alamat: `https://domain-anda.com/api/[nama-gateway]/webhook` (Contoh: `.../api/midtrans/webhook`).bhook`

---

## 3. APA YANG BOLEH & TIDAK BOLEH DIUBAH
Untuk menghindari website *crash* atau *error* (Mengingat fitur web ini sangat kompleks), harap perhatikan pedoman berikut:

✅ **YANG SANGAT BOLEH DIGANTI (Oleh Anda maupun Pembeli SC):**
- **Semua visual di Dashboard Admin:** Judul web, deskripsi, gambar logo, URL musik latar belakang, latar belakang website (video/gambar).
- **Semua Produk:** Nama produk, harga, kategori produk.
- **Link Sosial Media / WhatsApp:** Tombol CS dan link bantuan.
- Isi dari menu navigasi (Navbar).

❌ **YANG TIDAK BOLEH DIGANTI/DIHAPUS (Bisa Membuat Web Mati/Error):**
- Dilarang menghapus struktur file di folder `src/app/api/`. Itu adalah jantung dari pembayaran dan keamanan web.
- Dilarang sembarangan mengganti skema/model di `prisma/schema.prisma` jika tidak paham manajemen database. Jika Anda hapus 1 baris, sistem pembayaran akan rusak.
- Dilarang memodifikasi file `middleware.js` atau `lib/auth.js` jika tidak memahami JWT dan Next.js Edge Runtime (karena mengurus token admin).
- Jangan menghapus file `package.json` atau `package-lock.json`.

---

## 4. CARA MENDAPATKAN & MENGGANTI DATABASE POSTGRESQL
Web ini menggunakan database canggih PostgreSQL (bukan MySQL biasa). Anda bisa menggunakan penyedia gratis seperti **Neon.tech** atau **Supabase**.

**Langkah Mendapatkan URL Database (Menggunakan Neon.tech):**
1. Buka [neon.tech](https://neon.tech/) dan buat akun (gratis).
2. Buat project baru (Beri nama bebas, misal: `toko-digital`).
3. Setelah project dibuat, Anda akan melihat sebuah **Connection String** (biasanya dimulai dengan `postgresql://...`).
4. Salin kode `postgresql://...` tersebut.

**Cara Memasangnya ke Web:**
1. Buka file `.env` di dalam folder project ini (buat file baru bernama `.env` jika belum ada).
2. Tambahkan baris ini:
   `DATABASE_URL="postgresql://username:password@namaserver.neon.tech/namadatabase?sslmode=require"` (Ganti dengan URL yang Anda copy dari Neon).
3. Buka terminal (CMD) di dalam folder SC, lalu ketik perintah wajib ini:
   `npx prisma db push`
4. Perintah di atas akan secara otomatis membuatkan semua tabel yang dibutuhkan oleh web (tabel produk, tabel setting, tabel transaksi). Database Anda kini siap digunakan!

---

## 5. CARA MENGGANTI NAMA, LATAR & IDENTITAS (SAMPAI AKAR)
Anda tidak perlu repot mencari kode HTML untuk mengganti nama web. Web ini dibuat agar **100% perubahannya dilakukan lewat Dashboard**.

1. Login ke web melalui `https://domain-anda/login`.
   *(Secara default jika database baru, gunakan username dan password yang ada di file `.env.local` atau `.env`, biasanya `admin` dan `password`)*
2. Masuk ke halaman **Admin > Pengaturan Sistem**.
3. Di situ terdapat 7 Tab. Di sinilah **akar perubahan** dilakukan:
   - **Tab Tampilan Awal:** Ubah popup selamat datang, video, dan foto.
   - **Tab Latar Web:** Ubah gambar latar gelap menjadi foto game atau animasi ruang angkasa sesuai keinginan. Pilih "Standar" jika ingin latar gelap biasa.
   - **Tab Musik:** Masukkan URL `.mp3` lagu yang akan berputar saat pengunjung datang.
   - **Tab Info Toko:** Ubah nama "Tenka Store" menjadi "Toko Anda" sampai ke akar-akarnya.
   - **Tab Panel/Server:** Tempat menaruh kredensial Pterodactyl untuk penjual panel.
   - **Tab Admin:** Tempat merubah Username, Email, dan Password login admin Anda.

---

## 6. CARA DEPLOY / HOSTING WEB (VERCEL, VPS, SHARED HOSTING)
Source code ini dibangun menggunakan **Next.js**, sehingga sangat fleksibel dan bisa di-deploy di berbagai macam platform hosting modern.

### OPSI 1: DEPLOY KE VERCEL (GRATIS & PALING MUDAH)
Vercel adalah platform bawaan pembuat Next.js, sangat cocok untuk pemula.
1. Buat akun di [Vercel.com](https://vercel.com/) menggunakan GitHub.
2. Upload folder source code ini ke repository GitHub Anda (Private).
3. Di Vercel, klik **Add New Project**, lalu import repository GitHub tersebut.
4. Di bagian **Environment Variables**, masukkan isi dari file `.env` Anda:
   - Name: `DATABASE_URL` | Value: `postgresql://...`
   - Name: `JWT_SECRET` | Value: `bebas_acak_123`
   - *(Tambahkan juga API Key Gateway jika tidak ingin menyimpannya di DB)*
5. Klik **Deploy**. Selesai dalam 2 menit!

### OPSI 2: DEPLOY KE VPS (UBUNTU/DEBIAN) DENGAN PM2
Sangat cocok untuk Anda yang ingin performa maksimal dan kontrol penuh.
1. Siapkan VPS Anda, pastikan sudah terinstall Node.js (v18+) dan NPM.
2. Upload source code ke VPS (bisa via FTP, Git, atau SCP).
3. Masuk ke folder web: `cd /path/ke/folder/web`
4. Install semua library: `npm install`
5. Atur file `.env` Anda dengan koneksi database yang benar.
6. Buat struktur database: `npx prisma db push`
7. Build project Next.js: `npm run build`
8. Install PM2 (jika belum): `npm install -g pm2`
9. Jalankan web: `pm2 start npm --name "tenka-store" -- start`
10. Selesai! Web Anda sekarang berjalan non-stop di background VPS. Gunakan Nginx sebagai Reverse Proxy untuk mengarahkan port 3000 ke domain Anda.

### OPSI 3: DEPLOY VIA DOCKER (ADVANCED)
Jika Anda pecinta Docker, Anda bisa membuat `Dockerfile` sederhana untuk aplikasi Next.js ini dan menjalankannya di container manapun (Google Cloud Run, AWS ECS, dll).
1. Buat `Dockerfile` yang memuat Node 18, jalankan `npm install`, `npx prisma generate`, dan `npm run build`.
2. Expose port 3000.
3. Jalankan container dengan meneruskan variabel `.env`.

---

## 7. PANDUAN KHUSUS SELLER: MEMBERSIHKAN DATA SEBELUM DIJUAL
**(PENTING UNTUK ANDA YANG INGIN MENJUAL KEMBALI SC INI)**

Jika Anda mengirim file SC ini "mentah-mentah" dari laptop Anda ke pembeli SC, maka **DATABASE, KATA SANDI, DAN PRODUK PRIBADI ANDA AKAN IKUT TERJUAL**. Ini sangat berbahaya!

Ikuti pedoman pembersihan ini **sebelum Anda men-zip / me-rar** file SC ini kepada pembeli:

### A. Hapus File Konfigurasi Sensitif
Cari dan **HAPUS** file berikut dari dalam folder source code sebelum Anda kompres (Zip):
1. Hapus file `.env` (Ini berisi link database dan password Anda).
2. Hapus file `.env.local` (Sama bahayanya).
3. Hapus folder `.vercel` (Jika ada, karena ini terhubung dengan akun Vercel Anda).
4. Hapus folder `.next` (File cache build lokal).
5. Hapus folder `node_modules` (Ukurannya terlalu besar, pembeli wajib menginstalnya sendiri nanti dengan `npm install`).

### B. Siapkan File `.env.example`
Sebagai ganti file `.env` yang Anda hapus, buatlah file baru dengan nama `.env.example` untuk panduan pembeli. Isinya:
```env
DATABASE_URL="postgresql://user:pass@host/db_name?sslmode=require"
ADMIN_USERNAME="admin"
ADMIN_EMAIL="admin@email.com"
ADMIN_PASSWORD="password123"
```
Pembeli nanti tinggal menyalin `.env.example` menjadi `.env` milik mereka sendiri.

### C. Bersihkan Database (Opsional Jika Pembeli Menggunakan Database Anda)
Biasanya, pembeli akan membuat database mereka sendiri di Neon.tech (seperti panduan No. 4). Karena link database Anda di `.env` sudah dihapus, maka produk, transaksi, dan settingan web Anda **sudah aman 100%**. Pembeli akan memulai dengan web yang benar-benar kosong saat mereka melakukan `npx prisma db push`.

### D. File Produk Fisik / Media Lokal
Jika Anda pernah mengunggah gambar produk menggunakan Supabase CDN (seperti diatur di web ini), foto tersebut tersimpan di *cloud* Anda. Pembeli akan melihat gambar tersebut kecuali mereka menggantinya sendiri. Ini aman, tidak ada rahasia yang bocor.

### Kesimpulan untuk Penjual:
Bungkus folder yang berisi `src`, `prisma`, `public`, `package.json`, dan `README.md` (beserta `.env.example`). Zip folder tersebut, dan file SC Anda kini **siap dijual secara aman, profesional, dan lepas dari data pribadi Anda!**

---

## 8. PERUBAHAN & FITUR BARU TERBARU (UPDATE MEI 2026)
Pada pembaruan Mei 2026, Source Code ini telah ditingkatkan menjadi jauh lebih premium, fleksibel, dan cerdas dengan penambahan fitur-fitur berikut:

### 📁 A. Sistem Kategori & Desain Halaman Dinamis (100% Tanpa Coding)
Anda tidak perlu lagi mengedit kode visual berulang kali untuk membuat kategori. Sekarang Anda bisa mengelolanya dari menu baru **📁 Kategori & Tema**:
*   **Tambah Kategori Tanpa Batas:** Tentukan nama, slug URL kustom, emoji, dan tag filter (misal: tag `bot, wa` akan otomatis menyaring produk dengan tag tersebut ke kategori tersebut).
*   **Kostumisasi Tema Warna Gradasi:** Tentukan warna gradasi premium (dari palet warna color picker) untuk setiap kategori secara terpisah.
*   **Style/Layout Halaman:** Pilih layout visual halaman untuk setiap kategori (klasik Grid Kartu, Masonry Dinamis, atau Showcase Lebar).
*   **Robot Mascot & Latar Belakang:** Kustomisasi latar belakang halaman kategori (dari Gelap Standar hingga Ruang Angkasa Premium) dan animasi Maskot Robot (Melambai, Terbang, Duduk di Bulan, atau Tanpa Robot) lengkap dengan pengaturan posisi di kiri atau kanan!
*   **Auto-Sync Global:** Navigasi Navbar atas, tab filter halaman depan, dan form tambah/edit produk admin otomatis sinkron dengan kategori database Anda!

### 📈 B. Grafik Penjualan Kurva Area Premium (Real-Time & Nyata)
Grafik batang bawaan telah diganti dengan grafik kurva melengkung lembut (**Area Chart**) yang dilengkapi efek gradien holografis di bawah garis:
*   **Warna Titik Tren Otomatis (Glow Indicator):**
    *   **Titik Merah (🚨 Turun Pertama):** Menyala merah saat penjualan pertama kali turun dibanding periode sebelumnya.
    *   **Titik Biru (📉 Stabil Turun / 📈 Stabil Naik):** Menyala biru saat tren naik atau turun terus berlanjut secara stabil.
    *   **Titik Hijau (✨ Naik Pertama):** Menyala hijau saat penjualan pertama kali melonjak naik dibanding periode sebelumnya.
*   **Filter Multi-Timeframe:** Tombol instan untuk beralih visualisasi grafik **Per Hari** (15 hari terakhir), **Per Bulan** (tahun berjalan), **Per Tahun** (3 tahun terakhir), dan **Semua** (riwayat transaksi runtut).
*   **Mode Demo Simulasi:** Jika database Anda masih kosong (0 transaksi lunas), grafik otomatis beralih ke Mode Simulasi yang menawan agar visual dasbor tetap hidup, dan otomatis nonaktif setelah transaksi riil pertama Anda sukses!

### 👥 C. Pelacak Pengunjung Unik Riil (IP Unique Visitor)
*   **👥 Total Pengunjung (IP Unik):** Kartu statistik baru berwarna biru langit (*sky blue*) di Dasbor Admin yang merekam jumlah user riil yang pernah masuk ke website Anda secara akurat (berdasarkan IP unik, bukan klik palsu/refresh halaman).
*   **Asynchronous Tracker:** Pelacakan IP di halaman beranda bekerja secara asinkron tanpa memblokir respon pemuatan halaman, menjaga website Anda tetap super cepat dan instan!

