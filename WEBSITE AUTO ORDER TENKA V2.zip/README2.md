# ✨ EXCLUSIVE FEATURE SHOWCASE - NEXT-GEN DIGITAL STORE ✨
Selamat datang di era baru jualan digital. Source Code (SC) ini bukan sekadar website, ini adalah **Mesin Uang Otomatis** yang bekerja 24/7 untuk Anda.

---

## 💎 FITUR UTAMA (MAIN FEATURES)
Fitur-fitur pondasi yang membuat website ini berdiri kokoh dan profesional:
1.  **🚀 Full Automation System:** Bayar -> Verifikasi -> Barang Terkirim. Semua terjadi dalam hitungan detik tanpa Anda perlu menyentuh HP.
2.  **🛡️ Military-Grade Security:** Proteksi berlapis terhadap serangan bypass, SQL Injection, dan manipulasi harga.
3.  **💳 15-in-1 Ultimate Payment Gateways:** Dukungan masif untuk Midtrans, Xendit, Faspay, iPaymu, Finpay, Espay, Duitku, OY!, Pakasir, Atlantic, DOKU, Tripay, Mayar, Durianpay, dan UangX. Bebas pilih!
4.  **📊 Advanced Product Management:** Kelola ribuan produk digital (file, link, grup, server) dengan sangat mudah.

---

## 🔥 FITUR UNGGULAN & KEREN (COOL FEATURES)
Bagian yang akan membuat pembeli Anda terpesona:
*   **🌌 Futuristic Moon UI:** Desain futuristik dengan mascot moon yang melayang, efek glassmorphism, dan animasi super halus.
*   **🦖 Failover Pterodactyl Panel:** Jika Server 1 penuh atau mati, sistem otomatis beralih ke Server 2 atau 3 untuk membuatkan panel pesanan. Tidak ada kata gagal!
*   **🎭 All-in-One Branding:** Ubah Nama Toko, Video Selamat Datang, Musik Latar, hingga Background secara instan dari Dashboard Admin.
*   **📱 Super Responsive Design:** Tampilan tetap mewah dan elegan baik dibuka melalui PC, Tablet, maupun Smartphone.
*   **💬 Integrated CS Support:** Tombol Chat CS (WhatsApp) dinamis yang muncul otomatis jika diaktifkan.

---

## ⚡ FITUR MENAKJUBKAN (AMAZING FEATURES)
Fitur yang jarang ditemukan di Source Code lain:
*   **📁 Dynamic Category & Theme Engine:** Tambah, edit, dan rancang layout kategori Anda sendiri secara visual dengan pilihan warna gradasi premium, robot maskot melayang di kiri/kanan, serta penyaringan produk otomatis via Tag Filter!
*   **📈 Real-Time Glow Trend Curve Chart:** Grafik kurva area premium dengan detektor tren otomatis. Menampilkan warna merah menyala untuk penurunan pertama, hijau untuk kenaikan pertama, dan biru untuk kelanjutan tren stabil. Mendukung filter Harian, Bulanan, Tahunan, dan Semua!
*   **👥 Asynchronous Unique Visitor Tracking:** Merekam alamat IP unik pengunjung secara asinkron tanpa membebani performa web, mencegah manipulasi jumlah kunjungan palsu (refresh halaman).
*   **🛡️ Anti-Bypass Payment:** Halaman QRIS menggunakan sistem polling cerdas. Tidak bisa ditembus oleh trik 'pencet tombol bayar' palsu.
*   **🔐 Admin Account Protection:** Sistem login menggunakan enkripsi JWT (JSON Web Token) yang sangat aman.
*   **📈 Real-Time Order Tracking:** Pelanggan bisa melihat status pesanan mereka secara langsung dari halaman checkout.
*   **🎨 Dynamic Background Engine:** Mendukung pergantian latar belakang ke mode "Default Dark" hanya dengan satu klik jika ingin tampilan original.
*   **🛑 Cancel Purchase Button:** Memberikan pengalaman belanja yang nyaman bagi pelanggan dengan tombol pembatalan yang intuitif.

---

## 🛠️ DAFTAR FITUR LENGKAP (FULL FEATURE LIST)

### 👤 Fitur Sisi User (Pembeli)
- [x] Home Page Kategoris (Rapi & Teratur)
- [x] Pencarian Produk Real-Time
- [x] Detail Produk dengan Deskripsi Markdown
- [x] Modal Pembayaran QRIS yang Interaktif
- [x] Notifikasi Suara/Efek saat Membuka Web
- [x] Tombol Batal Beli (UX Improvement)
- [x] Support Berbagai E-Wallet & Bank melalui 15 Gateway

### ⚙️ Fitur Sisi Admin (Pemilik)
- [x] Dashboard Statistik Mewah (Real-Time 4 Kartu: Produk, Pesanan, Omset Nyata, Pengunjung Unik)
- [x] Grafik Penjualan Kurva Area Premium (Multi-Timeframe & Logika Tren Glowing)
- [x] Sistem Kategori & Desain Halaman Dinamis (Kategori & Tema, Warna Gradasi, Custom Robot & Posisi)
- [x] Manajemen Produk (Tambah, Edit, Hapus, Cari, Hubungkan ke Kategori Dinamis)
- [x] Pengaturan API Key 15 Payment Gateway
- [x] Pengaturan API Pterodactyl (3 Server Failover)
- [x] Pengaturan Branding (Nama, Logo, Background, Musik)
- [x] Manajemen Akun Admin (Ganti Username/Password/Email)

### 🔒 Fitur Keamanan (Security)
- [x] Validasi Webhook Signature (Opsional/Tergantung Gateway)
- [x] Math CAPTCHA pada Login Admin
- [x] Proteksi Folder Sensitif
- [x] Environment Variables (.env) untuk Data Rahasia

---

## 🌟 MENGAPA HARUS MEMILIKI SC INI?
1.  **Investasi Sekali, Cuan Berkali-kali:** Anda bisa menjual ribuan produk digital tanpa biaya operasional tinggi.
2.  **No Coding Skill Needed:** Semuanya diatur dari dashboard. Cocok untuk pemula maupun pro.
3.  **Unique Aesthetic:** Desain "Hologram Moon" memberikan kesan website mahal dan terpercaya.
4.  **Siap Pakai (Ready to Deploy Anywhere):** Cukup pasang database dan deploy ke Vercel, VPS (PM2/Docker), atau Shared Hosting. Toko langsung buka!

---
*Dibuat dengan ❤️ untuk para pengusaha digital masa depan.*
